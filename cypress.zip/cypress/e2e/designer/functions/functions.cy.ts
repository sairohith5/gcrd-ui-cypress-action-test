import { skipOn } from "@cypress/skip-test";
import { getRelativeDate } from "../../../utils/date-utils";
import {
  openDialog,
  testDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";
import {
  testColumnVisibility,
  testFilter,
  testPagination,
  testRow,
  testSort,
  testTable,
  toggleColumnVisibility,
} from "../../../utils/grid-utils";
import {
  testRevisionCompareDialog,
  testRevisionHistoryDialogFromGrid,
  testRollback,
} from "../../../utils/revision-history-utils";
import { deleteArtifact } from "../../../utils/utils";
import {
  clearFormField,
  testFormField,
  testFormFieldValidation,
  testNameFieldValidation,
  testNameFieldValidationWhenCloning,
  typeFormField,
} from "../../../utils/form-utils";
import {
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";

describe("functions", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter("Functions");
    cy.testBrowserTitle("Functions");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Designer", "Functions");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays a grid", () => {
    testTable(
      [
        { type: "button", ariaLabel: "Lock Status" },
        "Name",
        "Tags",
        "Last Committed",
        "Actions",
      ],
      [
        { type: "button", value: "checked out by me" },
        "CheckDecisionforEachLine",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for CheckDecisionforEachLine",
          },
          { type: "button", value: "clone CheckDecisionforEachLine" },
          { type: "button", value: "delete function CheckDecisionforEachLine" },
        ],
      ],
    );
    testRow(1, [
      "",
      "entryPointFn",
      { type: "tags", tags: ["BusinessLibrary"] },
      getRelativeDate("2022-05-03 11:28:33 -0400"),
      [
        { type: "button", value: "view revision history for entryPointFn" },
        { type: "button", value: "clone entryPointFn" },
      ],
    ]);
    testFilter("fn_", [
      "",
      "fn_ActivePending_ClinicalProgramsCheck",
      "",
      getRelativeDate("2023-12-03 07:18:33 -0400"),
      [
        {
          type: "button",
          value:
            "view revision history for fn_ActivePending_ClinicalProgramsCheck",
        },
        {
          type: "button",
          value: "clone fn_ActivePending_ClinicalProgramsCheck",
        },
      ],
    ]);
    testFilter("Business", [
      { type: "button", value: "checked out by me" },
      "CheckDecisionforEachLine",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
      getRelativeDate("2024-05-03 13:13:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for CheckDecisionforEachLine",
        },
        { type: "button", value: "clone CheckDecisionforEachLine" },
      ],
    ]);
    testSort(
      1,
      [
        "",
        "main",
        "",
        getRelativeDate("2024-05-23 13:47:33 -0400"),
        [
          { type: "button", value: "view revision history for main" },
          { type: "button", value: "clone main" },
        ],
      ],
      [
        { type: "button", value: "checked out by me" },
        "CheckDecisionforEachLine",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for CheckDecisionforEachLine",
          },
          { type: "button", value: "clone CheckDecisionforEachLine" },
        ],
      ],
    );
    testPagination(53, 53, ["fn_AuthCustomFieldChk", "", "", "", ""]);
    testColumnVisibility([
      "Lock Status",
      "Tags",
      "Last Committed",
      "Committed By",
      "Message",
    ]);
    toggleColumnVisibility("Tags", ["", "Name", "Last Committed", "Actions"]);
    toggleColumnVisibility(
      "Committed By",
      ["", "Name", "Tags", "Last Committed", "Committed By", "Actions"],
      [
        { type: "button", value: "checked out by me" },
        "CheckDecisionforEachLine",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        { type: "email", value: "mdickson@healthedge.com" },
        [
          {
            type: "button",
            value: "view revision history for CheckDecisionforEachLine",
          },
          { type: "button", value: "clone CheckDecisionforEachLine" },
          { type: "button", value: "delete function CheckDecisionforEachLine" },
        ],
      ],
    );
    toggleColumnVisibility(
      "Message",
      ["", "Name", "Tags", "Last Committed", "Message", "Actions"],
      [
        { type: "button", value: "checked out by me" },
        "CheckDecisionforEachLine",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        "probably messed something up",
        [
          {
            type: "button",
            value: "view revision history for CheckDecisionforEachLine",
          },
          { type: "button", value: "clone CheckDecisionforEachLine" },
          { type: "button", value: "delete function CheckDecisionforEachLine" },
        ],
      ],
    );
  });

  it("should sort alphanumerically after filtering", () => {
    // sort by name asc
    cy.getByTestId("dataTableHeader")
      .find("th:nth-child(2)")
      .as("columnHeader");
    cy.get("@columnHeader").find("button").click();
    testRow(0, [
      { type: "button", value: "checked out by me" },
      "CheckDecisionforEachLine",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
      getRelativeDate("2024-05-03 13:13:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for CheckDecisionforEachLine",
        },
        { type: "button", value: "clone CheckDecisionforEachLine" },
      ],
    ]);

    // test before filtering
    testRow(12, [
      "",
      "Fn_calculateBusinessDate",
      "",
      getRelativeDate("2023-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for Fn_calculateBusinessDate",
        },
        { type: "button", value: "clone Fn_calculateBusinessDate" },
      ],
    ]);

    // filter by "fn_" and check the row
    cy.getByTestId("dataTableFilterInput").type("fn_");
    cy.wait(510); // wait for 500ms debounce
    testRow(10, [
      "",
      "Fn_calculateBusinessDate",
      "",
      getRelativeDate("2023-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for Fn_calculateBusinessDate",
        },
        { type: "button", value: "clone Fn_calculateBusinessDate" },
      ],
    ]);
  });

  it("should sort tags case insensitively", () => {
    // sort by tags asc
    cy.getByTestId("dataTableHeader")
      .find("th:nth-child(3)")
      .as("columnHeader");
    cy.get("@columnHeader").find("button").click();

    testRow(4, [
      "",
      "fn_Active_WorkQueue_Chk",
      ["testCaseInsensitive"],
      getRelativeDate("2022-05-03 13:13:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for fn_Active_WorkQueue_Chk",
        },
        { type: "button", value: "clone fn_Active_WorkQueue_Chk" },
      ],
    ]);
    testRow(5, [
      "",
      "fn_admissionDateDischargedateCheck",
      ["TestCaseInsensitive"],
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for fn_admissionDateDischargedateCheck",
        },
        { type: "button", value: "clone fn_admissionDateDischargedateCheck" },
      ],
    ]);
  });

  it("should consider all tags in a row when sorting", () => {
    // sort by tags asc
    cy.getByTestId("dataTableHeader")
      .find("th:nth-child(3)")
      .as("columnHeader");
    cy.get("@columnHeader").find("button").click();

    testRow(1, [
      "",
      "CheckDecisionforEachLine",
      ["BusinessLibrary", "GCRE-123", "GCRE-456"],
      getRelativeDate("2024-05-03 13:13:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for CheckDecisionforEachLine",
        },
        { type: "button", value: "clone CheckDecisionforEachLine" },
      ],
    ]);
    testRow(2, [
      "",
      "fn_activeProgram_Check",
      ["BusinessLibrary", "GCRE-456", "GCRE-123"],
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for fn_activeProgram_Check",
        },
        { type: "button", value: "clone fn_activeProgram_Check" },
      ],
    ]);
  });

  it("deletes a function", () => {
    testDialog(cy.getGridRowButtonOrLink(0, 4, 2), "Delete Confirmation");
    openDialog(cy.getGridRowButtonOrLink(0, 4, 2));
    deleteArtifact();
  });

  it("navigates to edit a function", () => {
    cy.getGridRowButtonOrLink(0, 1).click();
    cy.url().should(
      "include",
      "/rule-designer/designer/functions/CheckDecisionforEachLine",
    );
  });

  it("navigates to add a function", () => {
    cy.getByTestId("addFunctionBtn").click();
    cy.url().should("include", "/rule-designer/designer/functions/_new");
  });

  it("displays revision history", () => {
    testRevisionHistoryDialogFromGrid(0, "CheckDecisionforEachLine", [
      { type: "checkbox", isChecked: false },
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
      { type: "email", value: "mdickson1@gmail.com" },
      "test",
      { type: "button", value: "Rollback to this revision" },
    ]);
    //test uncommitted version
    testRevisionCompareDialog(
      0,
      0,
      1,
      "CheckDecisionforEachLine (Function)",
      "",
      "",
      "",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
    );
    testRevisionCompareDialog(
      0,
      1,
      2,
      "CheckDecisionforEachLine (Function)",
      "429e207",
      getRelativeDate("2024-11-13 09:48:12 -0500"),
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
    );
    testRollback(0, 1);
    testRollback(1, 1, false);
  });

  it("clones a function", () => {
    testDialog(cy.getGridRowButtonOrLink(0, 4, 1), "Clone Function");
    openDialog(cy.getGridRowButtonOrLink(0, 4, 1));

    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled")
      .contains("Save & Commit");
    testFormField("filenameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false, {
      defaultValue: "cloned from CheckDecisionforEachLine",
    });
    cy.getByTestId("rulegroupInput").should("not.exist");

    // save without entering a name:
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testFormFieldValidation("filenameField", "Enter required field");
    testIsDialogDisplayed();

    // name with invalid characters:
    testNameFieldValidationWhenCloning();

    // try to save with a duplicate name:
    typeFormField("filenameInput", "duplicate");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testIsDialogDisplayed();
    testToast(
      ToastTitle.ERROR,
      "There was a problem saving the item. Name is not unique",
    );

    // save with a name:
    openDialog(cy.getGridRowButtonOrLink(0, 4, 1));
    typeFormField("filenameInput", "clonedFunction");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_CLONE, true);
  });

  it("should display the last committed date for migrated functions", () => {
    cy.wait(3000); // wait for the page to load
    testRow(11, [
      "",
      "fn_authEligibility",
      "",
      getRelativeDate("2025-04-23 21:07:36 -05:00"),
      [
        {
          type: "button",
          value: "view revision history for fn_authEligibility",
        },
        { type: "button", value: "clone fn_authEligibility" },
      ],
    ]);
  });

  it("should display the compilation errors after cloning a function", () => {
    openDialog(cy.getGridRowButtonOrLink(0, 4, 1));
    typeFormField("filenameInput", "newfn_1");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    cy.visit("/rule-designer/designer/functions/newfn_1");
    cy.getByTestId("viewCompileErrorsButton").should("exist");
  });
});
