import {
  clearFormField,
  testContentAssistedField,
  testDescriptionAddForm,
  testDescriptionEditForm,
  testFormField,
  testFormFieldValidation,
  testNameFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import {
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";
import {
  addCalculationVariable,
  checkAllFieldsInPropertiesPanel,
  checkPropertiesPanelandNodeValues,
  checkPropertiesPanelApplyButton,
  doubleClickNode,
  dragNodeFromPalette,
  getBranchOrder,
  getLatestNodesDataFromSessionStorage,
  getParentNode,
  nodes,
  openPropertiesPanel,
  testStartNode,
  verifyGraphIsReadonly,
} from "../../../utils/graph-utils";
import { NODE_X, NODE_Y } from "../../../utils/constants";
import { skipOn } from "@cypress/skip-test";
import {
  testAssociatedRecordsGrid,
  testAssociatedRecordsSheet,
} from "../../../utils/associated-records-utils";
import { deleteArtifact } from "../../../utils/utils";
import { testTable } from "../../../utils/grid-utils";
import {
  openDialog,
  submitDialog,
  testDialog,
} from "../../../utils/dialog-utils";
import { deleteAllText } from "../../../utils/monaco-utils";

describe("function", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/CheckDecisionforEachLine");
    cy.wait(1000); // need to wait for the graph to load before doing other things
    cy.emit("uncaught:exception", () => false);
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter(
      "CheckDecisionforEachLine",
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    );
    cy.testBrowserTitle("[CheckDecisionforEachLine] Function");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home", "Functions"]);
    cy.testSidebar("Designer", "Functions");
    cy.getByTestId("tags-container").should("exist");
  });

  it("edits description", () => {
    testDescriptionEditForm();
  });

  it("adds description", () => {
    // navigate to mock data function which doesn't already have a description value
    cy.visit("/rule-designer/designer/functions/fn_APEX_539_Rule");
    cy.wait(1000); // need to wait for the graph to load before doing other things
    testDescriptionAddForm();
  });

  it("test graph", () => {
    testStartNode("graphScreen");
  });

  it("tests Drag and Drop of the IF node in graph", () => {
    dragNodeFromPalette(nodes.If);
  });

  it("tests Drag and Drop of the FOR node in graph", () => {
    dragNodeFromPalette(nodes.For);
  });

  it("tests Drag and Drop of the Action node in graph", () => {
    dragNodeFromPalette(nodes.Action);
  });

  it("tests Drag and Drop of the Object node in graph", () => {
    dragNodeFromPalette(nodes.Object);
  });

  it("tests Drag and Drop of the Table node in graph", () => {
    dragNodeFromPalette(nodes.Table);
  });

  it("tests Drag and Drop of the Code node in graph", () => {
    dragNodeFromPalette(nodes.Code);
  });

  it("tests Drag and Drop of the Return node in graph", () => {
    dragNodeFromPalette(nodes.Return);
  });

  it("tests Drag and Drop of the Invoke node in graph", () => {
    dragNodeFromPalette(nodes.Invoke);
  });

  it("tests cancel button on the function screen", () => {
    cy.getByTestId("cancelBtn").click({ force: true });
    cy.wait(1000);
    cy.url().should("include", "/rule-designer/designer/functions");
  });

  /*
   *  Test case for Node Context Menu - Start node
   *
   */
  describe("Node Context Menu - Start node", () => {
    it("should right-click on start node in the canvas, and verify it has only edit properties and delete sub-tree options visible", () => {
      cy.getByTestId("mainGraphCanvas").then(($canvas) => {
        const canvas = $canvas[0];
        const startNodeX = 10 + NODE_X;
        const startNodeY = 10 + NODE_Y;

        cy.wrap(canvas).trigger("mousemove", {
          focus: true,
          x: startNodeX,
          y: startNodeY,
        });

        cy.wrap(canvas).rightclick(startNodeX, startNodeY);

        cy.getByTestId("editNode").should("exist");
        cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
        cy.getByTestId("deleteNode").should("not.exist");
        cy.getByTestId("deleteNodeSubTree").should("exist");
      });
    });
  });

  /*
   *  Test case for Node Context Menu - Non-start nodes
   *
   */
  describe("Node Context Menu - non start nodes", () => {
    it("should right-click on non-start node in the canvas, and verify it has all edit properties option and delete options", () => {
      cy.wait(2000);
      cy.getByTestId("mainGraphCanvas").then(($canvas) => {
        const canvas = $canvas[0];
        const nodeX = 210 + NODE_X;
        const nodeY = 110 + NODE_Y;

        cy.wrap(canvas).trigger("mousemove", {
          focus: true,
          x: nodeX,
          y: nodeY,
        });

        cy.wrap(canvas).rightclick(nodeX, nodeY);

        cy.getByTestId("editNode").should("exist");
        cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
        cy.getByTestId("deleteNode").should("exist");
        cy.getByTestId("deleteNodeAndSubTree").should("exist");
      });
    });
  });

  it("tests properties panel opening", () => {
    let node = {
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    checkAllFieldsInPropertiesPanel(node);
  });

  it("should display fields in properties panel as per the node details", () => {
    let node = {
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    checkAllFieldsInPropertiesPanel(node);
  });

  it("modify the Description and save properties panel changes", () => {
    let node = {
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    cy.getByTestId("varDescriptionTextArea").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("exist").should("be.disabled");
    cy.getByTestId("varDescriptionTextArea").type("test description");
    cy.getByTestId("propsPanelApplyBtn")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("should close properties panel", () => {
    let node = {
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    cy.getByTestId("propsPanelCancelBtn").should("exist");
    cy.getByTestId("propsPanelCancelBtn")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("propsPanelCancelBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("should test properties panel pending changes and apply button enablement", () => {
    let node = {
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    cy.getByTestId("nodeNameInput").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("exist").should("be.disabled");
    cy.getByTestId("nodeNameInput").click();
    cy.getByTestId("nodeNameInput").type("testName");
    cy.getByTestId("propsPanelApplyBtn")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("propsPanelCancelBtn").click();
    openPropertiesPanel(node);
    cy.wait(1000);
    cy.getByTestId("propsPanelApplyBtn").should("exist").should("be.disabled");

    cy.getByTestId("deleteVariableBtn").should("exist");
    cy.getByTestId("deleteVariableBtn").first().scrollIntoView();
    cy.getByTestId("deleteVariableBtn").first().click();
    cy.wait(500);
    //check for Delete Confirmation Dialog
    cy.getByTestId("dialog-container").should("exist");

    // Confirm deletion
    cy.getByTestId("dialog-destructive-button").click();
    cy.wait(500);
    cy.getByTestId("propsPanelApplyBtn")
      .should("exist")
      .should("not.be.disabled");
  });

  it("tests if a calculation variable can be added in fullscreen mode when none exists already and still present on restore", () => {
    cy.wait(2000);
    cy.getByTestId("if-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });

    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 400 + NODE_X,
        y: 100 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        focus: true,
        x: 400 + NODE_X,
        y: 100 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        focus: true,
        x: 400 + NODE_X,
        y: 100 + NODE_Y,
      });
      cy.wrap(canvas).dblclick(420 + NODE_X, 120 + NODE_Y);
      cy.getByTestId("calculationVariableAccordian").should("exist");
      cy.getByTestId("calVarGridMaximizeBtn").should("exist").click();
      cy.getByTestId("calVarGridMinimizeBtn").should("exist");
      cy.wait(1000);
      cy.getByTestId("addGlobalVariableBtn").should("exist");
      cy.getByTestId("addGlobalVariableBtn").scrollIntoView();
      cy.getByTestId("addGlobalVariableBtn").click();
      cy.getByTestId("dialog-container").should("exist");

      cy.getByTestId("varNameField")
        .should("exist")
        .type("param_decisionToChk");
      cy.wait(500);
      cy.getByTestId("varTypeInput").select("ActAlert");
      cy.getByTestId("arrayInput").should("exist").click();
      cy.getByTestId("initExprField")
        .find(".monaco-scrollable-element")
        .find(".lines-content")
        .find(".view-line")
        .type("test");

      cy.getByTestId("dialog-submit-button").should("exist").click();
      cy.wait(500);
      cy.getByTestId("calVarGridMinimizeBtn").should("exist").click();

      testTable(
        ["Name", "Type", "Value", "Is Array?", "Actions"],
        [
          "param_decisionToChk",
          "ActAlert",
          "test",
          {
            type: "icon",
            value: "check",
            screenReaderText: "item is an array",
          },
          "",
        ],
      );
    });
  });

  it("renames a calculation variable", () => {
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];

      // double click the 2nd "if param_checkType" node to open properties panel
      cy.wrap(canvas).dblclick(220 + NODE_X, 330 + NODE_Y);

      cy.getByTestId("calculationVariableAccordian").should("exist");
      // eslint-disable-next-line cypress/no-assigning-return-values
      const triggerBtn = cy.getGridRowButtonOrLink(0, 0);
      testDialog(triggerBtn, "Edit Calculation Variable");
      openDialog(triggerBtn);

      testFormField("varNameField", "Name", true, { expectDisabled: false });
      cy.getByTestId("varNameDescription").should("not.exist");
      testFormField("varTypeField", "Type", true, { expectDisabled: false });
      testFormField("varArrayField", "Is Array?", false, {
        isCheckbox: true,
        expectDisabled: false,
      });
      cy.getByTestId("initExprField").should("exist");
      testTable(
        ["Name", "Type", "Value", "Is Array?", "Actions"],
        [
          "param_decisionToChk",
          "String",
          '"test"',
          {
            type: "icon",
            value: "check",
            screenReaderText: "item is an array",
          },
          "",
        ],
      );

      // test renaming to something that already exists
      cy.getByTestId("varNameInput").clear();
      cy.getByTestId("varNameDescription")
        .should("exist")
        .contains(
          "Beware that renaming a variable could cause compilation errors if being referenced.",
        );
      typeFormField("varNameInput", "param_checkType");
      submitDialog();
      testToast(ToastTitle.ERROR, ToastMessage.ERROR_DUPLICATE);
      testTable(
        ["Name", "Type", "Value", "Is Array?", "Actions"],
        [
          "param_decisionToChk",
          "String",
          '"test"',
          {
            type: "icon",
            value: "check",
            screenReaderText: "item is an array",
          },
          "",
        ],
      );

      // test renaming to something that doesn't exist
      openDialog(triggerBtn);
      cy.getByTestId("varNameInput").clear();
      typeFormField("varNameInput", "renamedVar");
      submitDialog();
      testTable(
        ["Name", "Type", "Value", "Is Array?", "Actions"],
        [
          "renamedVar",
          "String",
          '"test"',
          {
            type: "icon",
            value: "check",
            screenReaderText: "item is an array",
          },
          "",
        ],
      );
    });
  });

  it("should open the properties panel of the start node and test if arguments and return type can be added + edited", () => {
    cy.wait(3000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];

      const startNodeX = NODE_X;
      const startNodeY = NODE_Y;

      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: startNodeX,
        y: startNodeY,
      });
      cy.wrap(canvas).dblclick(startNodeX, startNodeY);
      cy.getByTestId("propertiesPanel").should("exist");

      //make sure the apply button is disabled - GCRE-2782
      cy.getByTestId("propsPanelApplyBtn")
        .should("exist")
        .should("be.disabled");

      cy.getByTestId("argumentsAccordionTrigger").should("exist");
      cy.getByTestId("argumentsAccordionTrigger").scrollIntoView();
      cy.getByTestId("addArgumentBtn").should("exist");
      cy.getByTestId("addArgumentBtn").scrollIntoView();
      cy.getByTestId("addArgumentBtn").click();
      cy.wait(1000);

      cy.getByTestId("dialog-cancel-button")
        .should("exist")
        .should("not.be.disabled");

      //Name
      cy.getByTestId("varNameLabel").should("contain.text", "Name");
      cy.getByTestId("varNameInput").should("exist");
      cy.getByTestId("varNameInput").type("testName");
      //Type
      cy.getByTestId("argTypeLabel").should("contain.text", "Type");
      cy.getByTestId("argTypeInput").should("exist");
      cy.getByTestId("argTypeInput").select("ActAuthActivity");
      cy.getByTestId("varArrayInput").should("exist");
      cy.getByTestId("varArrayInput").click({ force: true });
      cy.getByTestId("dialog-submit-button")
        .should("exist")
        .should("not.be.disabled");
      cy.getByTestId("dialog-submit-button").click();
      cy.getByTestId("dialog-container").should("not.exist");
      cy.getByTestId("returnTypeInput").should("exist").select("boolean");

      cy.getByTestId("argumentsAccordionTrigger").click();
      cy.wait(500);
      cy.getByTestId("argumentsAccordionTrigger").click();
      cy.get("table tbody tr")
        .eq(2)
        .should("contain.text", "testNameActAuthActivityitem is an array");

      //rename the argument
      // eslint-disable-next-line cypress/no-assigning-return-values
      const triggerBtn = cy.getGridRowButtonOrLink(0, 0);
      testDialog(triggerBtn, "Edit Argument");

      openDialog(triggerBtn);
      cy.getByTestId("varNameInput").clear();
      typeFormField("varNameInput", "testNameUpdated");
      submitDialog();
      testTable(
        ["Name", "Type", "Is Array?", "Actions"],
        ["testNameUpdated", "String", "", ""],
      );
      cy.getByTestId("arrayInput").should("exist").should("not.be.disabled");

      cy.getByTestId("propsPanelApplyBtn").click();

      cy.wrap(canvas).trigger("mousedown", {
        focus: true,
        x: startNodeX,
        y: startNodeY,
      });

      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: startNodeX + 10,
        y: startNodeY,
      });
      cy.wait(1000);
      cy.window().then(() => {
        const graphMetaData: any = JSON.parse(
          window.sessionStorage.getItem("graphMetaData"),
        );
        expect(graphMetaData).to.not.be.undefined;
        expect(graphMetaData).to.have.property("argInfo");
        expect(graphMetaData.argInfo).to.have.length(3);
        expect(graphMetaData.argInfo[0]).to.have.property("varName");
        expect(graphMetaData.argInfo[0]).to.have.property("varType");
        expect(graphMetaData.argInfo[0].varName).to.equal("testNameUpdated");
        expect(graphMetaData.argInfo[0].varType).to.equal("String");
        expect(graphMetaData.returnType).to.equal("boolean");
        expect(graphMetaData.isArray).to.equal(false);
      });

      //test if the graph metadata is still present after editing any other node in the graph
      cy.getByTestId("code-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: 270 + NODE_X,
        y: NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 390 + NODE_X,
        y: NODE_Y,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 390 + NODE_X,
        y: NODE_Y,
      });

      cy.wait(200);
      cy.wrap(canvas).dblclick(390 + NODE_X, NODE_Y + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(1000);
      cy.getByTestId("varDescriptionTextArea").should("exist");
      cy.getByTestId("varDescriptionTextArea").type("test description");
      cy.getByTestId("codeExpression")
        .find(".monaco-scrollable-element")
        .find(".lines-content")
        .find(".view-line")
        .type("true");
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");

      cy.wrap(canvas).dblclick(startNodeX, startNodeY);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("argumentsAccordionTrigger").should("exist");
      cy.getByTestId("argumentsAccordionTrigger").scrollIntoView();
      cy.get("table tbody tr")
        .eq(0)
        .should("contain.text", "testNameUpdatedString");
      cy.getByTestId("returnTypeInput").should("contain.text", "boolean");
    });
  });

  it("should open the calculation variable add dialog and allow adding a new variable and test isArray column is present in the grid", () => {
    let node = {
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    addCalculationVariable(false);
  });

  it("should delete a Calculation variable item if user confirm delete", () => {
    let node = {
      variables: [
        {
          varName: "param_decisionToChk",
          varType: "string",
        },
        {
          varName: "param_checkType",
          varType: "string",
        },
      ],
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    cy.wait(2000);

    //check for delete button
    cy.getByTestId("deleteVariableBtn").should("exist");
    cy.getByTestId("deleteVariableBtn").first().scrollIntoView();
    cy.getByTestId("deleteVariableBtn").first().click();
    cy.wait(500);
    //check for Delete Confirmation Dailog
    cy.getByTestId("dialog-container").should("exist");

    // Confirm deletion
    cy.getByTestId("dialog-destructive-button").click();
    cy.wait(500);
    // Verify the row is deleted
    cy.get("table tbody tr").should("have.length", 1); // One row left
    cy.get("table tbody tr")
      .eq(0)
      .should("contain.text", node.variables[1].varName);
  });

  it("should not delete a Calculation variable item if user cancel delete confirmation", () => {
    let node = {
      variables: [
        {
          varName: "param_decisionToChk",
          varType: "string",
        },
        {
          varName: "param_checkType",
          varType: "string",
        },
      ],
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    cy.wait(2000);

    //check for delete button
    cy.getByTestId("deleteVariableBtn").should("exist");
    cy.getByTestId("deleteVariableBtn").first().scrollIntoView();
    cy.getByTestId("deleteVariableBtn").first().click();
    cy.wait(500);
    //check for Delete Confirmation Dailog
    cy.getByTestId("dialog-container").should("exist");

    // cancel deletion
    cy.getByTestId("dialog-cancel-button").click();
    cy.wait(500);
    // Verify the row is deleted
    cy.get("table tbody tr").should("have.length", 2);
    cy.get("table tbody tr")
      .eq(0)
      .should("contain.text", node.variables[0].varName);
    cy.get("table tbody tr")
      .eq(1)
      .should("contain.text", node.variables[1].varName);
  });

  it("should reorder Calculation variable table items", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(3000);
    cy.emit("uncaught:exception", () => false);
    const nodeDetails = {
      varName: "complaint1",
      varType: "Complaint",
      variables: [
        {
          varType: "Date",
          varName: "aGoodCauseReceivedDate",
          initExpr: "",
        },
        {
          varType: "String",
          varName: "tempString",
          initExpr: "",
        },
        {
          varType: "int",
          varName: "spaceCounter",
          initExpr: "",
        },
      ],
      name: "for complaints",
      x: 210 + NODE_X,
      _endCharPos: 1838,
      y: 110 + NODE_Y,
      id: "163",
      source: "theRequest.complaints",
      type: "FOR",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "217",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(nodeDetails);
    cy.getByTestId("calculationVariableAccordian").scrollIntoView();
    cy.wait(500);
    cy.get("table tbody tr")
      .eq(0)
      .should("contain.text", nodeDetails.variables[0].varName);
    cy.get("table tbody tr")
      .eq(1)
      .should("contain.text", nodeDetails.variables[1].varName);

    cy.get("table tbody tr").eq(0).find("button").eq(2).click();
    cy.wait(500);

    // Verify order is swapped
    cy.get("table tbody tr")
      .eq(0)
      .should("contain.text", nodeDetails.variables[1].varName);
    cy.get("table tbody tr")
      .eq(1)
      .should("contain.text", nodeDetails.variables[0].varName);

    cy.get("table tbody tr").eq(1).find("button").eq(3).click();
    cy.wait(500);
    // Verify order is swapped to original
    cy.get("table tbody tr")
      .eq(0)
      .should("contain.text", nodeDetails.variables[0].varName);
    cy.get("table tbody tr")
      .eq(1)
      .should("contain.text", nodeDetails.variables[1].varName);
  });

  it("tests opening properties panel for IF node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.If,
      name: nodes.If,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };

    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for FOR node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.For,
      name: nodes.For,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for ACTION node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Action,
      name: nodes.Action,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests the action fields dropdown based on the selected variable type", () => {
    cy.getByTestId(`action-shape`).should("exist");
    cy.wait(1000);
    const draggable = `action-shape`;
    cy.getByTestId(draggable).trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 470 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).rightclick(570 + NODE_X, NODE_Y + 50);
      cy.getByTestId("viewNodeInTab").should("not.exist");
      cy.getByTestId("editNode").should("exist").click();
      cy.wait(2000);
      cy.getByTestId("propertiesPanel").should("exist");
    });
    cy.wait(500);
    const expectedSelectOptions = [
      "Select one",
      "ActActivity",
      "ActAidSupplemental",
      "ActAlert",
      "ActAssignment",
      "ActAuthActivity",
      "ActAuthAssignment",
      "ActAuthProvider",
      "ActAuthRequest",
      "ActAuthServiceLine",
      "ActCareTeam",
      "ActClinicalProgram",
      "ActComplaint",
      "ActComplaintActivity",
      "ActComplaintAssignment",
      "ActCondition",
      "ActCustomField",
      "ActDeleteActivity",
      "ActDeleteAlert",
      "ActDeleteExternalCareTeam",
      "ActDeleteProgram",
      "ActDeleteRisk",
      "ActDeleteServicePlan",
      "ActDocument",
      "ActEligibility",
      "ActHealthNote",
      "ActIndicator",
      "ActInterQual",
      "ActKeyValue",
      "ActLetter",
      "ActMemberDemographic",
      "ActMemberSchedule",
      "ActMessage",
      "ActNote",
      "ActOGI",
      "ActOpportunity",
      "ActProcedureCode",
      "ActProfileKeyword",
      "ActProgram",
      "ActRisk",
      "ActRoundRobinAuthAssignment",
      "ActServiceInterruption",
      "ActUIControlData",
      "ActWarning",
      "AuthCustom",
      "ScheduleInfo",
    ];
    testFormField("varTypeField", "Variable Type", true, {
      expectedSelectOptions: expectedSelectOptions,
      numSelectOptionsToTest: 46,
    });
    cy.getByTestId("varTypeInput").select("ActAlert");
    cy.getByTestId("actionFieldsAccordian").should("exist");
    cy.getByTestId("actionFieldsAccordian").click();
    cy.getByTestId("actionFieldsAccordian").scrollIntoView();
    cy.getByTestId("addActionFieldBtn").should("exist");
    cy.getByTestId("addActionFieldBtn").click();
    cy.getByTestId("valueInput").select("alertSource");
  });

  it("tests opening properties panel for TABLE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Table,
      name: nodes.Table,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for CODE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Code,
      name: nodes.Code,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for OBJECT node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Object,
      name: nodes.Object,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for RETURN node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Return,
      name: nodes.Return,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for INVOKE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Invoke,
      name: nodes.Invoke,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests Apply Button functionality properties panel for INVOKE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Invoke,
      name: nodes.Invoke,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };

    cy.getByTestId(`${newNode.name.toLowerCase()}-shape`).should("exist");
    cy.wait(1000);
    const draggable = `${newNode.name.toLowerCase()}-shape`;
    cy.getByTestId(draggable).trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });

    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 470 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).rightclick(570 + NODE_X, NODE_Y + 50);
      cy.getByTestId("viewNodeInTab").should("not.exist");
      cy.getByTestId("editNode").should("exist").click();
      cy.wait(2000);
      cy.getByTestId("propertiesPanel").should("exist");
    });
    cy.wait(1000);
    cy.getByTestId("propsPanelApplyBtn").should("exist");
    cy.getByTestId("nodeNameInput").should("exist");
    cy.getByTestId("nodeNameInput").clear();
    cy.getByTestId("nodeNameInput").type("CheckDecisionforEachLine");
    cy.getByTestId("invokeTargetInput").click();
    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    //check the required filed shouldn't have invalid class
    cy.getByTestId("invokeTargetLabel").and(
      "not.have.class",
      "text-destructive",
    );
    cy.getByTestId("propsPanelApplyBtn").click();

    cy.getByTestId("invokeTargetInput").should("exist");
    cy.getByTestId("invokeTargetLabel").should("exist");
    //check the required filed has invalid class
    cy.getByTestId("invokeTargetLabel").and("have.class", "text-destructive");
    cy.getByTestId("invokeTargetField").contains("Enter required field");

    cy.getByTestId("invokeTargetInput").click();
    cy.get('div[data-value="checkdecisionforeachline"]').should("exist");
    cy.get('div[data-value="checkdecisionforeachline"]').click();
    cy.get("button").should("contain", "CheckDecisionforEachLine");

    cy.wait(500);
    cy.getByTestId("invokeTargetInput").click();
    cy.get('div[data-value="entrypointfn"]').should("exist");
    cy.get('div[data-value="entrypointfn"]').click();
    cy.get("button").should("contain", "entryPointFn");

    //test when a non-functional/non-existent invoke target value is selected and page doesn't navigate to page-not-found
    cy.wait(1000);
    cy.url().should(
      "include",
      "/rule-designer/designer/functions/CheckDecisionforEachLine",
    );

    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");

    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(570 + NODE_X, NODE_Y + 50);
      cy.getByTestId("viewNodeInTab").should("exist");
      cy.getByTestId("viewNodeInTab").click();
      cy.wait(2000);
      cy.getByTestId("CheckDecisionforEachLine")
        .should("exist")
        .click({ multiple: true });
    });
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y + 50,
        force: true,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 570 + NODE_X,
        y: NODE_Y + 50,
        force: true,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y + 100,
        force: true,
      });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const invokeNode = nodesData[nodesData.length - 1];
        expect(invokeNode).to.not.be.undefined;
        expect(invokeNode.type).to.equal(nodes.Invoke);
        expect(invokeNode.isSelected).to.equal(true);
      });
    });
  });

  it("tests Apply Button functionality properties panel for IF node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.If,
      name: nodes.If,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelApplyButton(newNode);
    cy.getByTestId("propsPanelApplyBtn").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("be.disabled");
    //check the required filed shouldn't have invalid class

    cy.getByTestId("nodeTypeItem").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
    cy.getByTestId("nodeTypeInput").should("have.value", nodes.If);

    cy.getByTestId("nodeNameInput").should("exist");
    cy.getByTestId("nodeNameInput").should("exist").should("not.be.disabled");
    cy.getByTestId("nodeNameInput").should("have.value", nodes.If);

    //condition
    cy.getByTestId("ifCondition")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("theRequest.complaints !== null");

    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("tests Apply Button functionality properties panel for FOR node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.For,
      name: nodes.For,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelApplyButton(newNode);
    cy.getByTestId("propsPanelApplyBtn").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("be.disabled");

    cy.getByTestId("nodeNameInput").should("exist").clear();
    cy.getByTestId("nodeNameInput").type("for complaints");
    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();

    //check the required filed shouldn't have invalid class
    cy.getByTestId("varTypeLabel").and("not.have.class", "text-destructive");

    cy.getByTestId("nodeTypeItem").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
    cy.getByTestId("nodeTypeInput").should("have.value", nodes.For);

    cy.getByTestId("nodeNameInput").should("have.value", "for complaints");
    //source
    cy.getByTestId("forSource")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("theRequest.complaints");

    //Variable Type field
    cy.getByTestId("varTypeInput").should("exist");
    cy.getByTestId("varTypeLabel").should("exist");

    //Variable Name field
    cy.getByTestId("varNameLabel").should("exist");
    cy.getByTestId("varNameInput").click();

    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("exist");
    cy.getByTestId("errorMessage")
      .should("exist")
      .should(
        "contain.text",
        "Variable Name is required when Source is provided.",
      );

    cy.getByTestId("varNameInput").type("test123");

    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");

    cy.getByTestId("forSource")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("theRequest.compl");

    cy.getByTestId("propsPanelCancelBtn").click();
    checkPropertiesPanelApplyButton(newNode);
    cy.wait(500);
    cy.getByTestId("forSource")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("theRequest.complaints");
    cy.getByTestId("varNameInput").type("test123");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("tests Apply Button functionality properties panel for ACTION node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Action,
      name: nodes.Action,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelApplyButton(newNode);
    cy.getByTestId("propsPanelApplyBtn").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("be.disabled");
    //check the required filed shouldn't have invalid class
    cy.getByTestId("nodeTypeItem").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
    cy.getByTestId("nodeTypeInput").should("have.value", nodes.Action);

    cy.getByTestId("nodeNameInput").should("exist");
    cy.getByTestId("nodeNameInput").should("exist").should("not.be.disabled");
    cy.getByTestId("nodeNameInput").should("have.value", nodes.Action);

    //Variable Type field
    cy.getByTestId("varTypeInput").should("exist");
    cy.getByTestId("varTypeLabel").should("exist");
    //check the required filed has invalid class
    cy.getByTestId("varTypeInput").select("ActActivity");

    //Variable Name field
    cy.getByTestId("varNameLabel").should("exist");
    cy.getByTestId("varNameInput").click();
    cy.getByTestId("varNameInput").type("test123");

    cy.getByTestId("assignTarget")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("env");

    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("should test if the variable type value is retained and not set to blank when source value is edited in FOR node", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(3000);
    cy.emit("uncaught:exception", () => false);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 350,
        y: 180,
      });
      cy.wrap(canvas).dblclick(350, 180);
      cy.wait(1000);
      cy.getByTestId("propertiesPanel").should("exist");
    });
    cy.wait(2000);
    //verify the variable type value is present
    cy.getByTestId("varTypeInput")
      .should("exist")
      .should("have.value", "Complaint");
    //edit the source value
    cy.getByTestId("forSource")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type(".abc");
    //verify the variable type value is still present
    cy.getByTestId("varTypeInput")
      .should("exist")
      .should("have.value", "Complaint");
    //delete the source value
    const backSpaces1 = "{backspace}".repeat(3);
    cy.getByTestId("forSource")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type(backSpaces1);
    cy.getByTestId("varTypeInput")
      .should("exist")
      .should("have.value", "Complaint");
    //remove until the dot and verify the variable type value is still present and set to Request
    const backSpaces2 = "{backspace}".repeat(11);
    cy.getByTestId("forSource")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type(backSpaces2);
    cy.getByTestId("varTypeInput")
      .should("exist")
      .should("have.value", "Request");
    //delete the entire source value and verify the variable type is set to blank
    cy.getByTestId("forSource")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type(backSpaces2);
    cy.getByTestId("varTypeInput").should("exist").should("have.value", "");
  });

  it("should test if the action fields can be added and edited in the properties panel along with the type info", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(1000);
    cy.emit("uncaught:exception", () => false);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wait(2000);
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 1010 + NODE_X,
        y: 310 + NODE_Y,
      });
      cy.wrap(canvas).dblclick(1010 + NODE_X, 310 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.once("uncaught:exception", () => false);
      cy.wait(2000);
    });
    cy.wait(2000);

    cy.getByTestId("actionFieldsAccordian").should("exist");
    cy.getByTestId("actionFieldsAccordian").scrollIntoView();

    cy.getByTestId("addActionFieldBtn").should("exist").click();
    cy.getByTestId("valueInput").select("assignFromRule");
    cy.getByTestId("varTypeField")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("true");
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("dialog-submit-button").click();

    cy.getByTestId("actionFieldsAccordian").click();
    cy.wait(500);
    cy.getByTestId("actionFieldsAccordian").click();

    //verify if the grid has the newly added action field along with the type info
    cy.getByTestId("dataTableContainer")
      .eq(0)
      .find("tr")
      .eq(3)
      .find("td")
      .eq(0)
      .should("contain.text", "Boolean");

    cy.getByTestId("dataTableContainer")
      .eq(0)
      .find("tbody")
      .eq(0)
      .find("tr")
      .eq(0)
      .find("th")
      .eq(0)
      .click();
    cy.getByTestId("valueInput").should("exist").should("be.disabled");
    cy.getByTestId("varTypeField").find(".mtk1").type("1");

    //just making sure the dialog is still open (GCRE-857_Unable to Edit Action Fields in ACTION Nodes)
    cy.getByTestId("dialog-form-container").should("exist");

    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("dialog-submit-button").click();
    cy.getByTestId("dialog-container").should("not.exist");

    cy.getByTestId("dataTableContainer")
      .eq(0)
      .find("tr")
      .eq(1)
      .find("td")
      .eq(1)
      .should("contain.text", "customField21.complaintID");
  });

  it("should display the mandatory field validation while saving the action fields", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(1000);
    cy.emit("uncaught:exception", () => false);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wait(3000);
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 1010 + NODE_X,
        y: 310 + NODE_Y,
      });
      cy.wrap(canvas).dblclick(1010 + NODE_X, 310 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.once("uncaught:exception", () => false);
      cy.wait(2000);
    });
    cy.getByTestId("actionFieldsAccordian").should("exist");
    cy.getByTestId("actionFieldsAccordian").scrollIntoView();
    cy.getByTestId("addActionFieldBtn").should("exist").click();
    cy.getByTestId("valueInput").select("assignFromRule");
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("dialog-submit-button").click();
    cy.getByTestId("errorMessage").contains("Enter required field");
  });

  it("tests Apply Button functionality properties panel for CODE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Code,
      name: nodes.Code,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelApplyButton(newNode);
    cy.getByTestId("propsPanelApplyBtn").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("be.disabled");
    //check the required filed shouldn't have invalid class
    cy.getByTestId("nodeTypeItem").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
    cy.getByTestId("nodeTypeInput").should("have.value", nodes.Code);

    cy.getByTestId("nodeNameInput").should("exist");
    cy.getByTestId("nodeNameInput").should("exist").should("not.be.disabled");
    cy.getByTestId("nodeNameInput").should("have.value", nodes.Code);

    cy.getByTestId("nodeNameInput").clear();
    cy.getByTestId("nodeNameInput").type("testName");

    cy.getByTestId("codeExpression")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("true");

    cy.getByTestId("nodeNameInput").should("have.value", "testName");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("tests Apply Button functionality properties panel for OBJECT node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Object,
      name: nodes.Object,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelApplyButton(newNode);
    cy.getByTestId("propsPanelApplyBtn").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("be.disabled");

    //check the required field shouldn't have invalid class
    cy.getByTestId("varTypeLabel").and("not.have.class", "text-destructive");
    cy.getByTestId("varNameLabel").and("not.have.class", "text-destructive");

    cy.getByTestId("varTypeLabel").and("not.have.class", "text-destructive");
    cy.getByTestId("nodeTypeItem").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
    cy.getByTestId("nodeTypeInput").should("have.value", nodes.Object);

    cy.getByTestId("nodeNameInput").should("exist");
    cy.getByTestId("nodeNameInput").should("exist").should("not.be.disabled");
    cy.getByTestId("nodeNameInput").should("have.value", nodes.Object);

    //Variable Type field
    cy.getByTestId("varTypeInput").should("exist");
    cy.getByTestId("varTypeLabel").should("exist");
    cy.getByTestId("varTypeInput").select("ActActivity");

    //Variable Name field
    cy.getByTestId("varNameLabel").should("exist");
    cy.getByTestId("varNameInput").click();
    cy.getByTestId("varNameInput").type("test123");

    cy.getByTestId("assignTarget")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("env");

    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("tests Apply Button functionality properties panel for RETURN node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Return,
      name: nodes.Return,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelApplyButton(newNode);
    cy.wait(2000);
    cy.getByTestId("propsPanelApplyBtn").should("exist");
    cy.getByTestId("propsPanelApplyBtn").should("be.disabled");
    //there are no required fields

    cy.getByTestId("nodeTypeItem").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist");
    cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
    cy.getByTestId("nodeTypeInput").should("have.value", nodes.Return);

    cy.getByTestId("nodeNameInput").should("exist");
    cy.getByTestId("nodeNameInput").should("exist").should("not.be.disabled");
    cy.getByTestId("nodeNameInput").should("have.value", nodes.Return);

    cy.getByTestId("swcRetExpression")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("theRequest.complaints");

    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("should test if a node's branch order is correctly displayed when moved from a false to true trunk and also its old siblings got correct order as well", () => {
    skipOn("firefox");
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(2000);
    cy.getByTestId(`${nodes.Code.toLowerCase()}-shape`).should("exist");
    const draggable = `${nodes.Code.toLowerCase()}-shape`;

    //add two code nodes to the false trunk of an IF node
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.getByTestId(draggable).trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: 580,
        y: 250,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 690,
        y: 80,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 690,
        y: 80,
      });

      cy.getByTestId(draggable).trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: 580,
        y: 250,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 690,
        y: 140,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 690,
        y: 140,
      });

      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const secondNodeAdded = nodesData[nodesData.length - 1];
        expect(secondNodeAdded).to.not.be.undefined;
        expect(secondNodeAdded.type).to.equal(nodes.Code);
        const parentNode = getParentNode(secondNodeAdded, nodesData);
        expect(parentNode).to.not.be.undefined;
        //verify if the branch order is correct
        const currentNodeBranchOrder = getBranchOrder(
          secondNodeAdded,
          parentNode,
        );
        expect(currentNodeBranchOrder).to.equal(1);
      });

      //move the new node to the true trunk
      cy.wrap(canvas).trigger("mousedown", {
        x: 690,
        y: 140,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 580,
        y: 300,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 450,
        y: 450,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 450,
        y: 450,
      });
      cy.wait(100);
      cy.wrap(canvas).trigger("mousedown", {
        x: 450,
        y: 450,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 450,
        y: 460,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 450,
        y: 460,
      });
      cy.wait(100);
      cy.window().then((win) => {
        //get nodes from session storage after node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const secondNodeAdded = nodesData[nodesData.length - 1];
        expect(secondNodeAdded).to.not.be.undefined;
        expect(secondNodeAdded.type).to.equal(nodes.Code);
        const parentNode = getParentNode(secondNodeAdded, nodesData);
        expect(parentNode).to.not.be.undefined;
        //verify if the branch order is correct after moving to the true trunk
        const currentNodeBranchOrder = getBranchOrder(
          secondNodeAdded,
          parentNode,
        );
        expect(currentNodeBranchOrder).to.equal(2);
        //verify if the old sibling's branch order is correct
        const firstNodeAdded = nodesData[nodesData.length - 2];
        expect(firstNodeAdded).to.not.be.undefined;
        expect(firstNodeAdded.type).to.equal(nodes.Code);
        const firstNodeBranchOrder = getBranchOrder(firstNodeAdded, parentNode);
        expect(firstNodeBranchOrder).to.equal(1);
      });
    });
  });

  it("test if a node is deleted on choosing `Delete Node` option from context-menu ", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const forComplaintsNodePosition = { x: 210 + NODE_X, y: 110 + NODE_Y };
      cy.wrap(canvas).rightclick(
        forComplaintsNodePosition.x,
        forComplaintsNodePosition.y,
      );
      cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("deleteNode").should("exist").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const deletedNodeExists = nodesData.some((node) => node.id === "163");
        expect(deletedNodeExists).to.be.false;
      });
    });
  });

  it("test if a node and its children are deleted on choosing `Delete Node + Subtree` option from context-menu ", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(2000);
    cy.emit("uncaught:exception", () => false);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const forComplaintsNodePosition = { x: 210 + NODE_X, y: 110 + NODE_Y };
      cy.wrap(canvas).rightclick(
        forComplaintsNodePosition.x,
        forComplaintsNodePosition.y,
      );
      cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("deleteNodeAndSubTree").should("exist").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const deletedNodeExists = nodesData.some((node) => node.id === "163");
        expect(deletedNodeExists).to.be.false;
        //since we've deleted the FOR complaints node and its children, there should be only 1 node left (start node) in the graph
        expect(nodesData.length).to.equal(1);
      });
    });
  });

  it("should test undo and redo features", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(3000);
    cy.emit("uncaught:exception", () => false);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const forComplaintsNodePosition = { x: 210 + NODE_X, y: 110 + NODE_Y };

      //move for complaints node to a new position to enable undo and redo
      cy.wrap(canvas).trigger("mousemove", {
        x: forComplaintsNodePosition.x,
        y: forComplaintsNodePosition.y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: forComplaintsNodePosition.x,
        y: forComplaintsNodePosition.y,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: forComplaintsNodePosition.x + 100,
        y: forComplaintsNodePosition.y + 100,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: forComplaintsNodePosition.x + 100,
        y: forComplaintsNodePosition.y + 100,
      });

      //test undo
      cy.getByTestId("undoButton").should("exist");
      cy.getByTestId("undoButton").should("not.be.disabled");
      cy.getByTestId("undoButton").click();

      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const forComplaintsNode = nodesData.find((node) => node.id === "163");
        expect(forComplaintsNode).to.not.be.undefined;
        expect(forComplaintsNode.x).to.equal(210);
        expect(forComplaintsNode.y).to.equal(110);
      });

      //test redo
      cy.getByTestId("redoButton").should("exist");
      cy.getByTestId("redoButton").should("not.be.disabled");
      cy.getByTestId("redoButton").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const forComplaintsNode = nodesData.find((node) => node.id === "163");
        expect(forComplaintsNode).to.not.be.undefined;
        expect(forComplaintsNode.x).to.equal(310);
        expect(forComplaintsNode.y).to.equal(210);
      });

      //drag a new node to enable the redo button
      cy.getByTestId("code-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 650,
        y: 100,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 650,
        y: 100,
        force: true,
      });
      //test the nodes data in session storage
      cy.window().then(() => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        expect(nodesData.length).to.equal(10);
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.Code);
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: 650,
        y: 100,
        force: true,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 650,
        y: 100,
        force: true,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 680,
        y: 300,
        force: true,
      });
      cy.wait(100);
      cy.wrap(canvas).trigger("mousemove", {
        x: 750,
        y: 250,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 750,
        y: 250,
        force: true,
      });
      cy.wait(1000);
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        //get IF node with id 217
        const ifNode = nodesData.find((node) => node.id === "217");
        expect(ifNode).to.not.be.undefined;
        expect(ifNode.type).to.equal(nodes.If);
        expect(ifNode?.connections?.outputs.length).to.equal(2);
      });

      cy.getByTestId("undoButton").should("be.enabled").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        //get IF node with id 217
        const ifNode = nodesData.find((node) => node.id === "217");
        expect(ifNode).to.not.be.undefined;
        expect(ifNode.type).to.equal(nodes.If);
        expect(ifNode?.connections?.outputs.length).to.equal(1);
      });
      cy.getByTestId("undoButton").should("be.enabled").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        expect(nodesData.length).to.equal(9);
      });

      //drag if node to enable the undo button
      cy.getByTestId("if-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 450,
        y: 100,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 450,
        y: 100,
        force: true,
      });
      cy.wait(1000);
      cy.getByTestId("undoButton").should("be.enabled").click();

      //drag a FOR node
      cy.getByTestId("for-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 200,
        y: 100,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 200,
        y: 100,
        force: true,
      });
      cy.wait(1000);
      cy.getByTestId("undoButton").should("be.enabled").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        expect(nodesData.length).to.equal(9);
      });

      //make sure the undo/redo works as expected after performing arrange nodes action
      cy.getByTestId("arrangeButton").should("exist").click();
      cy.wait(2000);
      //drop a new code node
      cy.getByTestId("code-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 650,
        y: 100,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 650,
        y: 100,
        force: true,
      });
      //undo
      cy.getByTestId("undoButton").should("be.enabled").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        expect(nodesData.length).to.equal(9);
      });
    });
  });

  /*
   * This test case is to test the following:
   *  1) switch case node type exists in the palette
   *  2) add a switch case node to the graph and verify its properties
   *  3) add any other node to the switch case node and verify the properties
   *  4) add a second code node to the switch case node and apply the same case value as the first code node
   *     and verify the form should not be submitted and the error message should be displayed as the case value should be unique
   */
  it("should test the switch case node type", () => {
    skipOn("firefox");
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(5000);
    cy.getByTestId("switch-shape").should("exist");
    cy.wait(1000);
    cy.getByTestId("switch-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });

    //add switch case node to the graph
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 470 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wait(2000);
      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.SwitchCase);
      });

      //open properties panel of the switch case node
      cy.wrap(canvas).dblclick(570 + NODE_X, NODE_Y + 50);
      cy.wait(3000);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.once("uncaught:exception", () => false);
      cy.getByTestId("swcRetExpression").should("exist");
    });

    //close the properties panel
    cy.getByTestId("propsPanelCancelBtn").click();

    //add a new code node to the switch case node
    cy.getByTestId("code-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 630 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 800 + NODE_X,
        y: 100 + NODE_Y,
        force: true,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 800 + NODE_X,
        y: 100 + NODE_Y,
        force: true,
      });
      cy.wait(3000);
      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.Code);
      });

      //open properties panel of the code node just added to the switch case node and verify case value input field exists
      cy.wrap(canvas).dblclick(800 + NODE_X, 150 + NODE_Y, { force: true });
      cy.wait(3000);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.once("uncaught:exception", () => false);
      cy.getByTestId("branchValueInput").should("exist");
      cy.getByTestId("branchValueInput").clear();
      cy.getByTestId("branchValueInput").type('"CaseValue1"');
      cy.getByTestId("codeExpression")
        .find(".monaco-scrollable-element")
        .find(".lines-content")
        .find(".view-line")
        .type("theRequest.complaints");
    });

    //apply the properties
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.once("uncaught:exception", () => false);
    //add second node to the switch case node and apply the same case value as the first code node
    cy.getByTestId("code-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 630 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 800 + NODE_X,
        y: 150 + NODE_Y,
        force: true,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 800 + NODE_X,
        y: 150 + NODE_Y,
        force: true,
      });
      cy.wait(3000);
      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.Code);
      });

      //open properties panel of the code node just added to the switch case node and verify case value input field exists
      cy.wrap(canvas).dblclick(800 + NODE_X, 200 + NODE_Y, { force: true });
      cy.wait(3000);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("branchValueInput").should("exist");
      cy.getByTestId("branchValueInput").clear();
      cy.getByTestId("branchValueInput").type('"CaseValue1"');
      cy.getByTestId("codeExpression")
        .find(".monaco-scrollable-element")
        .find(".lines-content")
        .find(".view-line")
        .type("theRequest.complaints");
    });

    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("branchValueError").should("exist");
    cy.getByTestId("branchValueError").should(
      "contain.text",
      "Case value already exists",
    );
    cy.getByTestId("branchValueInput").clear();
    cy.getByTestId("branchValueInput").type('"CaseValue2"');
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");

    //test delete node and subtree functionality
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(800 + NODE_X, 200 + NODE_Y, { force: true });
      cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("deleteNode").should("exist").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        const parentSwitchNode = nodesData.find(
          (node) => node.type === nodes.SwitchCase,
        );
        expect(parentSwitchNode).to.not.be.undefined;
        expect(parentSwitchNode?.connections?.outputs?.length).to.equal(1);
      });
    });
  });

  it("should display confirmation dialog and confirm when navigating away with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true; // Simulate clicking 'OK'
    });

    // dirty the page:
    dragNodeFromPalette(nodes.If);

    cy.getByTestId("saveGraphButton").should("exist").should("be.enabled");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should("include", "/dashboard");
  });

  it("should display confirmation dialog and cancel when navigating away with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return false; // Simulate clicking 'Cancel'
    });

    // dirty the page:
    dragNodeFromPalette(nodes.If);

    cy.getByTestId("saveGraphButton").should("exist").should("be.enabled");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should(
      "include",
      "/rule-designer/designer/functions/CheckDecisionforEachLine",
    );
  });

  it("should not display the confirmation dialog for unsaved changes after deleting", () => {
    // dirty the page:
    dragNodeFromPalette(nodes.If);

    // delete the graph
    cy.getByTestId("nav-menu-more").click({ force: true });
    cy.getByTestId("deleteArtifactBtn").should("exist");
    cy.getByTestId("deleteArtifactBtn").click();
    deleteArtifact();

    // verify we are redirected to the functions list
    cy.url().should("include", "/rule-designer/designer/functions");
  });

  it("should display confirmation dialog and cancel when navigating away with saved changes along with tab switching", () => {
    skipOn("firefox");
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true;
    });

    // dirty the page:
    cy.getByTestId(`invoke-shape`).should("exist");
    cy.wait(1000);
    const draggable = `invoke-shape`;
    cy.getByTestId(draggable).trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    const tabNames = ["CheckDecisionforEachLine", "entryPointFn"];
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 470 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).rightclick(570 + NODE_X, NODE_Y + 50);
      cy.getByTestId("viewNodeInTab").should("not.exist");
      cy.getByTestId("editNode").should("exist").click();
      cy.wait(500);
      cy.getByTestId("propertiesPanel").should("exist");
    });
    cy.wait(1000);
    cy.getByTestId("invokeTargetInput").click();
    //set Invoke target value
    cy.get('div[data-value="entrypointfn"]').should("exist");
    cy.get('div[data-value="entrypointfn"]').click();
    cy.get("button").should("contain", "entryPointFn");
    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 470 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).rightclick(570 + NODE_X, NODE_Y + 50);
      cy.getByTestId("viewNodeInTab").should("exist");
      cy.getByTestId("viewNodeInTab").click();
      cy.wait(500);
      cy.getByTestId("designerDebugTabs").should("exist");
      cy.getByTestId("designerDebugTabs")
        .find("button[role='tab']")
        .then((tabs) => {
          expect(tabs.length).to.equal(tabNames.length);
          for (let x = 0; x < tabNames.length; x++) {
            expect(tabs[x]).to.contain.text(tabNames[x]);
          }
        });

      cy.getByTestId("CheckDecisionforEachLine").click({ multiple: true });
      cy.wait(1200);
      cy.getByTestId("saveGraphButton")
        .should("exist")
        .should("be.enabled")
        .click({ force: true });
      cy.getByTestId("bottom-drawer").should("not.exist");

      // navigate away
      cy.getByTestId("Dashboard-link").click();

      cy.wait(1000);
      cy.url().should("include", "/dashboard");
    });
  });

  it("should keep the save and reset buttons disabled after the entire graph canvas gets moved", () => {
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousedown", {
        x: 500,
        y: 500,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 900,
        y: 600,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 900,
        y: 600,
      });
    });
    cy.getByTestId("saveGraphButton").should("exist").should("be.disabled");
    cy.getByTestId("nav-menu-more").click({ force: true });
    cy.getByTestId("resetGraphBtn").should("not.exist");
  });

  it("should display compilation error indicator when graph with errors is loaded", () => {
    cy.getByTestId("viewCompileErrorsButton").should("exist");
  });

  it("should not display compilation error indicator when graph with no errors is loaded", () => {
    cy.visit(
      "/rule-designer/designer/functions/fn_ActivePending_ClinicalProgramsCheck",
    );
    cy.wait(2000);
    cy.getByTestId("viewCompileErrorsButton").should("not.exist");
  });

  it("should display compilation error indicator after graph is saved", () => {
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(2000);
    cy.getByTestId("viewCompileErrorsButton").should("not.exist");

    cy.getByTestId("invoke-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 400,
        y: 200,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 400,
        y: 200,
      });
    });
    cy.wait(500);
    cy.getByTestId("saveGraphButton")
      .should("exist")
      .should("be.enabled")
      .click({ force: true });
    cy.getByTestId("bottom-drawer").should("not.exist");
    cy.getByTestId("viewCompileErrorsButton").should("exist").click();
    cy.getByTestId("bottom-drawer").should("exist");
    cy.getByTestId("filterMessageInfo").should("exist");
    cy.getByTestId("graphOnlyResultsText")
      .should("exist")
      .should("contain.text", "Showing results for fn_APEX_538_Rule");
    cy.get('[data-testid^="compile-result-group"]').should("have.length", 1);
    cy.getByTestId("showAllResults").should("exist").click();
    cy.get('[data-testid^="compile-result-group"]')
      .its("length")
      .should("be.gt", 1);
    cy.getByTestId("filterMessageInfo").should("not.exist");
  });

  it("should display compile results drawer when the properties panel of a node with compile issue is opened", () => {
    cy.wait(2000);
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wait(2000);
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 410 + NODE_X,
        y: 428 + NODE_Y,
      });
      cy.wrap(canvas).dblclick(410 + NODE_X, 428 + NODE_Y);
      cy.wait(2000);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(3000);
      cy.once("uncaught:exception", () => false);
    });

    cy.getByTestId("bottom-drawer").should("exist");
    cy.getByTestId("filterMessageInfo").should("exist");
  });

  it("should not display compile results drawer when the properties panel of a node without compile issue is opened", () => {
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wait(2000);
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 120,
        y: 70,
      });
      cy.wrap(canvas).dblclick(120, 70);
      cy.wait(1000);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.once("uncaught:exception", () => false);
    });

    cy.getByTestId("bottom-drawer").should("not.exist");
  });

  it("should enable graph save button when changes are made to nodes from properties panel", () => {
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 410 + NODE_X,
        y: 428 + NODE_Y,
      });
      cy.wrap(canvas).dblclick(410 + NODE_X, 428 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.once("uncaught:exception", () => false);
    });

    cy.getByTestId("bottom-drawer-close-btn").click();
    cy.getByTestId("varDescriptionTextArea").should("exist").type("test");
    cy.getByTestId("saveGraphButton").should("exist").should("be.disabled");
    cy.getByTestId("propsPanelApplyBtn")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("saveGraphButton").should("exist").should("be.enabled");
  });

  it("should display associated items", () => {
    // most of the associated items testing is done in decision-table.cy.ts, so just testing a few things here
    testAssociatedRecordsSheet("CheckDecisionforEachLine");
    testAssociatedRecordsGrid(["Rule", "Apex_582 (Batch_Activity_RS)"]);
  });

  it("should drag a decision table node to the graph and verify if the node type is DECISIONTABLE and the properties of the node", () => {
    cy.wait(1500);
    cy.getByTestId("decisiontable-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 490 + NODE_X,
        y: 100 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 600 + NODE_X,
        y: 60 + NODE_Y,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 600 + NODE_X,
        y: 60 + NODE_Y,
      });
      cy.getByTestId("decisiontable-shape").should("exist");
      cy.wait(1000);
      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.Table);
      });
      cy.wrap(canvas).dblclick(600 + NODE_X, 100 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.once("uncaught:exception", () => false);
      cy.getByTestId("nodeTypeInput").should("exist");
      cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
      cy.getByTestId("nodeTypeInput").should("have.value", nodes.Table);
      cy.getByTestId("decisionLabel").and("not.have.class", "text-destructive");
      cy.getByTestId("nodeNameLabel").and("not.have.class", "text-destructive");

      cy.getByTestId("propsPanelApplyBtn").click({ force: true });

      cy.getByTestId("decisionLabel").should("exist");
      cy.getByTestId("decisionTableInput").should("exist");
      cy.getByTestId("varNameLabel").should("exist");
      cy.getByTestId("varNameInput").should("exist").should("not.be.disabled");

      //fill required fields
      cy.getByTestId("decisionTableInput").select("DT_ColumnsMismatch");

      cy.getByTestId("varNameInput").click();
      cy.getByTestId("varNameInput").type("test123");

      cy.getByTestId("tableCondition")
        .find(".monaco-scrollable-element")
        .find(".lines-content")
        .find(".view-line")
        .type("true");

      cy.getByTestId("propsPanelApplyBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });

  it("should delete the function from the function screen", () => {
    cy.wait(1000);
    cy.getByTestId("nav-menu-more").click({ force: true });
    cy.getByTestId("deleteArtifactBtn").should("exist");
    cy.getByTestId("deleteArtifactBtn").click();
    deleteArtifact();
    cy.url().should("include", "/rule-designer/designer/functions");
  });

  /*
   * This test case is to test the following:
   * (1) if a node's siblings branch orders are correctly updated after deleting the node from it's parent supporting false trunk
   * (2) if the children of the node are connected to a new parent with correct connection type after deleting the node
   */
  it("should test if node's siblings branch order gets updated correctly and also children of a node are connected to a new parent with correct connection type after deleting", () => {
    skipOn("firefox");
    cy.wait(1000);
    cy.getByTestId("code-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 490 + NODE_X,
        y: 200 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 550 + NODE_X,
        y: 200 + NODE_Y,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 550 + NODE_X,
        y: 200 + NODE_Y,
      });
      cy.wait(1000);
      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.Code);
        const parentNode = getParentNode(newNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        expect(parentNode.type).to.equal(nodes.If);
        parentNode.connections.outputs.forEach((output) => {
          if (output.connectedTo === newNode.id) {
            expect(output.order).to.equal(1);
          } else {
            expect(output.order).to.equal(2);
          }
        });
        cy.wrap(canvas).rightclick(550 + NODE_X, 250 + NODE_Y, { force: true });
        cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
        cy.getByTestId("deleteNode").should("exist").click();
        cy.window().then(() => {
          const nodesData = getLatestNodesDataFromSessionStorage();
          expect(nodesData).to.not.be.undefined;
          const deletedNodeExists = nodesData.some(
            (node) => node.id === newNode.id,
          );
          expect(deletedNodeExists).to.be.false;
          const parentNode = getParentNode(newNode, nodesData);
          expect(parentNode).to.not.be.undefined;
          parentNode.connections.outputs.forEach((output) => {
            expect(output.order).to.equal(1);
          });
        });
      });
    });
    cy.getByTestId("code-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 260 + NODE_X,
        y: NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 390 + NODE_X,
        y: NODE_Y,
      });

      cy.wrap(canvas).trigger("mouseup", {
        x: 390 + NODE_X,
        y: NODE_Y,
      });
      cy.wait(1000);
      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.Code);
        const parentNode = getParentNode(newNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        expect(parentNode.type).to.equal(nodes.If);
        parentNode.connections.outputs.forEach((output) => {
          if (output.connectedTo === newNode.id) {
            expect(output.type).to.equal("false");
          }
        });
        cy.wrap(canvas).rightclick(260 + NODE_X, 100 + NODE_Y);
        cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
        cy.getByTestId("deleteNode").should("exist").click();
        cy.window().then(() => {
          const nodesData = getLatestNodesDataFromSessionStorage();
          const startNode = nodesData.find((node) => node.id === "start");
          startNode.connections.outputs.forEach((output) => {
            if (output.connectedTo === newNode.id) {
              expect(output.type).to.equal("true");
            }
          });
        });
      });
    });
  });

  it("should test if a node can be added to a trunk of a node which doesn't support false trunk and also all the siblings are placed on top of the node", () => {
    skipOn("firefox");
    cy.visit("/rule-designer/designer/functions/fn_APEX_538_Rule");
    cy.wait(1000);
    cy.emit("uncaught:exception", () => false);

    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 910 + NODE_X,
        y: 400 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 910 + NODE_X,
        y: 400 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 900 + NODE_X,
        y: 100 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 900 + NODE_X,
        y: 100 + NODE_Y,
      });
      cy.wait(1000);
      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
      });

      cy.getByTestId("code-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: 650 + NODE_X,
        y: 300 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 740 + NODE_X,
        y: 350 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 740 + NODE_X,
        y: 350 + NODE_Y,
      });

      cy.window().then((win) => {
        //get nodes from session storage before node move
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const newNode = nodesData[nodesData.length - 1];
        expect(newNode).to.not.be.undefined;
        expect(newNode.type).to.equal(nodes.Code);
        const parentNode = getParentNode(newNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        expect(parentNode.type).to.equal(nodes.For);
        expect(parentNode.name).to.equal("for customFields");
      });
    });
  });

  /*it("should save both props panel and graph changes when there are pending properties panel changes", () => {
    cy.getByTestId("saveGraphButton").should("exist").should("not.be.enabled");
    cy.wait(1000);
    let node = {
      condition: 'param_checkType = "any"',
      x: 410,
      _endCharPos: 460,
      y: 428,
      id: "128",
      type: "IF",
      name: "if param_checkType",
      _lineNumber: 8,
      connections: {
        outputs: [
          {
            type: "true",
            connectedTo: "165",
            order: 1,
          },
        ],
        input: {
          connectedTo: "start",
        },
      },
    };
    openPropertiesPanel(node);
    cy.getByTestId("varDescriptionTextArea").type("test");

    //make props panel and graph dirty
    dragNodeFromPalette(nodes.If);

    cy.getByTestId("saveGraphButton").click({ force: true });
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
    openPropertiesPanel(node);
    cy.getByTestId("varDescriptionTextArea").contains("test");
  });*/

  it("should enable the arrange button when checked out", () => {
    cy.wait(1000);
    cy.getByTestId("lock-button")
      .find("svg[data-icon='user-lock'].text-he-green-1")
      .should("exist");

    cy.getByTestId("arrangeButton").should("be.enabled");
  });

  it("should display the 'Delete Subtree' context menu option for any node, only if there are nodes connected to it and clicking of this option should delete all the children", () => {
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(700, 400);
      cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("deleteNodeSubTree").should("not.exist");
      cy.getByTestId("deleteNode").should("exist").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const returnNode = nodesData.find((node) => node.id === "141");
        expect(returnNode).to.be.undefined;
      });
      cy.wrap(canvas).rightclick(100, 100);
      cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("deleteNodeSubTree").should("exist").click();
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        expect(nodesData.length).to.equal(1);
      });
      cy.wrap(canvas).rightclick(100, 100);
      cy.getByTestId("deleteNodeButton").should("not.exist");
    });
  });

  /*
   * Below test case is to test the following:
   * (1) if a node can be connected to a node with long name regardless of the width of the node
   * (2) if all the existing true/false branches are placed at the opposite side of the node, still the new node can be connected to the node
   */
  it("should test if node connections are working fine", () => {
    skipOn("firefox");
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(100, 100);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput").should("exist");
      cy.getByTestId("nodeNameInput").clear();
      cy.getByTestId("nodeNameInput").type(
        "alongnodenameforthestartnodetotestifanodecanbeconnectedregardlessofthenodewidth",
      );
      cy.getByTestId("propsPanelApplyBtn").click({ force: true });
      cy.getByTestId("propertiesPanel").should("not.exist");
      cy.getByTestId("code-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: NODE_X - 10,
        y: NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 50 + NODE_X,
        y: 10 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 50 + NODE_X,
        y: 10 + NODE_Y,
      });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const startNode = nodesData.find((node) => node.id === "start");
        expect(startNode).to.not.be.undefined;
        startNode.connections.outputs.forEach((output, index) => {
          if (index === 0) {
            expect(output.order).to.equal(1);
            const codeNode = nodesData.find(
              (node) => node.id === output.connectedTo,
            );
            expect(codeNode).to.not.be.undefined;
            expect(codeNode.type).to.equal(nodes.Code);
          }
        });
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 400 + NODE_X,
        y: 200 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 400 + NODE_X,
        y: 200 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 500 + NODE_X,
        y: NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 500 + NODE_X,
        y: NODE_Y,
      });

      cy.wait(1000);

      cy.getByTestId("code-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: NODE_X + 200,
        y: NODE_Y + 100,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: NODE_X + 300,
        y: NODE_Y + 200,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: NODE_X + 300,
        y: NODE_Y + 200,
      });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const ifNode = nodesData.find((node) => node.id === "128");
        expect(ifNode).to.not.be.undefined;
        expect(ifNode.connections.outputs.length).to.equal(2);
        ifNode.connections.outputs.forEach((output, index) => {
          if (index === 1) {
            expect(output.order).to.equal(2);
            expect(output.type).to.equal("true");
            const codeNode = nodesData.find(
              (node) => node.id === output.connectedTo,
            );
            expect(codeNode).to.not.be.undefined;
            expect(codeNode.type).to.equal(nodes.Code);
          }
        });
      });
    });
  });

  it("should test branch order manager", () => {
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("branch-order-manager-btn")
        .should("exist")
        .click({ force: true });
      cy.getByTestId("branch-order-2").should("exist").click({ force: true });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const ifNode = nodesData.find((node) => node.id === "128");
        expect(ifNode).to.not.be.undefined;
        expect(ifNode.isSelected).to.equal(true);
        const parentNode = getParentNode(ifNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        parentNode.connections.outputs.forEach((output) => {
          if (output.connectedTo === ifNode.id) {
            expect(output.order).to.equal(2);
          }
        });
      });
    });
  });

  it("should test graph node navigator", () => {
    cy.wait(2000);
    cy.getByTestId("nodeChooserBtn").should("exist").click({ force: true });
    cy.getByTestId("searchInput").should("exist");
    cy.getByTestId("searchInput").type("IF");
    cy.get("div [cmdk-group-items]").should("exist");
    cy.get("div [cmdk-group-items]").children().should("have.length", 4);
    cy.getByTestId("node-128").click({ force: true });
    cy.window().then(() => {
      const nodesData = getLatestNodesDataFromSessionStorage();
      expect(nodesData).to.not.be.undefined;
      const ifNode = nodesData.find((node) => node.id === "128");
      expect(ifNode).to.not.be.undefined;
      expect(ifNode.isSelected).to.equal(true);
    });
  });

  it("should test if the node palette, delete and change order context menu options are hidden when the properties panel is open", () => {
    cy.wait(2000);
    cy.getByTestId("maximizeToggleBtn").should("exist").click({ force: true });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(100, 100);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.get('div[class="shape if-shape read-only"]').should("exist");
      cy.wrap(canvas).rightclick(100, 100, { force: true });
      cy.getByTestId("deleteNodeButton").should("not.exist");

      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.get('div[class="shape if-shape "]').should("exist");
      cy.wrap(canvas).rightclick(100, 100, { force: true });
      cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("deleteNodeSubTree").should("exist");
    });
  });
});

describe("new function", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/_new");
  });

  it("adds a function", () => {
    cy.testBrowserTitle("New Function");
    testFormField("fileFormNameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false);
    testFormField("fileCommitMessageField", "Commit Message", false);

    testNameFieldValidation();

    typeFormField("fileNameInput", "new");
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("btnFileFormSave").click();
    cy.url().should("include", "/rule-designer/designer/functions/new");
  });

  it("checks for duplicate function name", () => {
    typeFormField("fileNameInput", "duplicate");
    cy.getByTestId("btnFileFormSave").click();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_CHECK_UNIQUE_NAME);
    cy.visit("rule-designer/designer/functions/_new");
  });
});

it("should redirect to page not found when function does not exist", () => {
  cy.testPageNotFound("/rule-designer/designer/functions/DoesNotExist");
});

describe("read only function screen", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/entryPointFn");
    cy.wait(2000);
  });

  it("should display as readonly when not checked out", () => {
    cy.getByTestId("lock-button")
      .should("exist")
      .and("be.disabled")
      .find("svg[data-icon='lock'].text-he-red-1")
      .should("exist");
    verifyGraphIsReadonly("function");
  });
});

describe("Graph Designer Node Context Menu & Copy/Paste Integration", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/CheckDecisionforEachLine");
    cy.wait(3000);
    cy.emit("uncaught:exception", () => false);
  });

  it("should show Copy menu with submenu for non-Start node, but not for Start node", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      // Start node
      cy.wrap(canvas).rightclick(10 + NODE_X, 10 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("not.exist");
      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      // If node
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNode").should("exist");
      cy.getByTestId("copyNodeSubTree").should("exist");
    });
  });

  it("should show Delete menu option for any node", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("deleteNode").should("exist");
      cy.getByTestId("deleteNodeSubTree").should("exist");
    });
  });

  it("should paste node at the bottom-right corner of the cursor location", () => {
    skipOn("firefox");
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNode").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_COPIED, true);

      const cursorX = 700 + NODE_X;
      const cursorY = 50 + NODE_Y;

      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      cy.wrap(canvas).rightclick(cursorX, cursorY);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);

      const offsetY = 30.5; // approx center of node height

      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const pastedNode = nodesData[nodesData.length - 1];
        expect(pastedNode).to.not.be.undefined;
        expect(pastedNode.x).to.be.equal(cursorX);
        expect(pastedNode.y).to.be.equal(cursorY - offsetY);
      });
    });
  });

  it("should copy node, paste as new node, and verify properties", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      addCalculationVariable(true);
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNode").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_COPIED, true);
      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);
      cy.wrap(canvas).dblclick(700 + NODE_X, 50 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "if param_checkType");
      cy.getByTestId("ifCondition")
        .find(".mtk1")
        .invoke("text")
        .then((text) => {
          expect(text.replace(/\s+/g, " ").trim()).to.include(
            'param_checkType = "any"',
          );
        });
      cy.get("table tbody tr").eq(0).should("contain.text", "testName");
      cy.get("table tbody tr").eq(0).should("contain.text", "ActActivity");
      cy.get("table tbody tr").eq(0).should("contain.text", "testValue");
      cy.get("table tbody tr").eq(0).should("contain.text", "item is an array");
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");

      cy.wrap(canvas).trigger("mousemove", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 270 + NODE_X,
        y: 160 + NODE_Y,
      });
      cy.wait(500);
      cy.wrap(canvas).trigger("mousemove", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const copiedNode = nodesData[nodesData.length - 1];
        const parentNode = getParentNode(copiedNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        parentNode.connections.outputs.forEach((output) => {
          if (output.connectedTo === copiedNode.id) {
            expect(output.order).to.equal(1);
          }
        });
      });
    });
  });

  it("should copy node + subtree, paste, and verify properties", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("varDescriptionTextArea").should("exist").type("test");
      addCalculationVariable();
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNodeSubTree").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_SUBTREE_COPIED, true);
      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);
      cy.wrap(canvas).dblclick(720 + NODE_X, 50 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "if param_checkType");
      cy.getByTestId("varDescriptionTextArea")
        .should("exist")
        .and("have.value", "test");
      cy.get("table tbody tr").eq(0).should("contain.text", "testName");
      cy.get("table tbody tr").eq(0).should("contain.text", "ActActivity");
      cy.get("table tbody tr").eq(0).should("contain.text", "testValue");
      cy.get("table tbody tr").eq(0).should("contain.text", "item is an array");
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");

      cy.wrap(canvas).trigger("mousemove", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 275 + NODE_X,
        y: 160 + NODE_Y,
      });
      cy.wait(500);
      cy.wrap(canvas).trigger("mousemove", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const copiedNode = nodesData[nodesData.length - 1];
        const parentNode = getParentNode(copiedNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        parentNode.connections.outputs.forEach((output) => {
          if (output.connectedTo === copiedNode.id) {
            expect(output.order).to.equal(1);
          }
        });
      });
    });
  });

  it("should allow pasting multiple times from one copy", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(210 + NODE_X, 320 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNode").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_COPIED, true);
      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);

      cy.wrap(canvas).dblclick(700 + NODE_X, 50 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "if param_checkType");
      cy.getByTestId("ifCondition")
        .find(".mtk1")
        .invoke("text")
        .then((text) => {
          expect(text.replace(/\s+/g, " ").trim()).to.include(
            'param_checkType = "all"',
          );
        });
      cy.get("table tbody tr")
        .eq(0)
        .should("contain.text", "param_decisionToChk");
      cy.get("table tbody tr").eq(0).should("contain.text", "String");
      cy.get("table tbody tr").eq(0).should("contain.text", '"test"');
      cy.get("table tbody tr").eq(0).should("contain.text", "item is an array");
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");

      cy.wrap(canvas).trigger("mousemove", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 270 + NODE_X,
        y: 160 + NODE_Y,
      });
      cy.wait(500);
      cy.wrap(canvas).trigger("mousemove", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 700 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const copiedNode = nodesData[nodesData.length - 1];
        const parentNode = getParentNode(copiedNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        parentNode.connections.outputs.forEach((output) => {
          if (output.connectedTo === copiedNode.id) {
            expect(output.order).to.equal(1);
          }
        });
      });

      cy.wrap(canvas).rightclick(900 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);

      cy.wrap(canvas).dblclick(1000 + NODE_X, 50 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "if param_checkType");
      cy.getByTestId("ifCondition")
        .find(".mtk1")
        .invoke("text")
        .then((text) => {
          expect(text.replace(/\s+/g, " ").trim()).to.include(
            'param_checkType = "all"',
          );
        });
      cy.get("table tbody tr").eq(1).should("contain.text", "param_checkType");
      cy.get("table tbody tr").eq(1).should("contain.text", "String");
      cy.get("table tbody tr").eq(1).should("contain.text", '"test"');
      cy.get("table tbody tr").eq(1).should("contain.text", "item is an array");
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
      cy.wrap(canvas).trigger("mousemove", {
        x: 1000 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 1000 + NODE_X,
        y: 50 + NODE_Y,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 270 + NODE_X,
        y: 160 + NODE_Y,
      });
      cy.wait(500);
      cy.wrap(canvas).trigger("mousemove", {
        x: 500 + NODE_X,
        y: NODE_Y,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 500 + NODE_X,
        y: NODE_Y,
      });
      cy.window().then(() => {
        const nodesData = getLatestNodesDataFromSessionStorage();
        expect(nodesData).to.not.be.undefined;
        const copiedNode = nodesData[nodesData.length - 1];
        const parentNode = getParentNode(copiedNode, nodesData);
        expect(parentNode).to.not.be.undefined;
        parentNode.connections.outputs.forEach((output) => {
          if (output.connectedTo === copiedNode.id) {
            expect(output.order).to.equal(1);
          }
        });
      });
    });
  });

  it("should allow copy from and not paste into a read-only graph", () => {
    cy.visit("/rule-designer/designer/functions/entryPointFn");
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_COPIED, true);
      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("not.exist");
    });
  });

  it("should test if the local storage data gets updated properly", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNodeSubTree").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_SUBTREE_COPIED, true);
      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);
      cy.wrap(canvas).dblclick(720 + NODE_X, 50 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "if param_checkType");
      cy.get("table").should("not.exist");
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");

      cy.getByTestId("undoButton").should("exist").and("be.enabled").click();

      cy.wrap(canvas).rightclick(210 + NODE_X, 328 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNodeSubTree").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_SUBTREE_COPIED, true);
      cy.wrap(canvas).trigger("mousedown", {
        which: 1,
        pageX: 0 + NODE_X,
        pageY: 0 + NODE_Y,
      });
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);
      cy.wrap(canvas).dblclick(720 + NODE_X, 50 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "if param_checkType");
      cy.get("table tbody tr")
        .eq(0)
        .should("contain.text", "param_decisionToChk");
      cy.get("table tbody tr").eq(0).should("contain.text", "String");
      cy.get("table tbody tr").eq(0).should("contain.text", '"test"');
      cy.get("table tbody tr").eq(0).should("contain.text", "item is an array");
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });

  it("should copy a node and paste into a different graph, verifying all properties and calculation variables", () => {
    cy.visit("/rule-designer/designer/functions/CheckDecisionforEachLine");
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(210 + NODE_X, 328 + NODE_Y);
      cy.getByTestId("copyNodeButton").should("exist").trigger("mouseover");
      cy.getByTestId("copyNode").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODE_COPIED, true);
    });
    cy.get('[aria-label="functions"]').click();
    cy.get(
      'a[href="/rule-designer/designer/functions/fn_APEX_538_Rule"]',
    ).click();
    cy.wait(3000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(900 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.NODES_PASTED, true);

      cy.wrap(canvas).dblclick(1020 + NODE_X, 50 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "if param_checkType");
      cy.get("table tbody tr")
        .eq(0)
        .should("contain.text", "param_decisionToChk");
      cy.get("table tbody tr").eq(0).should("contain.text", "String");
      cy.get("table tbody tr").eq(0).should("contain.text", '"test"');
      cy.get("table tbody tr").eq(0).should("contain.text", "item is an array");
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });

  it("should show error toast when copied data is invalid JSON", () => {
    cy.window().then((win) => {
      win.localStorage.setItem("copiedNode", "{invalid:json}");
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.ERROR, ToastMessage.INVALID_COPIED_DATA, true);
    });
  });

  it("should show error toast when there are no nodes to paste", () => {
    cy.window().then((win) => {
      win.localStorage.setItem("copiedNode", "[]");
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(600 + NODE_X, NODE_Y);
      cy.getByTestId("pasteNode").should("exist").click();
      testToast(ToastTitle.ERROR, ToastMessage.NO_NODES_TO_PASTE, true);
    });
  });

  it("should not persist copied node after all tabs are closed", () => {
    cy.window().then((win) => {
      win.localStorage.setItem("copiedNode", JSON.stringify([{ id: "test" }]));
      win.localStorage.setItem("openTabs", JSON.stringify([1]));
    });
    cy.window().then((win) => {
      win.localStorage.setItem("openTabs", JSON.stringify([]));
      win.dispatchEvent(new StorageEvent("storage", { key: "openTabs" }));
      expect(win.localStorage.getItem("copiedNode")).to.be.null;
    });
  });
});

describe("Properties Panel Tab Behavior", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/fnWithInvokeNode");
    cy.wait(1000);
    cy.emit("uncaught:exception", () => false);
  });

  it("closes property panel in 2nd tab when switching back to original tab", () => {
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).rightclick(240 + NODE_X, 140 + NODE_Y);
      cy.getByTestId("viewNodeInTab").should("exist").click();
    });
    cy.wait(1000);
    const tabNames = ["fnWithInvokeNode", "entryPointFn"];
    cy.getByTestId("designerDebugTabs").should("exist");
    cy.getByTestId("designerDebugTabs")
      .find("button[role='tab']")
      .then((tabs) => {
        expect(tabs.length).to.equal(tabNames.length);
        for (let x = 0; x < tabNames.length; x++) {
          expect(tabs[x]).to.contain.text(tabNames[x]);
        }
      });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
    });
    cy.getByTestId("designerDebugTabs")
      .find("button[role='tab']")
      .first()
      .click();
    cy.wait(1000);
    cy.getByTestId("designerDebugTabs")
      .find("button[role='tab']")
      .eq(1)
      .click({ force: true });
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("closes property panel in first tab when opening node in new tab", () => {
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(360, 200);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wrap(canvas).rightclick(360, 200);
      cy.getByTestId("viewNodeInTab").should("exist").click();
    });
    cy.wait(1000);
    const tabNames = ["fnWithInvokeNode", "entryPointFn"];
    cy.getByTestId("designerDebugTabs")
      .find("button[role='tab']")
      .first()
      .click({ force: true });
    cy.getByTestId("designerDebugTabs")
      .should("exist")
      .find("button[role='tab']")
      .then((tabs) => {
        expect(tabs.length).to.equal(tabNames.length);
        for (let x = 0; x < tabNames.length; x++) {
          expect(tabs[x]).to.contain.text(tabNames[x]);
        }
      });
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("shows unsaved changes dialog when switching tabs with dirty panel and tests `Confirm` and `Cancel` actions", () => {
    cy.wait(2000);
    cy.getByTestId("designerDebugTabs").should("exist");
    const tabNames = ["fnWithInvokeNode", "entryPointFn"];
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(120 + NODE_X, 20 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput").should("exist").type("Unsaved Changes");
      cy.wrap(canvas).rightclick(240 + NODE_X, 140 + NODE_Y);
      cy.getByTestId("viewNodeInTab").should("exist").click();
      cy.getByTestId("unsavedPropsDialog-dialog-container")
        .should("exist")
        .contains("Unsaved Changes");
      cy.getByTestId("unsavedPropsDialog-dialog-content")
        .should("exist")
        .contains(
          "You have unsaved changes. You will lose your unsaved changes if you open a graph in a new tab.",
        );
      cy.getByTestId("unsavedPropsDialog-dialog-content").contains(
        "Do you want to proceed?",
      );
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button")
        .should("exist")
        .contains("Confirm");
      cy.getByTestId("unsavedPropsDialog-dialog-cancel-button")
        .should("exist")
        .contains("Cancel");
      cy.getByTestId("unsavedPropsDialog-dialog-cancel-button").click();
      cy.getByTestId("propertiesPanel").should("exist");

      cy.getByTestId("designerDebugTabs")
        .find("button[role='tab']")
        .then((tabs) => {
          expect(tabs.length).to.equal(1);
          expect(tabs[0]).to.contain.text(tabNames[0]);
        });

      cy.wrap(canvas).rightclick(240 + NODE_X, 140 + NODE_Y);
      cy.getByTestId("viewNodeInTab").should("exist").click();
      cy.getByTestId("unsavedPropsDialog-dialog-container").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-cancel-button").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
    cy.wait(2000);
    cy.getByTestId("designerDebugTabs")
      .find("button[role='tab']")
      .then((tabs) => {
        expect(tabs.length).to.equal(tabNames.length);
        for (let x = 0; x < tabNames.length; x++) {
          expect(tabs[x]).to.contain.text(tabNames[x]);
        }
        cy.wrap(tabs[0]).click();
        cy.wait(1000);
        cy.getByTestId("propertiesPanel").should("not.exist");
      });
  });
});

describe("View Code Link", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/fnWithInvokeNode");
    cy.wait(500);
  });
  it("should test if the view code link is present in the more actions menu", () => {
    cy.getByTestId("nav-menu-more").should("exist").click({ force: true });
    cy.getByTestId("viewCodeLink")
      .should("exist")
      .should(
        "have.attr",
        "href",
        "/rule-designer/code-viewer?graphName=fnWithInvokeNode&parentName=&type=FUNCTION",
      );
  });

  it("should test if the view code link is present in the more actions menu for read-only function", () => {
    cy.visit("/rule-designer/designer/functions/entryPointFn");
    cy.getByTestId("nav-menu-more").should("exist").click({ force: true });
    cy.getByTestId("viewCodeLink")
      .should("exist")
      .should(
        "have.attr",
        "href",
        "/rule-designer/code-viewer?graphName=entryPointFn&parentName=&type=FUNCTION",
      );
  });
});

describe("Properties Panel Unsaved Changes Warning", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/CheckDecisionforEachLine");
    cy.wait(500);
  });

  it("should show unsaved changes warning when properties panel, is switched between nodes,  with unsaved changes and test `Confirm` and `Cancel` actions", () => {
    skipOn("firefox");
    cy.wait(3000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];

      //test cancel action
      cy.wrap(canvas).dblclick(350, 200);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput").should("exist").clear();
      cy.getByTestId("nodeNameInput").type("Unsaved Changes");
      cy.getByTestId("ifCondition")
        .find(".monaco-scrollable-element .view-lines")
        .type("test");
      cy.wrap(canvas).dblclick(350, 420);
      cy.getByTestId("unsavedPropsDialog-dialog-container")
        .should("exist")
        .contains("Unsaved Changes");
      cy.getByTestId("unsavedPropsDialog-dialog-content")
        .should("exist")
        .contains(
          "You have unsaved changes for the current node. These changes will be lost if you proceed.",
        );
      cy.getByTestId("unsavedPropsDialog-dialog-content").contains(
        "Do you want to proceed?",
      );
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button")
        .should("exist")
        .contains("Confirm");
      cy.getByTestId("unsavedPropsDialog-dialog-cancel-button")
        .should("exist")
        .contains("Cancel");
      cy.getByTestId("unsavedPropsDialog-dialog-cancel-button").click();
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("have.value", "Unsaved Changes");

      //test confirm action
      cy.wrap(canvas).dblclick(350, 420);
      cy.getByTestId("unsavedPropsDialog-dialog-container").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-cancel-button").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button").click();
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput")
        .should("exist")
        .and("not.have.value", "Unsaved Changes");
      cy.getByTestId("nodeNameInput").should(
        "have.value",
        "if param_checkType",
      );
      testTable(
        ["Name", "Type", "Value", "Is Array?", "Actions"],
        [
          "param_decisionToChk",
          "String",
          "test",
          {
            type: "icon",
            value: "check",
            screenReaderText: "item is an array",
          },
          "",
        ],
      );
      // verify that Apply button is disabled when there are no changes and content assisted field state from the previous node is not carried over
      cy.getByTestId("propsPanelApplyBtn")
        .should("exist")
        .should("not.be.enabled");
    });
  });

  it("should test if the properties panel apply button is disabled on click of confirm in the unsaved warnings dialog when switching between decision table and for node", () => {
    cy.wait(2000);
    cy.getByTestId("decisiontable-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 500,
        y: 0,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 500,
        y: 0,
      });
    });

    cy.getByTestId("for-shape").trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 500,
        y: 60,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 500,
        y: 60,
      });
    });

    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(550, 20);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput").should("exist").clear();
      cy.getByTestId("nodeNameInput").type("Unsaved Changes");
      cy.getByTestId("tableCondition")
        .find(".monaco-scrollable-element .view-lines")
        .type("test");
      cy.wrap(canvas).dblclick(550, 70);
      cy.getByTestId("unsavedPropsDialog-dialog-container").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-cancel-button").should("exist");
      cy.getByTestId("unsavedPropsDialog-dialog-submit-button").click();
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("propsPanelApplyBtn")
        .should("exist")
        .should("not.be.enabled");
    });
  });

  it("should show window before unloading or closing the tab with unsaved changes", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(350, 200);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("nodeNameInput").should("exist").clear();
      cy.getByTestId("nodeNameInput").type("Unsaved Changes");
      cy.getByTestId("Dashboard-link").click();
      cy.on("window:confirm", (confirmText) => {
        expect(confirmText).to.equal(
          "Your changes have not been saved. Do you wish to leave this page without saving?",
        );
        return true;
      });
      cy.url().should("include", "/dashboard");
    });
  });

  it("should close properties panel on click of reset button and not show unsaved changes dialog", () => {
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 560,
        y: 290,
      });
      cy.wrap(canvas).trigger("mousedown", {
        x: 560,
        y: 290,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: 600,
        y: 290,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 600,
        y: 290,
      });
      cy.wrap(canvas).dblclick(370, 190);
      cy.getByTestId("propertiesPanel").should("exist");
      //make sure the node palette is in read-only mode
      cy.getByTestId("if-shape").should("have.class", "read-only");
      cy.getByTestId("nav-menu-more").click({ force: true });
      cy.getByTestId("resetGraphBtn").should("exist").click({ force: true });
      cy.wait(500);
      cy.getByTestId("propertiesPanel").should("not.exist");
      //make sure the node palette is not in read-only mode anymore
      cy.getByTestId("if-shape").should("not.have.class", "read-only");
    });
  });

  it("verify that expression field should be visible and required for function with non-void return type", () => {
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const startNodeX = NODE_X;
      const startNodeY = NODE_Y;

      // Open Start node properties panel
      cy.wrap(canvas).dblclick(startNodeX, startNodeY);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Set return type to Integer (non-void)
      cy.getByTestId("returnTypeInput").should("exist").select("Integer");
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.wait(500);

      // Add a Return node to the function
      const returnNodeX = 400 + NODE_X;
      const returnNodeY = NODE_Y;
      cy.getByTestId("return-shape").should("exist");
      cy.getByTestId("return-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX - 100,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wait(500);

      // Open the property panel for the Return node
      cy.wrap(canvas).dblclick(returnNodeX, returnNodeY + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Expected Result: The Expression field should be visible
      cy.getByTestId("swcRetExpression").should("exist");
      cy.getByTestId("swcRetExpression").should("be.visible");

      // Add something in Description text box
      cy.getByTestId("varDescriptionTextArea").should("exist");
      cy.getByTestId("varDescriptionTextArea").type(
        "Test return node description",
      );

      // Click apply and validate Expression field is displaying mandatory field validation
      cy.getByTestId("propsPanelApplyBtn").should("exist");
      cy.getByTestId("propsPanelApplyBtn").should("be.enabled");
      cy.getByTestId("propsPanelApplyBtn").click();

      // Validate that mandatory field validation is displayed for Expression field
      cy.getByTestId("errorMessage")
        .should("exist")
        .should("contain.text", "Enter required field");

      // Expected Result: The Expression field should be marked as required
      // Now add an expression and verify it enables successful save
      cy.getByTestId("swcRetExpression")
        .find(".monaco-scrollable-element")
        .find(".lines-content")
        .find(".view-line")
        .type("123");

      cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });

  it("verify that expression field should be hidden for function with void return type", () => {
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const startNodeX = NODE_X;
      const startNodeY = NODE_Y;

      // Open Start node properties panel
      cy.wrap(canvas).dblclick(startNodeX, startNodeY);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Set return type to void
      cy.getByTestId("returnTypeInput").should("exist").select("void");
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.wait(500);

      // Add a Return node to the function
      const returnNodeX = 400 + NODE_X;
      const returnNodeY = NODE_Y;
      cy.getByTestId("return-shape").should("exist");
      cy.getByTestId("return-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX - 100,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wait(500);

      // Open the property panel for the Return node
      cy.wrap(canvas).dblclick(returnNodeX, returnNodeY + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Expected Result: The Expression field should not be visible
      cy.getByTestId("swcRetExpression").should("not.exist");

      // Expected Result: User cannot enter or edit an expression
      // Return node acts as a simple exit - verify we can close without expression
      cy.getByTestId("propsPanelApplyBtn").should("exist");
      cy.getByTestId("propsPanelApplyBtn").should("be.disabled");

      // Close properties panel
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });
});

describe("Invoke Node's Assign target", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/functions/fnWithInvokeNode");
    cy.wait(2000);
  });

  it("should test if the Assign Target field is displayed when the Assign Target value already exists for the node", () => {
    doubleClickNode(230, 200);
    cy.getByTestId("propertiesPanel").should("exist");
    cy.wait(1000);
    testContentAssistedField("assignTarget", "Assign Target", true);
    cy.getByTestId("assignTarget")
      .find(".monaco-scrollable-element .view-lines")
      .click();
    deleteAllText();
    cy.getByTestId("propsPanelApplyBtn")
      .should("exist")
      .should("be.enabled")
      .click();
    cy.getByTestId("errorMessage")
      .should("exist")
      .should("contain.text", "Enter required field");
    cy.getByTestId("assignTarget")
      .find(".monaco-scrollable-element .view-lines")
      .type("theRequest");
    cy.getByTestId("propsPanelApplyBtn")
      .should("exist")
      .should("be.enabled")
      .click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("should test if the Assign Target field is not displayed when target doesn't return anything", () => {
    doubleClickNode(230, 100);
    cy.getByTestId("propertiesPanel").should("exist");
    cy.getByTestId("assignTarget").should("not.exist");

    cy.getByTestId("invokeTargetInput").click();
    cy.wait(500);
    cy.get('div[data-value="checkdecisionforeachline"]')
      .should("exist")
      .click();
    cy.get("button").should("contain", "CheckDecisionforEachLine");
    cy.getByTestId("assignTarget").should("exist");
    cy.getByTestId("propsPanelCancelBtn").should("exist").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
  });

  it("should test if the invoke target parameters can be edited and verified in the properties panel", () => {
    doubleClickNode(230, 200);
    cy.wait(2000);
    cy.getByTestId("propertiesPanel").should("exist");
    testTable(
      ["Name", "Type", "Is Array?", "Value"],
      ["testArg1", "String", "", "(empty)"],
    );
    // eslint-disable-next-line cypress/no-assigning-return-values
    const triggerBtn = cy.getGridRowButtonOrLink(0, 3);
    openDialog(triggerBtn);
    // eslint-disable-next-line cypress/unsafe-to-chain-command
    cy.getByTestId("initExprField")
      .find(".monaco-scrollable-element .view-lines")
      .type("{backspace}".repeat(7))
      .type("newval");
    cy.getByTestId("dialog-submit-button")
      .contains("Apply")
      .click({ force: true });
    testTable(
      ["Name", "Type", "Is Array?", "Value"],
      ["testArg1", "String", "", "newval"],
    );
  });
});
