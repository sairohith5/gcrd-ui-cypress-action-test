import { skipOn } from "@cypress/skip-test";
import { testDescriptionEditForm } from "../../utils/form-utils";
import {
  testAssociatedRecordsGrid,
  testAssociatedRecordsSheet,
} from "../../utils/associated-records-utils";
import { NODE_X, NODE_Y } from "../../utils/constants";

describe("main flow", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/main-flow");
    cy.wait(1000); // need to wait for the graph to load before doing other things
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter("MainFlow", "main rule flow");
    cy.testBrowserTitle("Main Flow");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Designer", "Main Flow");
    cy.getByTestId("tags-container").should("exist");
  });

  it("edits description", () => {
    testDescriptionEditForm();
  });

  it("should display associated items", () => {
    // most of the associated items testing is done in decision-table.cy.ts, so just testing a few things here
    testAssociatedRecordsSheet("MainFlow");
    testAssociatedRecordsGrid("No results.");
  });

  it("should test if the view code link is present in the more actions menu", () => {
    cy.getByTestId("nav-menu-more").should("exist").click({ force: true });
    cy.getByTestId("viewCodeLink")
      .should("exist")
      .should(
        "have.attr",
        "href",
        "/rule-designer/code-viewer?graphName=MainFlow&parentName=&type=FLOW",
      );
  });

  it("verify that return node does not show expression field for main flow", () => {
    // Add a return node to main flow
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];

      // Add a Return node to the Main Flow
      const returnNodeX = 400 + NODE_X;
      const returnNodeY = NODE_Y;
      cy.getByTestId("return-shape").should("exist");
      cy.getByTestId("return-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX - 100,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wait(500);

      // Open the property panel for the Return node
      cy.wrap(canvas).dblclick(returnNodeX, returnNodeY + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Expected Result: Expression field should not be displayed
      cy.getByTestId("swcRetExpression").should("not.exist");

      // Verify the properties panel can be closed without requiring an expression
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });
});
