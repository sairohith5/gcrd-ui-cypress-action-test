import { skipOn } from "@cypress/skip-test";
import { getRelativeDate } from "../../../utils/date-utils";
import {
  openDialog,
  testDialog,
  testDialogIsNotDisplayed,
} from "../../../utils/dialog-utils";
import {
  testColumnVisibility,
  testFilter,
  testPagination,
  testTable,
} from "../../../utils/grid-utils";
import {
  testRevisionCompareDialog,
  testRevisionHistoryDialogFromGrid,
  testRollback,
} from "../../../utils/revision-history-utils";
import { deleteArtifact } from "../../../utils/utils";
import {
  selectFormField,
  testFormField,
  testNameFieldValidationWhenCloning,
  typeFormField,
} from "../../../utils/form-utils";
import {
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";

describe("rules", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/rule-sets/Batch_Activity_RS");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter(
      "Batch_Activity_RS",
      "This rule does some really cool stuff",
    );
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home", "Rule Sets"]);

    cy.testSidebar("Designer", "Rule Sets");
    cy.getByTestId("tags-container").should("exist");
  });

  it("displays a grid", () => {
    cy.wait(1000);
    testTable(
      [
        { type: "button", ariaLabel: "Lock Status" },
        "Name",
        "Tags",
        "Last Committed",
        "Actions",
      ],
      [
        { type: "button", value: "checked out by me" },
        "Apex_582",
        { type: "tags", tags: ["GCRE-789"] },
        getRelativeDate("2024-05-23 13:47:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for Apex_582",
          },
          { type: "button", value: "clone Apex_582" },
          { type: "button", value: "delete rule Apex_582" },
        ],
      ],
    );
    testFilter("583", [
      { type: "button", value: "checked out by mdickson@healthedge.com" },
      "Apex_583",
      "",
      getRelativeDate("2022-05-03 11:28:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for Apex_583",
        },
        { type: "button", value: "clone Apex_583" },
      ],
    ]);
    // test hash-tag filtering (this one also tests case-insensitive filtering):
    testFilter("#gcre-789", [
      { type: "button", value: "checked out by me" },
      "Apex_582",
      { type: "tags", tags: ["GCRE-789"] },
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for Apex_582",
        },
        { type: "button", value: "clone Apex_582" },
        { type: "button", value: "delete rule Apex_582" },
      ],
    ]);
    testPagination(2);
    testColumnVisibility([
      "Lock Status",
      "Tags",
      "Last Committed",
      "Committed By",
      "Message",
    ]);
  });

  it("deletes a rule", () => {
    testDialog(cy.getGridRowButtonOrLink(0, 4, 2), "Delete Confirmation");
    openDialog(cy.getGridRowButtonOrLink(0, 4, 2));
    deleteArtifact();
  });

  it("navigates to edit a rule", () => {
    cy.getGridRowButtonOrLink(0, 1).click();
    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/Apex_582",
    );
  });

  it("navigates to add a rule", () => {
    cy.getByTestId("addRuleBtn").click();
    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/_new",
    );
  });

  it("displays revision history", () => {
    testRevisionHistoryDialogFromGrid(0, "Apex_582", [
      { type: "checkbox", isChecked: false },
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
      { type: "email", value: "mdickson1@gmail.com" },
      "test",
      { type: "button", value: "Rollback to this revision" },
    ]);
    testRevisionCompareDialog(
      0,
      1,
      2,
      "Apex_582 (Rule)",
      "429e207",
      getRelativeDate("2024-11-13 09:48:12 -0500"),
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
    );
    testRollback(0, 1);
  });

  it("clones a rule", () => {
    testDialog(cy.getGridRowButtonOrLink(0, 4, 1), "Clone Rule");
    openDialog(cy.getGridRowButtonOrLink(0, 4, 1));
    cy.wait(1000);
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled")
      .contains("Save & Commit");
    testFormField("filenameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false, {
      defaultValue: "cloned from Apex_582 (rule set: Batch_Activity_RS)",
    });
    cy.getByTestId("rulegroupInput").should("exist");
    testFormField("rulegroupField", "Rule Set", true, {
      defaultValue: "Batch_Activity_RS",
      expectedSelectOptions: [
        "Select one",
        "Batch_Activity_RS",
        "Batch_AG_Letter_RS",
        "Batch_AG_RealTime_RS",
        "Batch_Alerts_RS",
        "Batch_Assignment_RS",
        "Batch_ClinicalProgram_RS",
        "Batch_CM_RealTime_RS",
        "Batch_Letters_RS",
        "Batch_Monthly_RS",
        "Batch_Others_RS",
        "Batch_PH_RealTime_RS",
        "Batch_Program_RS",
        "Batch_Risks_RS",
        "Batch_UM_RealTime_RS",
        "MainFlow",
        "PP_RealTime_RS",
        "RealTime_AG_RS",
        "RealTime_InterQual_RS",
        "testZeros0",
        "testZeros00",
        "testZeros000",
      ],
    });

    testNameFieldValidationWhenCloning();

    typeFormField("filenameInput", "clonedFunction");
    selectFormField("rulegroupInput", "Batch_Alerts_RS");
    testFormField("fileFormDescriptionField", "Description", false, {
      defaultValue: "cloned from Apex_582 (rule set: Batch_Activity_RS)",
    });
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_CLONE, true);
  });
});
