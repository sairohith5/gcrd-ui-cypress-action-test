import {
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";
import {
  testDescriptionEditForm,
  testFormField,
  testFormFieldValidation,
  testNameFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import {
  checkPropertiesPanelandNodeValues,
  dragNodeFromPalette,
  nodes,
  openPropertiesPanel,
  testStartNode,
} from "../../../utils/graph-utils";
import {
  testToast,
  ToastTitle,
  ToastMessage,
} from "../../../utils/toast-utils";
import { NODE_X, NODE_Y } from "../../../utils/constants";
import { skipOn } from "@cypress/skip-test";
import {
  testAssociatedRecordsGrid,
  testAssociatedRecordsSheet,
} from "../../../utils/associated-records-utils";

describe("rule", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/Apex_582",
    );
    cy.wait(1000); // need to wait for the graph to load before doing other things
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter(
      "Apex_582",
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    );
    cy.testBrowserTitle("[Apex_582] Rule");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs([
      "Home",
      "Rule Sets",
      "Rule Set: Batch_Activity_RS",
      "Rules",
    ]);
    cy.testSidebar("Designer", "Rule Sets");
    cy.getByTestId("tags-container").should("exist");
  });

  it("edits description", () => {
    testDescriptionEditForm();
  });

  it("renames rule", () => {
    // test the form appears and can be cancelled:
    cy.getByTestId("renameBtn").should("exist").click();
    cy.getByTestId("filenameFormSaveBtn").should("exist").should("be.disabled");
    cy.getByTestId("filenameFormCancelBtn").should("exist").click();
    cy.getByTestId("filenameField").should("not.exist");

    // test validation:
    cy.getByTestId("renameBtn").click();
    cy.getByTestId("filenameInput").clear();
    cy.getByTestId("filenameFormSaveBtn").should("be.enabled").click();
    testFormFieldValidation("filenameField", "Enter required field", true);

    testNameFieldValidation(
      "filenameField",
      "filenameInput",
      "filenameFormSaveBtn",
    );

    cy.getByTestId("filenameFormCancelBtn").should("exist").click();

    // test confirmation dialog:
    cy.getByTestId("renameBtn").click();
    cy.getByTestId("filenameInput").clear();
    typeFormField("filenameInput", "newRuleName");
    cy.getByTestId("filenameFormSaveBtn").should("be.enabled").click();
    testIsDialogDisplayed();
    cy.getByTestId("dialog-title").contains("Rename Confirmation");
    cy.getByTestId("dialog-content").contains(
      "Renaming a rule may cause compilation errors, requiring manual updates to all existing references.",
    );
    cy.getByTestId("dialog-content").contains(
      "Are you sure you want to rename this rule?",
    );
    cy.getByTestId("dialog-submit-button").should("exist").contains("Confirm");
    cy.getByTestId("dialog-cancel-button")
      .should("exist")
      .contains("Cancel")
      .click();
    testDialogIsNotDisplayed();
    cy.getByTestId("filenameInput").should("not.exist");
    cy.getByTestId("pageHeader").contains("Apex_582");

    // test duplicate rename:
    cy.getByTestId("renameBtn").click();
    cy.getByTestId("filenameInput").clear();
    typeFormField("filenameInput", "badRuleName");
    cy.getByTestId("filenameFormSaveBtn").should("be.enabled").click();
    testIsDialogDisplayed();
    cy.getByTestId("dialog-submit-button").should("exist").click();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_TARGET_ALREADY_EXISTS);

    // test referenced rename:
    cy.getByTestId("filenameInput").clear();
    typeFormField("filenameInput", "referencedRuleName");
    cy.getByTestId("filenameFormSaveBtn").should("be.enabled").click();
    testIsDialogDisplayed();
    cy.getByTestId("dialog-submit-button").should("exist").click();
    testDialogIsNotDisplayed();
    testToast(
      ToastTitle.ERROR,
      "Unable to rename - the item is being referenced by 1 other item.",
    );

    // test successful rename:
    cy.getByTestId("filenameInput").clear();
    typeFormField("filenameInput", "newRuleName");
    cy.getByTestId("filenameFormSaveBtn").should("be.enabled").click();
    testIsDialogDisplayed();
    cy.getByTestId("dialog-submit-button").should("exist").click();

    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/newRuleName",
    );
  });

  it("test graph", () => {
    testStartNode("graphScreen");
  });
  it("tests Drag and Drop of the IF node in graph", () => {
    dragNodeFromPalette(nodes.If);
  });

  it("tests Drag and Drop of the FOR node in graph", () => {
    dragNodeFromPalette(nodes.For);
  });

  it("tests Drag and Drop of the Action node in graph", () => {
    dragNodeFromPalette(nodes.Action);
  });

  it("tests Drag and Drop of the Object node in graph", () => {
    dragNodeFromPalette(nodes.Object);
  });

  it("tests Drag and Drop of the Table node in graph", () => {
    dragNodeFromPalette(nodes.Table);
  });

  it("tests Drag and Drop of the Code node in graph", () => {
    dragNodeFromPalette(nodes.Code);
  });

  it("tests Drag and Drop of the Return node in graph", () => {
    dragNodeFromPalette(nodes.Return);
  });

  it("tests Drag and Drop of the Invoke node in graph", () => {
    dragNodeFromPalette(nodes.Invoke);
  });

  it("modify the Description and save properties panel changes", () => {
    cy.fixture("loadrule-Batch_Activity_RS-Apex_582.json").then(
      (nodeDetails) => {
        openPropertiesPanel(nodeDetails.nodes[2]);
        cy.getByTestId("varDescriptionTextArea").should("exist");
        cy.getByTestId("propsPanelApplyBtn").should("exist");
        cy.getByTestId("propsPanelApplyBtn")
          .should("exist")
          .should("be.disabled");
        cy.getByTestId("varDescriptionTextArea").type("test description");
        cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
        cy.getByTestId("propsPanelApplyBtn").click({ force: true });
      },
    );
  });

  it("should close properties panel", () => {
    cy.fixture("loadrule-Batch_Activity_RS-Apex_582.json").then(
      (nodeDetails) => {
        openPropertiesPanel(nodeDetails.nodes[2]);
        cy.getByTestId("propsPanelCancelBtn").should("exist");
        cy.getByTestId("propsPanelCancelBtn")
          .should("exist")
          .should("not.be.disabled");
        cy.getByTestId("propsPanelCancelBtn").click();
        cy.getByTestId("propertiesPanel").should("not.exist");
      },
    );
  });

  it("should navigate to rules grid on cancel", () => {
    cy.getByTestId("cancelBtn").click({ force: true });
    cy.wait(2000);
    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS",
    );
  });

  it("should reorder Calculation variable table items", () => {
    cy.fixture("loadrule-Batch_Activity_RS-Apex_582.json").then(
      (nodeDetails) => {
        openPropertiesPanel(nodeDetails.nodes[2]);
        cy.wait(2000);
        cy.getByTestId("propertiesPanel").should("exist");
        cy.get("table tbody tr")
          .eq(0)
          .should("contain.text", nodeDetails.nodes[2].variables[0].varName);
        cy.get("table tbody tr")
          .eq(1)
          .should("contain.text", nodeDetails.nodes[2].variables[1].varName);

        cy.getByTestId("moveDownBtn").should("exist");

        // This is to prevent the defult submitting the form when we click a different button
        cy.get("form").invoke("on", "submit", (e) => {
          e.preventDefault();
        });

        cy.getByTestId("moveDownBtn").click();
        cy.wait(2000);

        // Verify order is swapped
        cy.get("table tbody tr")
          .eq(0)
          .should("contain.text", nodeDetails.nodes[2].variables[1].varName);
        cy.get("table tbody tr")
          .eq(1)
          .should("contain.text", nodeDetails.nodes[2].variables[0].varName);
      },
    );
  });

  it("tests opening properties panel for IF node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.If,
      name: nodes.If,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };

    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for FOR node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.For,
      name: nodes.For,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for ACTION node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Action,
      name: nodes.Action,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for TABLE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Table,
      name: nodes.Table,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for CODE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Code,
      name: nodes.Code,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for OBJECT node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Object,
      name: nodes.Object,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for RETURN node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Return,
      name: nodes.Return,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode, false);
  });

  it("tests opening properties panel for INVOKE node in graph", () => {
    cy.wait(1000);
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Invoke,
      name: nodes.Invoke,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests the 'View Node in Tab' functionality for Invoke node", () => {
    cy.getByTestId(`invoke-shape`).should("exist");
    cy.wait(1000);
    const draggable = `invoke-shape`;
    cy.getByTestId(draggable).trigger("mousedown", {
      which: 1,
      pageX: 100,
      pageY: 100,
    });
    const tabNames = ["Apex_582", "entryPointFn"];
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).trigger("mousemove", {
        x: 470 + NODE_X,
        y: 80 + NODE_Y,
        force: true,
      });
      cy.wait(200);
      cy.wrap(canvas).trigger("mousemove", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: 570 + NODE_X,
        y: NODE_Y,
        force: true,
      });
      cy.wrap(canvas).rightclick(570 + NODE_X, NODE_Y + 50);
      cy.getByTestId("viewNodeInTab").should("not.exist");
      cy.getByTestId("editNode").should("exist").click();
      cy.wait(2000);
      cy.getByTestId("propertiesPanel").should("exist");
    });
    cy.wait(1000);
    cy.getByTestId("invokeTargetInput").click();
    //set Invoke target value
    cy.get('div[data-value="entrypointfn"]').should("exist");
    cy.get('div[data-value="entrypointfn"]').click();
    cy.get("button").should("contain", "entryPointFn");
    cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
    cy.getByTestId("propsPanelApplyBtn").click();
    cy.getByTestId("propertiesPanel").should("not.exist");
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wait(2000);
      cy.wrap(canvas).rightclick(570 + NODE_X, NODE_Y + 50);
      cy.getByTestId("viewNodeInTab").should("exist");
      cy.getByTestId("viewNodeInTab").click();
      cy.wait(5000);

      cy.getByTestId("designerDebugTabs")
        .find("button[role='tab']")
        .then((tabs) => {
          expect(tabs.length).to.equal(tabNames.length);
          for (let x = 0; x < tabNames.length; x++) {
            expect(tabs[x]).to.contain.text(tabNames[x]);
          }
        });
    });
  });

  it("should right-click on a node in the canvas, click one Delete Node + Subtree, and verify it no longer exists", () => {
    cy.fixture("loadrule-Batch_Activity_RS-Apex_582.json").then(
      (nodeDetails) => {
        cy.wait(2000);
        cy.getByTestId("mainGraphCanvas").then(($canvas) => {
          const canvas = $canvas[0];
          const initialCanvasTab = $canvas[0].toDataURL();
          cy.wrap(canvas).trigger("mousemove", {
            focus: true,
            x: nodeDetails.nodes[2].x,
            y: nodeDetails.nodes[2].y,
          });
          cy.wrap(canvas).rightclick(
            nodeDetails.nodes[2].x,
            nodeDetails.nodes[2].y,
          );
          cy.getByTestId("deleteNodeButton")
            .should("exist")
            .trigger("mouseover");
          cy.getByTestId("deleteNodeAndSubTree").click();
          cy.getByTestId("mainGraphCanvas").then((canvasAfterDeletion) => {
            const newCanvasState = canvasAfterDeletion[0].toDataURL();
            expect(initialCanvasTab).not.be.equal(newCanvasState);
          });
        });
      },
    );
  });

  it("tests the Undo and Redo functionality in graph", () => {
    cy.fixture("loadrule-Batch_Activity_RS-Apex_582.json").then(
      (nodeDetails) => {
        cy.wait(2000);
        cy.getByTestId("mainGraphCanvas").then(($canvas) => {
          const canvas = $canvas[0];
          //check the Undo and Redo buttons should exits and disabled
          cy.getByTestId("undoButton").should("exist");
          cy.getByTestId("undoButton").should("be.disabled");
          cy.getByTestId("redoButton").should("exist");
          cy.getByTestId("redoButton").should("be.disabled");

          // delete the node in graph
          cy.wrap(canvas).trigger("mousemove", {
            focus: true,
            x: nodeDetails.nodes[2].x,
            y: nodeDetails.nodes[2].y,
          });
          cy.wrap(canvas).rightclick(
            nodeDetails.nodes[2].x,
            nodeDetails.nodes[2].y,
          );
          cy.getByTestId("deleteNodeButton")
            .should("exist")
            .trigger("mouseover");
          cy.getByTestId("deleteNode").click();

          //check the Undo should be enabled
          cy.getByTestId("undoButton").should("exist");
          cy.getByTestId("undoButton").should("not.be.disabled");
          const initialCanvasTab = $canvas[0].toDataURL();

          cy.getByTestId("mainGraphCanvas").then((canvasAfterDeletion) => {
            const newCanvasState = canvasAfterDeletion[0].toDataURL();
            expect(initialCanvasTab).not.be.equal(newCanvasState);
          });
          cy.getByTestId("undoButton").click();
          cy.getByTestId("redoButton").should("exist");
          cy.getByTestId("redoButton").should("not.be.disabled");
          cy.getByTestId("mainGraphCanvas").then((canvasAfterDeletion) => {
            const newCanvasState = canvasAfterDeletion[0].toDataURL();
            expect(initialCanvasTab).be.equal(newCanvasState);
          });
        });
      },
    );
  });

  it("should display properties panel header as 'Properties' if graph is in read-only mode else 'Edit properties'", () => {
    cy.wait(1000);
    cy.emit("uncaught:exception", () => false);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const ctx = canvas.getContext("2d");
      cy.wait(2000);
      expect(ctx).to.not.be.undefined;
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 210 + NODE_X,
        y: 110 + NODE_Y,
      });
      cy.wrap(canvas).dblclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("propertiesPanelHeader").should("exist");
      cy.getByTestId("propertiesPanelHeader").should(
        "have.text",
        "Edit Properties",
      );
      cy.once("uncaught:exception", () => false);
      cy.wait(2000);
    });

    cy.visit(
      "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/Apex_583",
    );
    cy.wait(1000);
    cy.emit("uncaught:exception", () => false);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const ctx = canvas.getContext("2d");
      cy.wait(2000);
      expect(ctx).to.not.be.undefined;
      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: 210 + NODE_X,
        y: 110 + NODE_Y,
      });
      cy.wrap(canvas).dblclick(210 + NODE_X, 110 + NODE_Y);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("propertiesPanelHeader").should("exist");
      cy.getByTestId("propertiesPanelHeader").should("have.text", "Properties");
      cy.once("uncaught:exception", () => false);
      cy.wait(2000);
    });
  });

  it("should display associated items", () => {
    // most of the associated items testing is done in decision-table.cy.ts, so just testing a few things here
    testAssociatedRecordsSheet("APEX_582");
    testAssociatedRecordsGrid("No results.");
  });

  it("should test if the view code link is present in the more actions menu", () => {
    cy.getByTestId("nav-menu-more").should("exist").click({ force: true });
    cy.getByTestId("viewCodeLink")
      .should("exist")
      .should(
        "have.attr",
        "href",
        "/rule-designer/code-viewer?graphName=APEX_582&parentName=Batch_Activity_RS&type=RULE",
      );
  });

  it("verify that return node does not show expression field for rule", () => {
    // Add a return node to rule
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];

      // Add a Return node to the rule
      const returnNodeX = 400 + NODE_X;
      const returnNodeY = NODE_Y;
      cy.getByTestId("return-shape").should("exist");
      cy.getByTestId("return-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX - 100,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wait(500);

      // Open the property panel for the Return node
      cy.wrap(canvas).dblclick(returnNodeX, returnNodeY + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      cy.getByTestId("swcRetExpression").should("not.exist");

      // Verify the properties panel can be closed without requiring an expression
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });
});

describe("new rule", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/_new");
    cy.once("uncaught:exception", () => false);
  });

  it("adds a rule", () => {
    cy.testBrowserTitle("New Rule");
    testFormField("fileFormNameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false);
    testFormField("fileCommitMessageField", "Commit Message", false);

    testNameFieldValidation();

    typeFormField("fileNameInput", "new");
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("btnFileFormSave").click();
    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/new",
    );
  });

  it("checks for duplicate rule set", () => {
    typeFormField("fileNameInput", "duplicate");
    cy.getByTestId("btnFileFormSave").click();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_CHECK_UNIQUE_NAME);
    cy.visit("/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/_new");
  });
});

it("should redirect to page not found when rule does not exist", () => {
  cy.testPageNotFound(
    "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/DoesNotExist",
  );
});
