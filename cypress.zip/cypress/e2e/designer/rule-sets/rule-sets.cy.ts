import { skipOn } from "@cypress/skip-test";
import { getRelativeDate } from "../../../utils/date-utils";
import { openDialog, testDialog } from "../../../utils/dialog-utils";
import {
  testColumnVisibility,
  testFilter,
  testPagination,
  testRow,
  testSort,
  testTable,
  toggleColumnVisibility,
} from "../../../utils/grid-utils";
import {
  testRevisionCompareDialog,
  testRevisionHistoryDialogFromGrid,
  testRollback,
} from "../../../utils/revision-history-utils";
import { deleteArtifact } from "../../../utils/utils";

describe("rule sets", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/rule-sets");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter("Rule Sets");
    cy.testBrowserTitle("Rule Sets");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home"]);

    cy.testSidebar("Designer", "Rule Sets");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays a grid", () => {
    testTable(
      [
        { type: "button", ariaLabel: "Lock Status" },
        "Name",
        "Tags",
        "Last Committed",
        "Actions",
      ],
      [
        { type: "button", value: "checked out by me" },
        "Batch_Activity_RS",
        { type: "tags", tags: ["TechnicalLibrary"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for Batch_Activity_RS",
          },
          { type: "button", value: "delete rule set Batch_Activity_RS" },
        ],
      ],
    );
    testFilter("AG", [
      "",
      "Batch_AG_Letter_RS",
      "",
      getRelativeDate("2022-05-03 11:28:33 -0400"),
      { type: "button", value: "view revision history for Batch_AG_Letter_RS" },
    ]);
    testFilter("Technical", [
      { type: "button", value: "checked out by me" },
      "Batch_Activity_RS",
      { type: "tags", tags: ["TechnicalLibrary"] },
      getRelativeDate("2024-05-03 13:13:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for Batch_Activity_RS",
        },
        { type: "button", value: "delete rule set Batch_Activity_RS" },
      ],
    ]);
    testSort(
      1,
      [
        "",
        "testZeros000",
        "",
        getRelativeDate("2024-05-23 13:47:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for testZeros000",
          },
        ],
      ],
      [
        { type: "button", value: "checked out by me" },
        "Batch_Activity_RS",
        { type: "tags", tags: ["TechnicalLibrary"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for Batch_Activity_RS",
          },
          { type: "button", value: "delete rule set Batch_Activity_RS" },
        ],
      ],
    );
    testPagination(21, 21, ["Batch_PH_RealTime_RS", "", "", "", ""]);
    testColumnVisibility([
      "Lock Status",
      "Tags",
      "Last Committed",
      "Committed By",
      "Message",
    ]);
    toggleColumnVisibility(
      "Committed By",
      ["", "Name", "Tags", "Last Committed", "Committed By", "Actions"],
      [
        { type: "button", value: "checked out by me" },
        "Batch_Activity_RS",
        { type: "tags", tags: ["TechnicalLibrary"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        { type: "email", value: "mdickson@healthedge.com" },
        [
          {
            type: "button",
            value: "view revision history for Batch_Activity_RS",
          },
          { type: "button", value: "delete rule set Batch_Activity_RS" },
        ],
      ],
    );
  });

  it("should sort columns with trailing zeroes correctly", () => {
    // sort by name asc
    cy.getByTestId("dataTableHeader")
      .find("th:nth-child(2)")
      .as("columnHeader");
    cy.get("@columnHeader").find("button").click();
    testRow(0, [
      { type: "button", value: "checked out by me" },
      "Batch_Activity_RS",
      { type: "tags", tags: ["TechnicalLibrary"] },
      getRelativeDate("2024-05-03 13:13:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for Batch_Activity_RS",
        },
        { type: "button", value: "delete rule set Batch_Activity_RS" },
      ],
    ]);

    // test before filtering
    testRow(18, [
      "",
      "testZeros0",
      "",
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for testZeros0",
        },
      ],
    ]);

    // filter by "testZeros" and check the row
    cy.getByTestId("dataTableFilterInput").type("testZeros");
    cy.wait(510); // wait for 500ms debounce
    testRow(0, [
      "",
      "testZeros0",
      "",
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for testZeros0",
        },
      ],
    ]);
    testRow(1, [
      "",
      "testZeros00",
      "",
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for testZeros00",
        },
      ],
    ]);
    testRow(2, [
      "",
      "testZeros000",
      "",
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for testZeros000",
        },
      ],
    ]);

    // sort by name desc
    cy.get("@columnHeader").find("button").click();
    testRow(0, [
      "",
      "testZeros000",
      "",
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for testZeros000",
        },
      ],
    ]);
    testRow(1, [
      "",
      "testZeros00",
      "",
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for testZeros00",
        },
      ],
    ]);
    testRow(2, [
      "",
      "testZeros0",
      "",
      getRelativeDate("2024-05-23 13:47:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for testZeros0",
        },
      ],
    ]);
  });

  it("cannot delete a rule set due to non-empty rule set", () => {
    openDialog(cy.getGridRowButtonOrLink(0, 4, 1));
    deleteArtifact("Unable to delete - the rule set is not empty");
  });

  it("navigates to edit a rule set", () => {
    cy.getGridRowButtonOrLink(0, 1).click();
    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS",
    );
  });

  it("navigates to add a rule", () => {
    cy.getByTestId("addRuleSetBtn").click();
    cy.url().should("include", "/rule-designer/designer/rule-sets/_new");
  });

  it("displays revision history", () => {
    testRevisionHistoryDialogFromGrid(0, "Batch_Activity_RS", [
      { type: "checkbox", isChecked: false },
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
      { type: "email", value: "mdickson1@gmail.com" },
      "test",
      { type: "button", value: "Rollback to this revision" },
    ]);
    testRevisionCompareDialog(
      0,
      1,
      2,
      "Batch_Activity_RS (Rule Set)",
      "429e207",
      getRelativeDate("2024-11-13 09:48:12 -0500"),
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
    );
    testRollback(0, 1);
  });
});
