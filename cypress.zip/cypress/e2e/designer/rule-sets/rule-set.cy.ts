import { skipOn } from "@cypress/skip-test";
import { testCommitDialog } from "../../../utils/dialog-utils";
import {
  testDescriptionEditForm,
  testFormField,
  testNameFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import {
  checkPropertiesPanelandNodeValues,
  checkPropertiesPanelApplyButton,
  deleteNodefromDesigner,
  dragNodeFromPalette,
  getLatestNodesDataFromSessionStorage,
  getParentNode,
  nodes,
  openPropertiesPanel,
  testStartNode,
  verifyGraphContent,
} from "../../../utils/graph-utils";
import { testTabs } from "../../../utils/tab-utils";
import {
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";
import {
  testAssociatedRecordsGrid,
  testAssociatedRecordsSheet,
} from "../../../utils/associated-records-utils";
import { NODE_X, NODE_Y } from "../../../utils/constants";

describe("rule set", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/rule-sets/Batch_Activity_RS?designer");
    cy.wait(2000);
    cy.emit("uncaught:exception", () => false);
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter(
      "Batch_Activity_RS",
      "This rule does some really cool stuff",
    );
    cy.testBrowserTitle("[Batch_Activity_RS] Rule Set");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home", "Rule Sets"]);
    cy.testSidebar("Designer", "Rule Sets");
    cy.getByTestId("tags-container").should("exist");
  });

  it("displays tabs", () => {
    testTabs(
      "ruleSetTabs",
      ["Rules", "Rule Set Designer"],
      "Rule Set Designer",
      ["rulesTabPanel", "designerTabPanel"],
    );
  });

  it("edits description", () => {
    testDescriptionEditForm();
  });

  it("navigates directly to the rule set designer tab", () => {
    cy.visit("/rule-designer/designer/rule-sets/Batch_Activity_RS?designer");
    testTabs(
      "ruleSetTabs",
      ["Rules", "Rule Set Designer"],
      "Rule Set Designer",
      ["rulesTabPanel", "designerTabPanel"],
    );
  });

  it("navigates directly to the rules tab", () => {
    cy.visit("/rule-designer/designer/rule-sets/Batch_Activity_RS?rules");
    testTabs("ruleSetTabs", ["Rules", "Rule Set Designer"], "Rules", [
      "rulesTabPanel",
      "designerTabPanel",
    ]);
  });

  it("test graph", () => {
    cy.wait(2000);
    testStartNode("graphScreen");
  });

  it("tests Drag and Drop of the IF node in graph", () => {
    dragNodeFromPalette(nodes.If);
  });

  it("tests Drag and Drop of the FOR node in graph", () => {
    dragNodeFromPalette(nodes.For);
  });

  it("tests Drag and Drop of the Action node in graph", () => {
    dragNodeFromPalette(nodes.Action);
  });

  it("tests Drag and Drop of the Object node in graph", () => {
    dragNodeFromPalette(nodes.Object);
  });

  it("tests Drag and Drop of the Table node in graph", () => {
    dragNodeFromPalette(nodes.Table);
  });

  it("tests Drag and Drop of the Code node in graph", () => {
    dragNodeFromPalette(nodes.Code);
  });

  it("tests Drag and Drop of the Return node in graph", () => {
    dragNodeFromPalette(nodes.Return);
  });

  it("tests Drag and Drop of the Invoke node in graph", () => {
    dragNodeFromPalette(nodes.Invoke);
  });

  it("should redirect to rule set when cancel button is clicked on the graph", () => {
    cy.getByTestId("cancelBtn").click({ force: true });
    cy.url().should("include", "/rule-designer/designer/rule-sets");
  });

  it("modify the Description and save properties panel changes", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(10 + NODE_X, 10 + NODE_Y);
      cy.getByTestId("varDescriptionTextArea").should("exist");
      cy.getByTestId("propsPanelApplyBtn").should("exist");
      cy.getByTestId("propsPanelApplyBtn")
        .should("exist")
        .should("be.disabled");
      cy.getByTestId("varDescriptionTextArea").type("test description");
      cy.getByTestId("propsPanelApplyBtn")
        .should("exist")
        .should("not.be.disabled");
      cy.getByTestId("bottom-drawer-close-btn").should("exist").click();
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });

  it("should close properties panel", () => {
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      cy.wrap(canvas).dblclick(10 + NODE_X, 10 + NODE_Y);
      cy.getByTestId("propsPanelCancelBtn").should("exist");
      cy.getByTestId("propsPanelCancelBtn")
        .should("exist")
        .should("not.be.disabled");
      cy.getByTestId("propsPanelCancelBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });

  it("tests opening properties panel for IF node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.If,
      name: nodes.If,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };

    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for FOR node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.For,
      name: nodes.For,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for ACTION node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Action,
      name: nodes.Action,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for TABLE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Table,
      name: nodes.Table,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for CODE node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Code,
      name: nodes.Code,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for OBJECT node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Object,
      name: nodes.Object,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests opening properties panel for RETURN node in graph", () => {
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Return,
      name: nodes.Return,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode, false);
  });

  it("tests opening properties panel for INVOKE node in graph", () => {
    cy.wait(1000);
    const newNode = {
      id: new Date().getTime().toString(),
      x: 700,
      y: 200,
      type: nodes.Invoke,
      name: nodes.Invoke,
      isToolBar: false,
      isConnecting: false,
      connections: {
        input: null,
        outputs: [],
      },
      connectable: true,
      canConnect: true,
    };
    checkPropertiesPanelandNodeValues(newNode);
  });

  it("tests the Batch_Activity_RS rule all node are displayed properly or not", () => {
    cy.fixture("loadrulegroup-Batch_Activity_RS.json").then((graphDetails) => {
      cy.log(graphDetails);
      graphDetails.nodes.forEach((elem) => {
        verifyGraphContent(elem);
      });
    });
  });

  it("should right-click on a node in the canvas, click on Delete Node + Subtree, and verify it no longer exists", () => {
    //get the canvas object data
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      deleteNodefromDesigner(210, 110, false);
      cy.wait(2000);
    });
  });

  it("should open the dialog when unlock button is clicked with unsaved changes", () => {
    cy.getByTestId("saveGraphButton").should("exist").should("be.disabled");
    dragNodeFromPalette(nodes.Table);
    cy.getByTestId("saveGraphButton").should("exist").should("not.be.disabled");
    cy.getByTestId("lock-button").click({ force: true });
    cy.getByTestId("dialog-container").should("exist");
    cy.getByTestId("dialog-title")
      .should("exist")
      .should("contain.text", "Unsaved Changes");
  });

  it("should display confirmation dialog and confirm when clicking rule tab", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true; // Simulate clicking 'OK'
    });

    dragNodeFromPalette(nodes.If);
    cy.getByTestId("saveGraphButton").should("be.enabled");
    cy.getByTestId("rulesTab").click();
    cy.wait(1000);
    cy.getByTestId("rulesTab").should("have.attr", "data-state", "active");
  });

  it("should display confirmation dialog and cancel when navigating to rules tab with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return false; // Simulate clicking 'Cancel'
    });

    dragNodeFromPalette(nodes.If);
    cy.getByTestId("saveGraphButton").should("be.enabled");
    cy.getByTestId("rulesTab").click();
    cy.wait(1000);
    cy.getByTestId("ruleSetDesignerTab").should(
      "have.attr",
      "data-state",
      "active",
    );
  });

  it("should display associated items", () => {
    // most of the associated items testing is done in decision-table.cy.ts, so just testing a few things here
    testAssociatedRecordsSheet("Batch_Activity_RS");
    testAssociatedRecordsGrid("No results.");
  });

  it("should test if the view code link is present in the more actions menu", () => {
    cy.getByTestId("nav-menu-more").should("exist").click({ force: true });
    cy.getByTestId("viewCodeLink")
      .should("exist")
      .should(
        "have.attr",
        "href",
        "/rule-designer/code-viewer?graphName=Batch_Activity_RS&parentName=&type=RULEGROUP",
      );
  });

  it("verify that return node does not show expression field for rule set", () => {
    // Add a return node to rule set
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];

      // Add a Return node to the rule set
      const returnNodeX = 400 + NODE_X;
      const returnNodeY = NODE_Y;
      cy.getByTestId("return-shape").should("exist");
      cy.getByTestId("return-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX - 100,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wait(500);

      // Open the property panel for the Return node
      cy.wrap(canvas).dblclick(returnNodeX, returnNodeY + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      cy.getByTestId("swcRetExpression").should("not.exist");

      // Verify the properties panel can be closed without requiring an expression
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });
});

describe("new rule set", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/rule-sets/_new");
    cy.once("uncaught:exception", () => false);
  });

  it("adds a rule set", () => {
    cy.testBrowserTitle("New Rule Set");
    testFormField("fileFormNameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false);
    testFormField("fileCommitMessageField", "Commit Message", false);

    testNameFieldValidation();

    typeFormField("fileNameInput", "new");
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("btnFileFormSave").click();
    cy.url().should("include", "/rule-designer/designer/rule-sets/new");
  });

  it("checks for duplicate rule set", () => {
    typeFormField("fileNameInput", "duplicate");
    cy.getByTestId("btnFileFormSave").click();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_CHECK_UNIQUE_NAME);
    cy.visit("/rule-designer/designer/rule-sets/_new");
  });
});

it("should redirect to page not found when rule set does not exist", () => {
  cy.testPageNotFound("/rule-designer/designer/rule-sets/DoesNotExist");
});

/* should test a node can be connected to a new parent node when there are no prior connections exists on the new parent
  Note: Normally this should work as the new parent node should be able to accept connections if it got created in Rules Designer. In case of migrated rules,
   this might not work as expected as nodes might not have the connections object and it's null 
*/
it("should test if a node can be connected to another node if there are no connections exists", () => {
  cy.visit("/rule-designer/designer/rule-sets/Batch_AG_RealTime_RS?designer");
  cy.wait(3000);
  cy.getByTestId("code-shape").trigger("mousedown", {
    which: 1,
    pageX: 100,
    pageY: 200,
  });
  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    cy.wrap(canvas).trigger("mousemove", {
      x: NODE_X - 10,
      y: NODE_Y + 10,
      force: true,
    });
    cy.wait(1000);
    cy.wrap(canvas).trigger("mousemove", {
      x: NODE_X + 100,
      y: NODE_Y + 100,
      force: true,
    });

    cy.wrap(canvas).trigger("mouseup", {
      x: NODE_X + 100,
      y: NODE_Y + 100,
      force: true,
    });
    cy.wait(1000);
    cy.window().then((win) => {
      const nodesData = getLatestNodesDataFromSessionStorage();
      expect(nodesData).to.not.be.undefined;
      const newNode = nodesData[nodesData.length - 1];
      expect(newNode).to.not.be.undefined;
      expect(newNode.type).to.equal(nodes.Code);
      const parentNode = getParentNode(newNode, nodesData);
      expect(parentNode).to.not.be.undefined;
      expect(parentNode.type).to.equal(nodes.Start);
      expect(parentNode.name).to.equal("Batch_AG_RealTime_RS");
    });
  });
});
