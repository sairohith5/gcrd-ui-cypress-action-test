import { skipOn } from "@cypress/skip-test";
import { testToast, ToastMessage, ToastTitle } from "../../utils/toast-utils";
import { TEST_CASES } from "./test-cases/testing-library-utils";

describe("Graph Testing", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/graph");
    cy.wait(2000); // need to wait for the graph to load before doing other things
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter("Graph Testing", "");
    cy.testBrowserTitle("Graph Testing");
    cy.testNavbar("Testing");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Testing", "Graph Testing");
  });
  it("Verify that Debug Panel exits with debug controls", () => {
    cy.getByTestId("debugPanel").should("exist");
    cy.getByTestId("debugBtn").should("exist");
    cy.getByTestId("playBtn").should("exist");
    cy.getByTestId("redoBtn").should("exist");
    cy.getByTestId("stepIntoBtn").should("exist");
    cy.getByTestId("stepOutBtn").should("exist");
    cy.getByTestId("stopBtn").should("exist");
    cy.getByTestId("resetBtn").should("exist");
  });

  it("click on Debug button and verify popup with input ", () => {
    cy.getByTestId("debugBtn").should("exist");
    cy.getByTestId("debugBtn").click();
    cy.getByTestId("inputAccordion").should("have.attr", "data-state", "open");
    cy.getByTestId("graphDebugInput").should("have.class", "border-red-600");
    testToast(ToastTitle.ERROR, "Please provide input data");
  });

  it("Verify that the Input Accordion is clickable and able to expand", () => {
    cy.getByTestId("inputAccordion").should("exist");
    cy.get("div[data-testid='inputAccordion']")
      .find("button")
      .should("have.attr", "data-state", "closed");
    cy.getByTestId("inputAccordion").click();
    cy.wait(2000);
    cy.get("div[data-testid='inputAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");
    cy.getByTestId("inputAccordion").click({ force: true });
  });

  it("Verify that the Output Accordion is clickable and able to expand", () => {
    cy.getByTestId("outputAccordion").should("exist");
    cy.get("div[data-testid='outputAccordion']")
      .find("button")
      .should("have.attr", "data-state", "closed");
    cy.getByTestId("outputAccordion").click();
    cy.wait(2000);
    cy.get("div[data-testid='outputAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");
    cy.getByTestId("outputAccordion").click();
  });
  it("Verify that the Variables Accordion is clickable and able to expand", () => {
    cy.getByTestId("variablesAccordion").should("exist");
    cy.get("div[data-testid='variablesAccordion']")
      .find("button")
      .should("have.attr", "data-state", "closed");
    cy.getByTestId("variablesAccordion").click();
    cy.wait(2000);
    cy.get("div[data-testid='variablesAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");
    cy.getByTestId("variablesAccordion").click();
  });
  it("Verify that the Watch Accordion is clickable and able to expand", () => {
    cy.getByTestId("watchAccordion").should("exist");
    cy.get("div[data-testid='watchAccordion']")
      .find("button")
      .should("have.attr", "data-state", "closed");
    cy.getByTestId("watchAccordion").click();
    cy.wait(2000);
    cy.get("div[data-testid='watchAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");
    cy.getByTestId("watchAccordion").click();
  });
  it("Verify that the Call Stack Accordion is clickable and able to expand", () => {
    cy.getByTestId("callStakAccordion").should("exist");
    cy.get("div[data-testid='callStakAccordion']")
      .find("button")
      .should("have.attr", "data-state", "closed");
    cy.getByTestId("callStakAccordion").click();
    cy.wait(2000);
    cy.get("div[data-testid='callStakAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");
    cy.getByTestId("callStakAccordion").click();
  });
  it("Verify that the Breakpoints Accordion is clickable and able to expand", () => {
    cy.getByTestId("breackPointsAccordion").should("exist");
    cy.get("div[data-testid='breackPointsAccordion']")
      .find("button")
      .should("have.attr", "data-state", "closed");
    cy.getByTestId("breackPointsAccordion").click();
    cy.wait(2000);
    cy.get("div[data-testid='breackPointsAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");
    cy.getByTestId("breackPointsAccordion").click();
  });

  it("tests Full Screen button and Restore button functionality ", () => {
    cy.getByTestId("graphContainer").should("exist");
    cy.getByTestId("graphContainer").and("have.class", "flex");
    cy.getByTestId("maximizeToggleBtn").should("exist");
    cy.getByTestId("maximizeToggleBtn").should("not.be.disabled");
    cy.getByTestId("maximizeToggleBtn").click({ force: true });
    cy.getByTestId("graphContainer").and("have.class", "fullscreen");
    cy.getByTestId("maximizeToggleBtn").click();
    cy.getByTestId("graphContainer").and("have.class", "flex");
  });

  it("Verify that the Zoom to Fit button adjusts the graph view ", () => {
    cy.getByTestId("zoomToFitButton").should("exist");
    cy.getByTestId("zoomToFitButton").click();
  });

  it("Verify the functionality of the Show Mini map button", () => {
    cy.getByTestId("minimapBtn").should("exist");
    cy.getByTestId("minimapBtn").click();
    cy.getByTestId("minimapCanvas").should("be.visible");
    cy.getByTestId("minimapBtn").click();
    cy.getByTestId("minimapCanvas").should("not.be.visible");
  });

  it("Verify that the Cancel button cancels the current action and redirect to Home page", () => {
    cy.getByTestId("cancelBtn").should("exist");
    cy.getByTestId("cancelBtn").click({ force: true });
    cy.wait(2000);
    cy.url().should("include", "/dashboard");
  });

  it("Verify the graph debugging without input", () => {
    cy.getByTestId("debugBtn").click();
  });

  it("test graph input data", () => {
    cy.getByTestId("inputAccordion").click();
    cy.getByTestId("graphDebugInput")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type(
        `{"requestID": "532",
        "memberID": "8229",
        "environmentType": "TEST",
        "schedulerType": "AG_REALTIME",
        "eventSource": "INTAKEDETAILS",
        "eventType": "POST",
        "memberAge": 28`,
        { delay: 0 },
      );
    cy.getByTestId("playBtn").should("exist").should("be.disabled");
    cy.getByTestId("debugBtn").click();
    cy.getByTestId("playBtn").should("exist").should("be.enabled");
    cy.getByTestId("redoBtn").should("exist").should("be.enabled");
    cy.getByTestId("stepIntoBtn").should("exist").should("be.enabled");
    cy.getByTestId("stepOutBtn").should("exist").should("be.enabled");
    cy.getByTestId("stopBtn").should("exist").should("be.enabled");
    cy.getByTestId("playBtn").click();
    cy.getByTestId("outputAccordion").click();
    cy.getByTestId("graphDebugOutput").should(
      "contain.text",
      "cbhEligibilityList",
    );
    cy.getByTestId("graphDebugOutput").should("contain.text", "isTrue:true");
    cy.getByTestId("variablesAccordion").click();
    cy.getByTestId("variablesAccordionContent").should(
      "contain.text",
      "theRequest",
    );
    cy.getByTestId("resetBtn").should("exist").click();
    cy.getByTestId("graphDebugInput")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-overlays")
      .children()
      .then((children) => {
        expect(children).to.have.length(1);
      });
  });

  it("should test watch expressions feature", () => {
    cy.getByTestId("watchAccordion").click();
    cy.getByTestId("addWatchExpressionBtn").should("exist");
    cy.getByTestId("addWatchExpressionBtn").should("be.disabled");

    cy.getByTestId("deleteAllWatchExpressionsBtn").should("exist");
    cy.getByTestId("deleteAllWatchExpressionsBtn").should("be.enabled");

    cy.getByTestId("inputAccordion").click();
    cy.getByTestId("graphDebugInput")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type(
        `{"requestID": "532",
        "memberID": "8229",
        "environmentType": "TEST",
        "schedulerType": "AG_REALTIME",
        "eventSource": "INTAKEDETAILS",
        "eventType": "POST",
        "memberAge": 28`,
        { delay: 0 },
      );
    cy.getByTestId("playBtn").should("exist").should("be.disabled");
    cy.getByTestId("debugBtn").click();

    cy.getByTestId("addWatchExpressionBtn").should("exist");
    cy.getByTestId("addWatchExpressionBtn").should("not.be.disabled");

    cy.getByTestId("deleteAllWatchExpressionsBtn").should("be.enabled");

    cy.getByTestId("addWatchExpressionBtn").click();

    cy.getByTestId("watchExpressionInput")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type(`theRequest`, { delay: 0 });
    cy.getByTestId("applyWatchExpressionButton").should("exist").click();
    cy.getByTestId("show-more-button").should("exist");
    cy.getByTestId("copy-button").should("exist");
    cy.getByTestId("watchExpression").should("have.length", 4);
    cy.getByTestId("deleteWatchExpressionButton3").should("exist").click();
    cy.getByTestId("watchExpression").should("have.length", 3);

    //test delete all watch expressions
    cy.getByTestId("deleteAllWatchExpressionsBtn").should("exist").click();
    cy.getByTestId("watchExpression").should("have.length", 0);
    cy.getByTestId("deleteAllWatchExpressionsBtn").should("be.disabled");
  });
});

describe("graph testing from the test cases list screen", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases");
    cy.getGridRowButtonOrLink(
      0,
      TEST_CASES.ACTION_COL_INDEX,
      TEST_CASES.GRAPH_TESTING_BTN_INDEX,
    ).click();

    cy.wait(2000); // need to wait for the graph to load before doing other things
    cy.url().should(
      "include",
      "/rule-designer/rule-testing/graph?testCase=TestFile1",
    );
  });

  it("should open graph testing from the test cases list screen", () => {
    // verify input accordion is expanded...
    cy.getByTestId("inputAccordion").should("exist");
    cy.get("div[data-testid='inputAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");

    // ... contains input data indicator and screen reader text...
    cy.getByTestId("inputAccordion")
      .find("button .graph-accordion-text span[data-testid='inputDataPresent']")
      .should("exist");
    cy.getByTestId("inputAccordion")
      .find("button .graph-accordion-text span.sr-only")
      .should("exist")
      .contains("Input data provided from TestFile1");

    // ... and contains input data
    cy.getByTestId("graphDebugInput")
      .should("exist")
      .contains(`"requestID": "0"`);
  });

  it("should replace input data with new test case", () => {
    // go back to test cases screen and select another test case
    cy.visit("/rule-designer/rule-testing/test-cases");
    cy.getGridRowButtonOrLink(
      1,
      TEST_CASES.ACTION_COL_INDEX,
      TEST_CASES.GRAPH_TESTING_BTN_INDEX,
    ).click();

    cy.wait(2000); // need to wait for the graph to load before doing other things
    cy.url().should(
      "include",
      "/rule-designer/rule-testing/graph?testCase=DeleteMe",
    );
    cy.getByTestId("graphDebugInput").should("exist").contains("{}");
  });
});

describe("graph testing from the test cases list screen", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases/TestFile1");
    cy.getByTestId("nav-menu-more").should("exist").click();
    cy.getByTestId("openGraphTestBtn")
      .should("exist")
      .contains("Open Graph Test")
      .click();

    cy.wait(2000); // need to wait for the graph to load before doing other things
    cy.url().should(
      "include",
      "/rule-designer/rule-testing/graph?testCase=TestFile1",
    );
  });

  it("should open graph testing from the test case detail screen", () => {
    // verify input accordion is expanded...
    cy.getByTestId("inputAccordion").should("exist");
    cy.get("div[data-testid='inputAccordion']")
      .find("button")
      .should("have.attr", "data-state", "open");

    // ... contains input data indicator and screen reader text...
    cy.getByTestId("inputAccordion")
      .find("button .graph-accordion-text span[data-testid='inputDataPresent']")
      .should("exist");
    cy.getByTestId("inputAccordion")
      .find("button .graph-accordion-text span.sr-only")
      .should("exist")
      .contains("Input data provided from TestFile1");

    // ... and contains input data
    cy.getByTestId("graphDebugInput")
      .should("exist")
      .contains(`"requestID": "0"`);
  });
});
