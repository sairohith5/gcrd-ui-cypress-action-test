export const TEST_CASES = {
  CHECKBOX_COL_INDEX: 0,
  LOCK_STATUS_COL_INDEX: 1,
  NAME_COL_INDEX: 2,
  TAGS_COL_INDEX: 3,
  LAST_COMMITTED_COL_INDEX: 4,
  RESULTS_COL_INDEX: 5,
  ACTION_COL_INDEX: 6,
  EXECUTE_BTN_INDEX: 0,
  GRAPH_TESTING_BTN_INDEX: 1,
  REVISION_BTN_INDEX: 2,
  CLONE_BTN_INDEX: 3,
  DELETE_BTN_INDEX: 4,
};

export function testOutputLine(
  lineIndex: number,
  text: string,
  highlight: "added" | "removed" | "modified" | "unchanged",
  isExpected: boolean = false,
  passingTest: boolean = false,
) {
  cy.getByTestId("json-diff-viewer-" + (isExpected ? "expected" : "actual"))
    .should("exist")
    .as("output");

  if (passingTest) {
    // for passing tests all lines should be unchanged
    highlight = "unchanged";

    cy.get("@output").contains(text);
  } else {
    cy.get("@output")
      .find("span")
      .eq(lineIndex)
      .contains(text)
      .should("have.class", highlight);
  }
}

export function testHighlightCounts(
  removedCount: number | null,
  addedCount: number | null,
  modifiedCount: number | null,
  isExpected: boolean = false,
) {
  if (removedCount !== null) {
    cy.getByTestId(
      "json-diff-viewer-removed-" + (isExpected ? "expected" : "actual"),
    )
      .should("exist")
      .contains("-" + removedCount);
  } else {
    cy.getByTestId(
      "json-diff-viewer-removed-" + (isExpected ? "expected" : "actual"),
    ).should("not.exist");
  }
  if (addedCount !== null) {
    cy.getByTestId(
      "json-diff-viewer-added-" + (isExpected ? "expected" : "actual"),
    )
      .should("exist")
      .contains("+" + addedCount);
  } else {
    cy.getByTestId(
      "json-diff-viewer-added-" + (isExpected ? "expected" : "actual"),
    ).should("not.exist");
  }
  if (modifiedCount !== null) {
    cy.getByTestId(
      "json-diff-viewer-modified-" + (isExpected ? "expected" : "actual"),
    )
      .should("exist")
      .contains("~" + modifiedCount);
  } else {
    cy.getByTestId(
      "json-diff-viewer-modified-" + (isExpected ? "expected" : "actual"),
    ).should("not.exist");
  }
}
