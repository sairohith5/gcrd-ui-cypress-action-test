import {
  cancelDialog,
  openDialog,
  submitDialog,
  testDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";
import {
  clickGridRow,
  clickTableHeaderButton,
  isColumnChecked,
  isColumnHeaderChecked,
  testColumnIcon,
} from "../../../utils/grid-utils";
import { replaceTextInEditor } from "../../../utils/monaco-utils";
import {
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";
import {
  TEST_CASES,
  testHighlightCounts,
  testOutputLine,
} from "./testing-library-utils";

function executeTestFromMoreActions() {
  cy.getByTestId("nav-menu-more").should("exist").click();
  cy.getByTestId("executeTestBtn").should("exist").click();
  testIsDialogDisplayed();
}

describe("single test case execution from list screen", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases");
  });

  it("executes a test case and shows results for a passing test", () => {
    cy.getGridRowButtonOrLink(
      0,
      TEST_CASES.ACTION_COL_INDEX,
      TEST_CASES.EXECUTE_BTN_INDEX,
    ).click();

    testIsDialogDisplayed();
    cy.getByTestId("dialog-title").contains("Test Result: TestFile1");
    cy.getByTestId("test-result-status").contains("PASSED");

    // expected output
    cy.getByTestId("json-diff-viewer-title-expected")
      .should("exist")
      .contains("Expected Output");
    testOutputLine(0, "{", "unchanged", true, true);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", true, true);
    testOutputLine(2, '"requestID": 124,', "unchanged", true, true);

    // actual output
    cy.getByTestId("json-diff-viewer-title-actual")
      .should("exist")
      .contains("Actual Output");
    testOutputLine(0, "{", "unchanged", false, true);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", false, true);
    testOutputLine(2, '"requestID": 124,', "unchanged", false, true);

    cy.getByTestId("dialog-cancel-button").click();
    testDialogIsNotDisplayed();
  });

  it("executes a test case and shows results for a failed test", () => {
    cy.getGridRowButtonOrLink(
      4,
      TEST_CASES.ACTION_COL_INDEX,
      TEST_CASES.EXECUTE_BTN_INDEX,
    ).click();

    testIsDialogDisplayed();
    cy.getByTestId("dialog-title").contains("Test Result: TestFile3");
    cy.getByTestId("test-result-status").contains("FAILED");

    // expected output
    cy.getByTestId("json-diff-viewer-title-expected")
      .should("exist")
      .contains("Expected Output");
    cy.getByTestId("json-diff-viewer-expected")
      .should("exist")
      .as("expectedOutput");
    testOutputLine(0, "{", "unchanged", true);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", true);
    testOutputLine(2, '"requestID": 124,', "modified", true);
    testOutputLine(3, '"memberID": "ALT124"', "modified", true);
    testOutputLine(4, "}", "unchanged", true);
    testHighlightCounts(null, null, 2, true);
    cy.getByTestId("copy-expected-output-btn").should("exist").contains("Copy"); // not able to interact reliably with clipboard in cypress tests

    // actual output
    cy.getByTestId("json-diff-viewer-title-actual")
      .should("exist")
      .contains("Actual Output");
    testOutputLine(0, "{", "unchanged", false);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", false);
    testOutputLine(2, '"requestID": 123,', "modified", false);
    testOutputLine(3, '"memberID": "ALT123"', "modified", false);
    testOutputLine(4, "}", "unchanged", false);
    testHighlightCounts(null, null, 2, false);
    cy.getByTestId("copy-actual-output-btn").should("exist").contains("Copy"); // not able to interact reliably with clipboard in cypress tests
  });

  it("reports api error when executing a test case", () => {
    cy.getGridRowButtonOrLink(
      3,
      TEST_CASES.ACTION_COL_INDEX,
      TEST_CASES.EXECUTE_BTN_INDEX,
    ).click();

    cy.wait(2000); // the dialog appears quickly and then should disappear once we get the error response

    testDialogIsNotDisplayed();
    testToast(ToastTitle.ERROR, "Sample error message coming from API");
  });
});

describe("single test case execution from the detail screen", () => {
  beforeEach(() => {});

  it("should execute a test case for a checked-out test case", () => {
    cy.visit("/rule-designer/rule-testing/test-cases/TestFile1");
    cy.get("div[data-testid='inputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");
    cy.get("div[data-testid='outputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");

    cy.getByTestId("nav-menu-more").should("exist").click();
    cy.getByTestId("executeTestBtn")
      .should("exist")
      .contains("Execute Test")
      .click();

    testIsDialogDisplayed();
    cy.getByTestId("dialog-title").contains("Test Result: TestFile1");
    cy.getByTestId("test-result-status").contains("PASSED");

    // expected output
    cy.getByTestId("json-diff-viewer-title-expected")
      .should("exist")
      .contains("Expected Output");
    testOutputLine(0, "{", "unchanged", true, true);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", true, true);
    testOutputLine(2, '"requestID": 124,', "unchanged", true, true);

    // actual output
    cy.getByTestId("json-diff-viewer-title-actual")
      .should("exist")
      .contains("Actual Output");
    testOutputLine(0, "{", "unchanged", false, true);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", false, true);
    testOutputLine(2, '"requestID": 124,', "unchanged", false, true);

    cy.getByTestId("dialog-cancel-button").click();
    testDialogIsNotDisplayed();
  });

  it("should execute a test case for a readonly test case", () => {
    cy.visit("/rule-designer/rule-testing/test-cases/TestFile3");
    cy.get("div[data-testid='inputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");
    cy.get("div[data-testid='outputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");

    cy.getByTestId("nav-menu-more").should("exist").click();
    cy.getByTestId("executeTestBtn").should("exist").click();

    testIsDialogDisplayed();
    cy.getByTestId("dialog-title").contains("Test Result: TestFile3");
    cy.getByTestId("test-result-status").contains("FAILED");

    // expected output
    cy.getByTestId("json-diff-viewer-title-expected")
      .should("exist")
      .contains("Expected Output");
    cy.getByTestId("json-diff-viewer-expected")
      .should("exist")
      .as("expectedOutput");
    testOutputLine(0, "{", "unchanged", true);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", true);
    testOutputLine(2, '"requestID": 124,', "modified", true);
    testOutputLine(3, '"memberID": "ALT124"', "modified", true);
    testOutputLine(4, "}", "unchanged", true);
    testHighlightCounts(null, null, 2, true);
    cy.getByTestId("copy-expected-output-btn").should("exist").contains("Copy"); // not able to interact reliably with clipboard in cypress tests

    // actual output
    cy.getByTestId("json-diff-viewer-title-actual")
      .should("exist")
      .contains("Actual Output");
    testOutputLine(0, "{", "unchanged", false);
    testOutputLine(1, '"cbhEligibilityList": [],', "unchanged", false);
    testOutputLine(2, '"requestID": 123,', "modified", false);
    testOutputLine(3, '"memberID": "ALT123"', "modified", false);
    testOutputLine(4, "}", "unchanged", false);
    testHighlightCounts(null, null, 2, false);
    cy.getByTestId("copy-actual-output-btn").should("exist").contains("Copy"); // not able to interact reliably with clipboard in cypress tests
  });

  it("should toggle wrapping test results text", () => {
    cy.visit("/rule-designer/rule-testing/test-cases/TestFile4");
    cy.get("div[data-testid='inputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");
    cy.get("div[data-testid='outputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");

    cy.getByTestId("nav-menu-more").should("exist").click();
    cy.getByTestId("executeTestBtn")
      .should("exist")
      .contains("Execute Test")
      .click();

    testIsDialogDisplayed();
    cy.getByTestId("dialog-title").contains("Test Result: TestFile4");

    cy.getByTestId("wrap-text-toggle")
      .should("exist")
      .should("have.attr", "data-state", "unchecked");

    cy.get("label[for='wrapTextToggle']").should("exist").contains("Wrap Text");

    // verify text is not wrapped by default
    cy.getByTestId("json-diff-viewer-expected")
      .should("have.class", "no-wrap")
      .find("span")
      .eq(7)
      .shouldNotWrapText();
    cy.getByTestId("json-diff-viewer-actual")
      .should("have.class", "no-wrap")
      .find("span")
      .eq(7)
      .shouldNotWrapText();

    // enable text wrapping
    cy.getByTestId("wrap-text-toggle").click();
    cy.getByTestId("json-diff-viewer-expected")
      .should("have.class", "wrap")
      .find("span")
      .eq(7)
      .shouldWrapText();
    cy.getByTestId("json-diff-viewer-actual")
      .should("have.class", "wrap")
      .find("span")
      .eq(7)
      .shouldWrapText();
  });
});

describe("bulk test case execution from list screen", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases");
  });

  it("should enable/disable the bulk execute button based on selection", () => {
    // execute tests button should not be visible when no rows are selected
    cy.getByTestId("bulk-execute-btn").should("not.exist");

    // select a single row and make sure the execute tests button appears
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX);
    cy.getByTestId("bulk-execute-btn")
      .should("exist")
      .contains("Execute Selected");
    isColumnHeaderChecked(TEST_CASES.CHECKBOX_COL_INDEX, "indeterminate");
    // deselect the row and make sure the execute tests button disappears
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX);
    cy.getByTestId("bulk-execute-btn").should("not.exist");

    // click the select all checkbox and make sure each row gets selected
    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX); // select all
    cy.getByTestId("bulk-execute-btn").should("exist");
    for (let row = 0; row <= 5; row++) {
      isColumnChecked(row, TEST_CASES.CHECKBOX_COL_INDEX, "checked");
    }

    // click the select all checkbox again to clear all selections
    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX); // clear all
    cy.getByTestId("bulk-execute-btn").should("not.exist");
    for (let row = 0; row <= 5; row++) {
      isColumnChecked(row, TEST_CASES.CHECKBOX_COL_INDEX, "unchecked");
    }

    // click the select all checkbox and then deselect a single row to make sure the select all checkbox gets cleared
    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX); // select all
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX); // deselect a single row
    cy.getByTestId("bulk-execute-btn").should("exist");
    isColumnHeaderChecked(TEST_CASES.CHECKBOX_COL_INDEX, "indeterminate");
    isColumnChecked(0, TEST_CASES.CHECKBOX_COL_INDEX, "unchecked");
    for (let row = 1; row <= 5; row++) {
      isColumnChecked(row, TEST_CASES.CHECKBOX_COL_INDEX, "checked");
    }
  });

  it("should execute multiple test cases and show results", () => {
    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX); // select all
    cy.getByTestId("bulk-execute-btn").should("exist").click();

    testToast(
      ToastTitle.TEST_SUMMARY,
      "5 passed, 1 failed out of 6 tests run.",
    );

    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 1, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 2, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 3, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 4, "x", "Failed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 5, "check", "Passed");

    cy.getByTestId("clear-test-results-btn").should("exist").click();
  });

  it("should clear test results", () => {
    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX); // select all
    cy.getByTestId("bulk-execute-btn").should("exist").click();
    cy.wait(1000);
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");

    cy.getByTestId("clear-test-results-btn")
      .should("exist")
      .contains("Clear Results")
      .click();
    cy.wait(1000);
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "", "");
  });

  it("should store test results until cleared even after navigating away and reloading", () => {
    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX); // select all
    cy.getByTestId("bulk-execute-btn").should("exist").click();
    testToast(
      ToastTitle.TEST_SUMMARY,
      "5 passed, 1 failed out of 6 tests run.",
    );
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");
    cy.visit("/dashboard");
    cy.wait(1000);
    cy.visit("/rule-designer/rule-testing/test-cases");
    cy.wait(1000);
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");

    cy.reload();
    cy.wait(1000);
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");

    cy.getByTestId("clear-test-results-btn").should("exist").click();
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "", "");
  });
});

describe("execute all tests button", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases");
  });

  it("should toggle between displaying Execute All and Execute Selected based on selection", () => {
    // initial load:
    cy.getByTestId("execute-all-tests-btn")
      .should("exist")
      .contains("Execute All");
    cy.getByTestId("bulk-execute-btn").should("not.exist");

    // select a single row:
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX);
    cy.getByTestId("bulk-execute-btn")
      .should("exist")
      .contains("Execute Selected");
    cy.getByTestId("execute-all-tests-btn").should("not.exist");

    // clear selection:
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX);
    cy.getByTestId("execute-all-tests-btn")
      .should("exist")
      .contains("Execute All");
    cy.getByTestId("bulk-execute-btn").should("not.exist");

    // select all rows:
    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX); // select all
    cy.getByTestId("bulk-execute-btn")
      .should("exist")
      .contains("Execute Selected");
    cy.getByTestId("execute-all-tests-btn").should("not.exist");

    clickTableHeaderButton(TEST_CASES.CHECKBOX_COL_INDEX);
  });

  it("should execute all tests when clicking Execute All Tests button", () => {
    cy.getByTestId("execute-all-tests-btn").should("exist").click();

    testDialog(
      cy.getByTestId("execute-all-tests-btn"),
      "Execute All Tests",
      "Execute",
    );
    openDialog(cy.getByTestId("execute-all-tests-btn"));
    cy.getByTestId("execute-all-confirmation").contains(
      "This may take a while depending on the number of tests. Please do not navigate away while the tests are running.",
    );
    cy.getByTestId("execute-all-confirmation").contains(
      "Are you sure you want to execute ALL test cases?",
    );
    submitDialog();

    testToast(
      ToastTitle.TEST_SUMMARY,
      "5 passed, 1 failed out of 6 tests run.",
    );
  });
});

describe("saving actual output to expected output", () => {
  it("displays the Save as Expected Output button for a checked-out test case", () => {
    cy.visit("/rule-designer/rule-testing/test-cases/saveActualOutput");
    cy.wait(2000);

    executeTestFromMoreActions();
    cy.getByTestId("test-result-status").contains("FAILED");

    // verify Save as Expected Output button appears and is enabled
    cy.getByTestId("save-result-as-expected-btn")
      .should("exist")
      .and("be.enabled")
      .contains("Save as Expected Output")
      .focus();

    cy.get('span[data-testid="save-result-tooltip"]')
      .should("be.visible")
      .and("contain", "Replace expected output with actual result");

    cancelDialog();
    testDialogIsNotDisplayed();

    // make a change to the test case and verify the Save as Expected Output button is disabled
    replaceTextInEditor(
      '{ "test": "edited" }',
      "div[data-testid='inputEditor']",
    );

    executeTestFromMoreActions();
    cy.getByTestId("save-result-as-expected-btn")
      .should("exist")
      .and("be.disabled")
      .trigger("mouseover", { force: true }); // not able to test hover tooltip text in cypress

    // CANNOT GET THIS TO WORK WITH CYPRESS:
    // cy.get('span[data-testid="save-result-tooltip"]')
    //   .should("exist")
    //   .should("be.visible")
    //   .and(
    //     "contain",
    //     "Test case has unsaved changes that would be overwritten",
    //   );

    // save the change and verify the Save as Expected Output button is no longer disabled
    cancelDialog();
    testDialogIsNotDisplayed();
    cy.getByTestId("saveBtn").click();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
    executeTestFromMoreActions();
    cy.getByTestId("save-result-as-expected-btn")
      .should("exist")
      .and("be.enabled");
  });

  it("should not display the Save as Expected Output button for a passing test", () => {
    cy.visit("/rule-designer/rule-testing/test-cases");
    cy.wait(2000);

    cy.getGridRowButtonOrLink(
      0,
      TEST_CASES.ACTION_COL_INDEX,
      TEST_CASES.EXECUTE_BTN_INDEX,
    ).click();

    testIsDialogDisplayed();
    cy.getByTestId("test-result-status").contains("PASSED");

    // verify Save as Expected Output button does not appear
    cy.getByTestId("save-result-as-expected-btn").should("not.exist");

    cancelDialog();
    testDialogIsNotDisplayed();
  });

  it("should disable the Save as Expected Output button if the test case is not checked out", () => {
    cy.visit(
      "/rule-designer/rule-testing/test-cases/saveActualOutputNotCheckedOut",
    );
    cy.wait(2000);

    cy.getByTestId("nav-menu-more").should("exist").click();
    cy.getByTestId("executeTestBtn").should("exist").click();
    testIsDialogDisplayed();
    cy.getByTestId("test-result-status").contains("FAILED");

    // verify Save as Expected Output button appears and is disabled
    cy.getByTestId("save-result-as-expected-btn")
      .should("exist")
      .and("be.disabled")
      .contains("Save as Expected Output")
      .trigger("mouseover", { force: true }); // need force:true to trigger mouseover on a disabled button

    // CANNOT GET THIS TO WORK WITH CYPRESS:
    // cy.get('span[data-testid="save-result-tooltip"]')
    //   .should("exist")
    //   .should("be.visible")
    //   .and("contain", "Test case must be checked out");
  });

  it("saves the actual output as the expected output", () => {
    cy.visit("/rule-designer/rule-testing/test-cases/saveActualOutput");
    cy.wait(2000);

    cy.getByTestId("outputEditor")
      .should("exist")
      .find("section")
      .contains('"memberID": "ALT124"');

    executeTestFromMoreActions();
    cy.getByTestId("test-result-status").contains("FAILED");

    cy.getByTestId("save-result-as-expected-btn")
      .should("exist")
      .and("be.enabled")
      .click();

    testDialogIsNotDisplayed();
    testToast(
      ToastTitle.SUCCESS,
      "Expected output updated and test case saved.",
    );

    // THIS PART CAN NO LONGER BE MOCK TESTED:
    // cy.getByTestId("outputEditor")
    //   .should("exist")
    //   .find("section")
    //   .contains('"memberID": "ALT123"');
  });
});
