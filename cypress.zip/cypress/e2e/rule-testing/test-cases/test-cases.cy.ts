import { skipOn } from "@cypress/skip-test";
import {
  testAssociatedRecordsGrid,
  testAssociatedRecordsGridRow,
  testAssociatedRecordsSheet,
} from "../../../utils/associated-records-utils";
import { getRelativeDate } from "../../../utils/date-utils";
import {
  openDialog,
  submitDialog,
  testDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";
import {
  clearFormField,
  testFormField,
  testFormFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import {
  clickGridRow,
  testColumnIcon,
  testColumnVisibility,
  testFilter,
  testPagination,
  testRow,
  testSort,
  testTable,
  toggleColumnVisibility,
} from "../../../utils/grid-utils";
import {
  closeRevisionCompareDialog,
  testRevisionCompareDialog,
  testRevisionHistoryDialogFromGrid,
  testRollback,
  verifyTestCaseComparison,
} from "../../../utils/revision-history-utils";
import {
  clickToastActionButton,
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";
import {
  clickAnywhere,
  deleteArtifact,
  verifyHoverTooltip,
} from "../../../utils/utils";
import { TEST_CASES } from "./testing-library-utils";

describe("test cases library", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    cy.testHeaderAndFooter("Test Cases");
    cy.testBrowserTitle("Test Cases");
    cy.testNavbar("Testing");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Testing", "Test Cases");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays a grid", () => {
    testTable(
      [
        { type: "checkbox", ariaLabel: "Select All" },
        { type: "button", ariaLabel: "Lock Status" },
        "Name",
        "Tags",
        "Last Committed",
        "Results",
        "Actions",
      ],
      [
        {
          type: "checkbox",
          isChecked: false,
          value: "Select row for test execution",
        },
        { type: "button", value: "checked out by me" },
        "TestFile1",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        "",
        [
          {
            type: "button",
            value: "execute test for TestFile1",
          },
          { type: "button", value: "open TestFile1 in graph testing" },
          { type: "button", value: "view revision history for TestFile1" },
          { type: "button", value: "clone TestFile1" },
          { type: "button", value: "delete test file TestFile1" },
        ],
      ],
    );
    testRow(3, [
      {
        type: "checkbox",
        isChecked: false,
        value: "Select row for test execution",
      },
      "",
      "TestFile2",
      { type: "tags", tags: ["BusinessLibrary"] },
      getRelativeDate("2022-05-03 11:28:33 -0400"),
      "",
      [
        {
          type: "button",
          value: "execute test for TestFile2",
        },
        { type: "button", value: "open TestFile2 in graph testing" },
        { type: "button", value: "view revision history for TestFile2" },
        { type: "button", value: "clone TestFile2" },
      ],
    ]);

    testFilter("TestFile", [
      {
        type: "checkbox",
        isChecked: false,
        value: "Select row for test execution",
      },
      { type: "button", value: "checked out by me" },
      "TestFile1",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
      getRelativeDate("2024-05-03 13:13:33 -0400"),
      "",
      [
        {
          type: "button",
          value: "execute test for TestFile1",
        },
        { type: "button", value: "open TestFile1 in graph testing" },
        { type: "button", value: "view revision history for TestFile1" },
        { type: "button", value: "clone TestFile1" },
        { type: "button", value: "delete test file TestFile1" },
      ],
    ]);

    testFilter("Technical", [
      {
        type: "checkbox",
        isChecked: false,
        value: "Select row for test execution",
      },
      "",
      "TestFile2",
      { type: "tags", tags: ["BusinessLibrary"] },
      getRelativeDate("2022-05-03 11:28:33 -0400"),
      "",
      [
        {
          type: "button",
          value: "execute test for TestFile2",
        },
        { type: "button", value: "open TestFile2 in graph testing" },
        { type: "button", value: "view revision history for TestFile2" },
        { type: "button", value: "clone TestFile2" },
      ],
    ]);

    testSort(
      2,
      [
        {
          type: "checkbox",
          isChecked: false,
          value: "Select row for test execution",
        },
        { type: "button", value: "checked out by me" },
        "TryToDeleteMe",
        { type: "tags", tags: ["BusinessLibrary"] },
        getRelativeDate("2022-05-03 11:28:33 -0400"),
        "",
        [
          {
            type: "button",
            value: "execute test for TryToDeleteMe",
          },
          { type: "button", value: "open TryToDeleteMe in graph testing" },
          { type: "button", value: "view revision history for TryToDeleteMe" },
          { type: "button", value: "clone TryToDeleteMe" },
          { type: "button", value: "delete test file TryToDeleteMe" },
        ],
      ],
      [
        {
          type: "checkbox",
          isChecked: false,
          value: "Select row for test execution",
        },
        { type: "button", value: "checked out by me" },
        "DeleteMe",
        { type: "tags", tags: ["BusinessLibrary"] },
        getRelativeDate("2022-05-03 11:28:33 -0400"),
        "",
        [
          {
            type: "button",
            value: "execute test for DeleteMe",
          },
          { type: "button", value: "open DeleteMe in graph testing" },
          { type: "button", value: "view revision history for DeleteMe" },
          { type: "button", value: "clone DeleteMe" },
          { type: "button", value: "delete test file DeleteMe" },
        ],
      ],
      "none",
      null,
      [
        {
          type: "checkbox",
          isChecked: false,
          value: "Select row for test execution",
        },
        { type: "button", value: "checked out by me" },
        "TestFile1",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        "",
        [
          {
            type: "button",
            value: "execute test for TestFile1",
          },
          { type: "button", value: "open TestFile1 in graph testing" },
          { type: "button", value: "view revision history for TestFile1" },
          { type: "button", value: "clone TestFile1" },
          { type: "button", value: "delete test file TestFile1" },
        ],
      ],
    );

    testPagination(6);

    testColumnVisibility([
      "Lock Status",
      "Tags",
      "Last Committed",
      "Committed By",
      "Message",
      "Results",
    ]);

    toggleColumnVisibility("Tags", [
      "",
      "",
      "Name",
      "Last Committed",
      "Results",
      "Actions",
    ]);
  });

  it("shows only failed tests when filter button is clicked", () => {
    cy.getByTestId("execute-all-tests-btn").should("exist").click();
    testIsDialogDisplayed();
    submitDialog();
    cy.wait(2000); // wait for tests to complete
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 4, "x", "Failed");

    cy.get("label[for='showFailedOnly']")
      .should("exist")
      .contains("Failed tests only");
    // select failed-only checkbox:
    cy.getByTestId("showFailedOnlyCheckbox")
      .should("exist")
      .should("not.be.checked")
      .click();
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "x", "Failed");

    // unselect failed-only checkbox:
    cy.getByTestId("showFailedOnlyCheckbox").should("exist").click();
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 4, "x", "Failed");

    // filter to show only some tests which are passing:
    cy.getByTestId("dataTableFilterInput").type("DeleteMe");
    cy.wait(510); // wait for 500ms debounce
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 1, "check", "Passed");
    // select failed-only checkbox - should show no rows now:
    cy.getByTestId("showFailedOnlyCheckbox").should("exist").click();
    cy.getByTestId("dataTableContainer")
      .find("tbody tr td")
      .contains("No results.");

    // verify that resetting the filter also clears the failed-only checkbox
    cy.getByTestId("dataTableFilterResetBtn").should("exist").click();
    cy.getByTestId("showFailedOnlyCheckbox").should("not.be.checked");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 0, "check", "Passed");
    testColumnIcon(TEST_CASES.RESULTS_COL_INDEX, 4, "x", "Failed");
  });

  it("deletes a test file", () => {
    testDialog(
      cy.getGridRowButtonOrLink(
        1,
        TEST_CASES.ACTION_COL_INDEX,
        TEST_CASES.DELETE_BTN_INDEX,
      ),
      "Delete Confirmation",
    );
    openDialog(
      cy.getGridRowButtonOrLink(
        1,
        TEST_CASES.ACTION_COL_INDEX,
        TEST_CASES.DELETE_BTN_INDEX,
      ),
    );
    deleteArtifact();
  });

  it("bulk deletes test files", () => {
    skipOn("firefox");
    cy.getByTestId("bulk-delete-btn")
      .should("exist")
      .contains("Delete Selected")
      .should("be.disabled");
    // select a checked-out test case:
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX);
    cy.getByTestId("bulk-delete-btn").should("be.enabled");
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX);
    cy.getByTestId("bulk-delete-btn").should("be.disabled");
    // select one checked-out and one locked test case:
    clickGridRow(2, TEST_CASES.CHECKBOX_COL_INDEX); // select it
    clickGridRow(3, TEST_CASES.CHECKBOX_COL_INDEX); // select it
    cy.getByTestId("bulk-delete-btn").should("be.disabled");
    clickGridRow(3, TEST_CASES.CHECKBOX_COL_INDEX); // deselect it
    cy.getByTestId("bulk-delete-btn").should("be.enabled");

    // test filtering out locked test case re-enables the button:
    clickGridRow(3, TEST_CASES.CHECKBOX_COL_INDEX); // select it
    cy.getByTestId("bulk-delete-btn").should("be.disabled");
    cy.getByTestId("dataTableFilterInput").type("TryToDeleteMe");
    cy.getByTestId("bulk-delete-btn").should("be.enabled");
    cy.getByTestId("dataTableFilterResetBtn").click();
    cy.getByTestId("bulk-delete-btn").should("be.disabled");

    clickGridRow(2, TEST_CASES.CHECKBOX_COL_INDEX); // deselect it
    clickGridRow(3, TEST_CASES.CHECKBOX_COL_INDEX); // deselect it

    // test Failed Tests Only checkbox re-enables the button:
    cy.getByTestId("execute-all-tests-btn").should("exist").click();
    cy.getByTestId("dialog-submit-button").should("exist").click();
    cy.wait(3000); // wait for tests to complete
    clickGridRow(3, TEST_CASES.CHECKBOX_COL_INDEX); // select it
    clickGridRow(4, TEST_CASES.CHECKBOX_COL_INDEX); // select it
    cy.getByTestId("bulk-delete-btn").should("be.disabled");
    // test tooltip on Delete Seelcted button when disabled:
    verifyHoverTooltip(
      "Cannot delete if selected row(s) locked by someone else",
      "bulk-delete-btn",
    );

    cy.getByTestId("showFailedOnlyCheckbox").click();
    cy.getByTestId("bulk-delete-btn").should("be.enabled");
    cy.getByTestId("showFailedOnlyCheckbox").click();
    cy.getByTestId("bulk-delete-btn").should("be.disabled");

    clickGridRow(3, TEST_CASES.CHECKBOX_COL_INDEX); // deselect it

    // test Delete Confirmation dialog and Cancel button:
    openDialog(cy.getByTestId("bulk-delete-btn"));
    testIsDialogDisplayed();
    cy.getByTestId("dialog-title").contains("Delete Confirmation");
    cy.getByTestId("dialog-destructive-button").contains("Delete");
    cy.getByTestId("dialog-cancel-button").contains("Cancel").click();
    testDialogIsNotDisplayed();
    clickGridRow(4, TEST_CASES.CHECKBOX_COL_INDEX); // deselect it

    // test deleting the selected test cases:
    clickGridRow(0, TEST_CASES.CHECKBOX_COL_INDEX);
    clickGridRow(1, TEST_CASES.CHECKBOX_COL_INDEX);
    clickGridRow(2, TEST_CASES.CHECKBOX_COL_INDEX);
    openDialog(cy.getByTestId("bulk-delete-btn"));
    cy.getByTestId("dialog-container").within(() => {
      cy.contains(
        "The selected items will be deleted immediately and are not recoverable:",
      );
      cy.getByTestId("bulkDeleteTestCaseList").within(() => {
        cy.contains("TestFile1");
        cy.contains("DeleteMe");
        cy.contains("TryToDeleteMe");
      });
      cy.contains('Type "DELETE" in the box below to proceed.');
    });
    deleteArtifact();
    testToast(
      "Some items could not be deleted",
      "DeleteMe: Item not locked by user",
    );
  });

  it("cannot delete a test file due to references", () => {
    skipOn("firefox"); // seems to be an issue with clicking the button in firefox only
    openDialog(
      cy.getGridRowButtonOrLink(
        2,
        TEST_CASES.ACTION_COL_INDEX,
        TEST_CASES.DELETE_BTN_INDEX,
      ),
    );
    deleteArtifact(
      "Unable to delete - the item is being referenced by 2 other items",
    );
    clickToastActionButton();
    testAssociatedRecordsSheet("TryToDeleteMe", true);
    testAssociatedRecordsGrid(["Rule Set", "Batch_Activity_RS"], true);
    testAssociatedRecordsGridRow(1, ["Function", "entryPointFn"]);
  });

  it("displays revision history", () => {
    testRevisionHistoryDialogFromGrid(
      0,
      "TestFile1",
      [
        { type: "checkbox", isChecked: false },
        "2a8ca79",
        getRelativeDate("2025-10-12 09:49:17 -0500"),
        { type: "email", value: "mdickson1@gmail.com" },
        "test",
        { type: "button", value: "Rollback to this revision" },
      ],
      true,
    );

    //test uncommitted version
    testRevisionCompareDialog(
      0,
      0,
      1,
      "TestFile1 (Test Case)",
      "",
      "",
      "",
      getRelativeDate("2025-10-12 09:49:17 -0500"),
    );

    // test committed revisions:
    testRevisionCompareDialog(
      0,
      1,
      2,
      "TestFile1 (Test Case)",
      "429e207",
      getRelativeDate("2024-11-13 09:48:12 -0500"),
      "2a8ca79",
      getRelativeDate("2025-10-12 09:49:17 -0500"),
      null,
      null,
      null,
      true,
    );

    verifyTestCaseComparison(
      {
        removedCount: 1,
        modifiedCount: 1,
        modifiedText: '"description": "",',
        removedText: '"oldField": "oldValue"',
      },
      {
        addedCount: 1,
        modifiedCount: 1,
        modifiedText: '"description": "new description",',
        addedText: '"newField": "newValue"',
      },
    );

    closeRevisionCompareDialog();
    testRollback(0, 1, true, true);
  });

  it("clones a test case", () => {
    testDialog(
      cy.getGridRowButtonOrLink(
        0,
        TEST_CASES.ACTION_COL_INDEX,
        TEST_CASES.CLONE_BTN_INDEX,
      ),
      "Clone Test Case",
    );
    openDialog(
      cy.getGridRowButtonOrLink(
        0,
        TEST_CASES.ACTION_COL_INDEX,
        TEST_CASES.CLONE_BTN_INDEX,
      ),
    );

    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled")
      .contains("Save & Commit");
    testFormField("filenameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false, {
      defaultValue: "cloned from TestFile1",
    });
    cy.getByTestId("rulegroupInput").should("not.exist");

    // save without entering a name:
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testFormFieldValidation("filenameField", "Enter required field");
    testIsDialogDisplayed();

    // save with invalid characters in name (slash should be invalid):
    typeFormField("filenameInput", "invalid/name");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testFormFieldValidation(
      "filenameField",
      "Field can only contain alphanumeric characters, underscores, spaces, plus (+), minus (-), and parentheses",
    );
    testIsDialogDisplayed();

    // verify allowed characters now work (space, plus, minus, parentheses, underscore)
    cy.getByTestId("filenameInput").clear();
    typeFormField("filenameInput", "Valid Name+(Test)-Case_1");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    // Reopen dialog for subsequent validation tests
    testDialog(
      cy.getGridRowButtonOrLink(
        0,
        TEST_CASES.ACTION_COL_INDEX,
        TEST_CASES.CLONE_BTN_INDEX,
      ),
      "Clone Test Case",
    );
    openDialog(
      cy.getGridRowButtonOrLink(
        0,
        TEST_CASES.ACTION_COL_INDEX,
        TEST_CASES.CLONE_BTN_INDEX,
      ),
    );
    cy.getByTestId("filenameInput").clear();

    // save with too long a name:
    const longName = "a".repeat(101);
    typeFormField("filenameInput", longName, 5);
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testFormFieldValidation(
      "filenameField",
      "Maximum length is 100 characters",
    );
    testIsDialogDisplayed();
    cy.getByTestId("filenameInput").clear();

    // try to save with too long a description:
    cy.getByTestId("fileDescriptionInput").clear();
    const longDescription = "a".repeat(1001);
    typeFormField("filenameInput", "uniqueName");
    typeFormField("fileDescriptionInput", longDescription, 5);
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testFormFieldValidation(
      "fileFormDescriptionField",
      "Maximum length is 1000 characters",
    );
    testIsDialogDisplayed();
    cy.getByTestId("fileDescriptionInput").clear();
    cy.getByTestId("filenameInput").clear();

    // try to save with a duplicate name:
    typeFormField("filenameInput", "duplicate");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testIsDialogDisplayed();
    testToast(
      ToastTitle.ERROR,
      "There was a problem saving the item. Name is not unique",
    );
    // this tests that clicking the toast action button closes the toast and the dialog remains open:
    testIsDialogDisplayed();
    clickAnywhere();
    testIsDialogDisplayed();

    // save with a valid name:
    clearFormField("filenameInput");
    typeFormField("filenameInput", "clonedTestCase");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_CLONE, true);
  });

  it("navigates to edit a test case", () => {
    cy.getGridRowButtonOrLink(0, TEST_CASES.NAME_COL_INDEX).click();
    cy.url().should(
      "include",
      "/rule-designer/rule-testing/test-cases/TestFile1",
    );
  });

  it("navigates to add a test case", () => {
    cy.getByTestId("addTestFileBtn").click();
    cy.url().should("include", "/rule-designer/rule-testing/test-cases/_new");
  });
});
