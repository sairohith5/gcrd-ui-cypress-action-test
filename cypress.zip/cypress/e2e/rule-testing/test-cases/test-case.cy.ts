import {
  testDescriptionEditForm,
  testFormField,
  testFormFieldNoValidation,
  testFormFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import {
  replaceTextInEditor,
  typeTextInEditor,
} from "../../../utils/monaco-utils";
import {
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";

describe("adding test case", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases/_new");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    cy.testHeaderAndFooter(
      "Create New Test Case",
      "Enter a name and click the Save button to design a new Test Case.",
    );
    cy.testBrowserTitle("New Test Case");
    cy.testNavbar("Testing");
    cy.testBreadcrumbs(["Home", "Test Cases"]);
    cy.testSidebar("Testing", "Test Cases");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays form fields and performs client side validation", () => {
    const nameValidationMessage =
      "Field can only contain alphanumeric characters, underscores, spaces, plus (+), minus (-), and parentheses";

    testFormField("fileFormNameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false);
    testFormField("fileCommitMessageField", "Commit Message", false);

    cy.getByTestId("btnFileFormSave")
      .should("exist")
      .should("be.disabled")
      .should("have.text", "Save & Commit");

    // test for required field
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("btnFileFormSave").should("exist").should("not.be.disabled");
    cy.getByTestId("btnFileFormSave").click();
    testFormFieldValidation("fileFormNameField", "Enter required field");

    // test invalid characters
    typeFormField("fileNameInput", "*");
    testFormFieldValidation("fileFormNameField", nameValidationMessage);

    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "~.");
    testFormFieldValidation("fileFormNameField", nameValidationMessage);

    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "[w");
    testFormFieldValidation("fileFormNameField", nameValidationMessage);

    // test for max length (100 chars)
    const _101Chars = new Array(102).join("a");
    typeFormField("fileNameInput", _101Chars);
    cy.getByTestId("btnFileFormSave").click();
    testFormFieldValidation(
      "fileFormNameField",
      "Maximum length is 100 characters",
    );

    // test for "+<space>a" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "+ a");
    testFormFieldNoValidation("fileFormNameField");

    // test for "_+" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "_+");
    testFormFieldNoValidation("fileFormNameField");

    // test for "-_" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "-_");
    testFormFieldNoValidation("fileFormNameField");

    // test for "()" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "()");
    testFormFieldNoValidation("fileFormNameField");

    // test for ")-" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", ")-");
    testFormFieldNoValidation("fileFormNameField");

    // test for "x(" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "x(");
    testFormFieldNoValidation("fileFormNameField");

    // test for "Vs" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "Vs");
    testFormFieldNoValidation("fileFormNameField");

    // test for "90" in name is valid
    cy.getByTestId("fileNameInput").clear();
    typeFormField("fileNameInput", "90");
    testFormFieldNoValidation("fileFormNameField");
  });

  it("navigates to new test case after saving", () => {
    typeFormField("fileNameInput", "Valid Name+(Test)-Case_1");
    cy.getByTestId("btnFileFormSave").click();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
    cy.url().should(
      "include",
      "/rule-designer/rule-testing/test-cases/Valid%20Name+(Test)-Case_1",
    );
    cy.testHeaderAndFooter("Valid Name+(Test)-Case_1");
  });
});

describe("editing test case", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases/TestFile1");
    cy.get("div[data-testid='inputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");
    cy.get("div[data-testid='outputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    cy.testHeaderAndFooter("TestFile1", "sample test case");
    cy.testBrowserTitle("[TestFile1] Test Case");
    cy.testNavbar("Testing");
    cy.testBreadcrumbs(["Home", "Test Cases"]);
    cy.testSidebar("Testing", "Test Cases");
    cy.getByTestId("tags-container").should("be.visible");
  });

  it("displays form buttons", () => {
    cy.getByTestId("saveBtn")
      .should("exist")
      .contains("Save")
      .should("be.disabled");
    cy.getByTestId("cancelBtn").should("exist").contains("Cancel");
    cy.getByTestId("maximizeToggleBtn").should("exist").contains("Fullscreen");
    cy.getByTestId("nav-menu-more")
      .should("exist")
      .contains("More Actions")
      .click();
    cy.getByTestId("executeTestBtn").should("exist").contains("Execute Test");
    cy.getByTestId("deleteArtifactBtn").should("exist").contains("Delete");
  });

  it("maximizes and restores content", () => {
    cy.testMaximizeToggleButton();

    cy.getByTestId("maximizeToggleBtn").click();
    cy.getByTestId("saveBtn").should("exist");
    cy.getByTestId("maximizeToggleBtn").click();
    cy.getByTestId("cancelBtn").should("exist");
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("executeTestBtn").should("exist");
    cy.getByTestId("deleteArtifactBtn").should("exist");
  });

  it("cancels edits and navigates back to test cases screen", () => {
    cy.getByTestId("cancelBtn")
      .should("exist")
      .should("not.be.disabled")
      .contains("Cancel");
    cy.getByTestId("cancelBtn").click();
    cy.url().should("include", "/rule-designer/rule-testing/test-cases");
  });

  it("edits description", () => {
    testDescriptionEditForm();
  });

  it("displays input and output editors", () => {
    cy.getByTestId("inputEditor").should("exist").as("inputEditor");
    cy.get("@inputEditor").find("h3").contains("Input");
    cy.get("@inputEditor").find("section").contains('"requestID": "0"');
    cy.getByTestId("outputEditor").should("exist").as("outputEditor");
    cy.get("@outputEditor").find("h3").contains("Expected Output");
    cy.get("@outputEditor")
      .find("section")
      .contains('"cbhEligibilityList": [],');
  });

  it("edits test case content", () => {
    replaceTextInEditor(
      '{ "test": "edited" }',
      "div[data-testid='inputEditor']",
    );

    replaceTextInEditor(
      '{ "test": "edited" }',
      "div[data-testid='outputEditor']",
    );

    cy.getByTestId("saveBtn").click();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
    cy.url().should(
      "include",
      "/rule-designer/rule-testing/test-cases/TestFile1",
    );
  });

  it("should not allow saving with invalid JSON syntax", () => {
    // test input editor
    replaceTextInEditor("invalid json", "div[data-testid='inputEditor']");
    cy.getByTestId("saveBtn").click();
    testToast(
      ToastTitle.ERROR,
      "Input JSON is invalid. Please correct it before saving.",
    );
    replaceTextInEditor(
      '{ "test": "edited" }',
      "div[data-testid='inputEditor']",
    );

    // test output editor
    replaceTextInEditor("invalid json", "div[data-testid='outputEditor']");
    cy.getByTestId("saveBtn").click();
    testToast(
      ToastTitle.ERROR,
      "Output JSON is invalid. Please correct it before saving.",
    );
  });
});

describe("readonly test case", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/test-cases/TestFile3");
    cy.get("div[data-testid='inputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");
    cy.get("div[data-testid='outputEditor'] .monaco-editor")
      .should("exist")
      .should("be.visible");
  });

  it("should display as readonly when not checked out", () => {
    cy.getByTestId("saveBtn").should("exist").should("be.disabled");
    cy.getByTestId("cancelBtn").should("exist");
    cy.getByTestId("maximizeToggleBtn").should("exist");
    cy.getByTestId("inputEditor").find(".readonly").should("exist");
    cy.getByTestId("outputEditor").find(".readonly").should("exist");

    cy.getByTestId("nav-menu-more").should("exist").click();
    cy.getByTestId("deleteArtifactBtn").should("not.exist");
    cy.getByTestId("executeTestBtn").should("exist");
    cy.getByTestId("openGraphTestBtn").should("exist");
  });
});
