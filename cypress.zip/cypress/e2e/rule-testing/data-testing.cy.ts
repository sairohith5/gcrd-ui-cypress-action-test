import { skipOn } from "@cypress/skip-test";
import {
  clickToastActionButton,
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../utils/toast-utils";
import {
  deleteAllText,
  replaceTextInEditor,
  typeTextInEditor,
  verifyEditorStyleIsReadWrite,
  verifyEditorStyleIsReadOnly,
} from "../../utils/monaco-utils";
import {
  openDialog,
  submitDialog,
  testDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../utils/dialog-utils";
import {
  clearFormField,
  pasteIntoFormField,
  testFormField,
  testFormFieldValidation,
  typeFormField,
} from "../../utils/form-utils";

const populateInputEditor = (input: string) => {
  typeTextInEditor(input, '[data-testid="inputEditor"]');
};

describe("Data Testing", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/data");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter(
      "Data Testing",
      "Paste JSON text or drop a JSON file into the Input section",
    );
    cy.testBrowserTitle("Data Testing");
    cy.testNavbar("Testing");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Testing", "Data Testing");
  });

  it("should display input and output editors", () => {
    verifyEditorStyleIsReadWrite('[data-testid="inputEditor"]');
    verifyEditorStyleIsReadOnly('[data-testid="outputEditor"]');
  });

  it("should display error test when no input is provided", () => {
    cy.getByTestId("testBtn").contains("Execute Test").click();
    testToast(ToastTitle.ERROR, ToastMessage.ENTER_INPUT);
  });

  it("should do data testing when input is provided", () => {
    cy.getByTestId("inputEditor")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("{}");
    cy.getByTestId("testBtn").click();
    cy.getByTestId("outputEditor")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .should("contain.text", "cbhEligibilityList");
  });
});

describe("Save as Test Case", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/rule-testing/data");
    cy.wait(2000);
  });

  it("should enable Save as Test Case button when input and output are present", () => {
    cy.getByTestId("saveAsTestCaseBtn")
      .contains("Save as Test Case")
      .should("be.disabled");

    populateInputEditor('{"foo":1}');
    cy.getByTestId("saveAsTestCaseBtn").should("be.disabled"); // still no output

    cy.getByTestId("testBtn").click();
    cy.getByTestId("outputEditor")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .should("exist");

    cy.getByTestId("saveAsTestCaseBtn").should("not.be.disabled");

    deleteAllText('[data-testid="inputEditor"]');
    cy.getByTestId("saveAsTestCaseBtn")
      .contains("Save as Test Case")
      .should("be.disabled");
  });

  it("should display the Save as Test Case dialog and perform validation", () => {
    populateInputEditor('{"foo":1}');
    cy.getByTestId("testBtn").click();
    cy.getByTestId("saveAsTestCaseBtn").should("not.be.disabled");

    testDialog(
      cy.getByTestId("saveAsTestCaseBtn"),
      "Save as Test Case",
      "Save & Commit",
      "Cancel",
    );
    openDialog(cy.getByTestId("saveAsTestCaseBtn"));
    cy.getByTestId("dialog-submit-button").should("be.disabled");
    cy.getByTestId("dialog-cancel-button").should("not.be.disabled");
    testFormField("filenameField", "Name", true, { defaultValue: "" });
    testFormField("fileFormDescriptionField", "Description", false, {
      defaultValue: "",
    });
    testFormField("fileCommitMessageField", "Commit Message", false, {
      defaultValue: "Initial commit.",
    });

    // test save button becomes enabled
    typeFormField("fileDescriptionInput", "Test case description");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled");

    // validate Name field
    submitDialog();
    testIsDialogDisplayed();
    testFormFieldValidation("filenameField", "Enter required field");
    clearFormField("filenameInput");
    typeFormField("filenameInput", "invalid name with special char *");
    submitDialog();
    testIsDialogDisplayed();
    testFormFieldValidation(
      "filenameField",
      "Field can only contain alphanumeric characters, underscores, spaces, plus (+), minus (-), and parentheses",
    );
    clearFormField("filenameInput");
    const name101 = Array.from({ length: 101 }, () => "x").join("");
    typeFormField("filenameInput", name101, 0);
    submitDialog();
    testIsDialogDisplayed();
    testFormFieldValidation(
      "filenameField",
      "Maximum length is 100 characters",
    );

    // validate description field  (validates the input field only accepts max 1000 chars)
    clearFormField("fileDescriptionInput");
    const commitMsg1001 = Array.from({ length: 1001 }, () => "x").join("");
    typeFormField("fileDescriptionInput", commitMsg1001, 0);
    const commitMsg1000 = Array.from({ length: 1000 }, () => "x").join("");
    cy.getByTestId("fileDescriptionInput").should("have.value", commitMsg1000);

    // validate commit message field (validates the input field only accepts max 255 chars)
    clearFormField("fileCommitMessageInput");
    const commitMsg256 = Array.from({ length: 256 }, () => "x").join("");
    typeFormField("fileCommitMessageInput", commitMsg256, 0);
    const commitMsg255 = Array.from({ length: 255 }, () => "x").join("");
    cy.getByTestId("fileCommitMessageInput").should("have.value", commitMsg255);
  });

  it("should save a new test case successfully", () => {
    populateInputEditor('{"foo":1}');
    cy.getByTestId("testBtn").click();
    cy.getByTestId("saveAsTestCaseBtn").should("not.be.disabled").click();
    typeFormField("filenameInput", "new");
    submitDialog();
    cy.wait(1000);

    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE, true);

    clickToastActionButton("Go to new test case");
    cy.url().should("include", "/rule-designer/rule-testing/test-cases/new");
  });
});
