import {
  getDecisionTableHeader,
  testDecisionTable,
  testDecisionTableRow,
  clickTableCellButton,
  getTableCell,
  getTableCellButton,
  filterDecisionTable,
  clearDecisionTableFilter,
  testDecisionTableCellFormField,
  testArrayCellMenuOptions,
  clickArrayCellButton,
  NULL_DISPLAY,
} from "../../utils/decision-table-utils";
import { ToastMessage, ToastTitle, testToast } from "../../utils/toast-utils";
import "cypress-file-upload";
import {
  clearFormField,
  selectFormField,
  testFormField,
  testFormFieldValidation,
  testFormFieldValue,
  typeFormField,
} from "../../utils/form-utils";
import {
  openDialog,
  testDialog,
  testDialogIsNotDisplayed,
} from "../../utils/dialog-utils";

describe("rule management table", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/configuration/rule-management");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    cy.testHeaderAndFooter("Rule Management");
    cy.testBrowserTitle("Rule Management");
    cy.testNavbar("Configuration");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Configuration", "Rule Management");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("should display the rule management table", () => {
    testDecisionTable(
      [
        "Rule Set",
        "Rule Name",
        "Tags",
        "Description",
        "Effective From",
        "Effective To",
        "Rule Type",
        "Module",
        "Event Source",
        "Event Type",
        "QA",
        "UAT",
        "PREPROD",
        "PROD",
      ],
      [
        "Batch_Activity_RS",
        "Apex_582",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
        "Test Description",
        "12/29/2024",
        "04/11/2025",
        "UM_REALTIME",
        "UM",
        ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
        "ALL",
        { type: "checkbox", isChecked: true },
        { type: "checkbox", isChecked: true },
        { type: "checkbox", isChecked: false },
        { type: "checkbox", isChecked: false },
      ],
      true,
    );
    testDecisionTableRow(1, [
      "Batch_Activity_RS",
      "GCCST_113475",
      { type: "tags", tags: [] },
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    testDecisionTableRow(2, [
      "Batch_Activity_RS",
      "GCCST_117226",
      { type: "tags", tags: [] },
      "Test Description",
      "",
      "",
      "BATCH_DAILY",
      "BATCH",
      ["CMPROGRAMEDIT"],
      "POST",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // test condition vs actions cols
    for (let i = 0; i < 3; i++) {
      getDecisionTableHeader(i)
        .find("span.sr-only")
        .should("have.text", "condition column type");
    }
    for (let i = 3; i < 14; i++) {
      getDecisionTableHeader(i)
        .find("span.sr-only")
        .should("have.text", "action column type");
    }

    // test columns are readonly
    for (let i = 0; i < 14; i++) {
      getDecisionTableHeader(i)
        .find("button[data-testid='cell-menu'][aria-label='cell options']")
        .should("exist")
        .should("not.be.visible");
    }

    // test row context menu not visible
    cy.getByTestId("row-context-menu").should("not.exist");

    // test readonly vs modifiable cells
    getTableCellButton(0, 0, "Edit").should("not.exist");
    getTableCellButton(0, 1, "Edit").should("not.exist");
    getTableCellButton(0, 2, "Edit").should("not.exist");
    getTableCellButton(0, 3, "Edit").should("exist");
    getTableCellButton(0, 4, "Edit").should("exist");
    getTableCellButton(0, 5, "Edit").should("exist");
    getTableCellButton(0, 6, "Edit").should("exist");
    getTableCellButton(0, 7, "Edit").should("exist");
    getTableCellButton(0, 9, "Edit").should("exist");
  });

  it("should edit and save a rule entry", () => {
    cy.getByTestId("saveBtn").should("exist").should("not.be.enabled");

    // edit a date field
    getTableCell(0, 4).should("have.text", "12/29/2024");
    clickTableCellButton(0, 4);
    cy.get("[data-testid='dateCellBox'] input").as("dateCell");
    cy.get("@dateCell").type("01022023"); // force to override the existing value
    clickTableCellButton(0, 4, "Apply");
    // TODO: when clicking Save, the newly-typed value is not saved (this is a Cypress problem, not an application bug):
    getTableCell(0, 4).should("have.text", "01/02/2023");
    getTableCellButton(0, 4, "Apply").should("not.exist");
    getTableCellButton(0, 4, "Cancel").should("not.exist");

    // edit a dropdown field
    clickTableCellButton(0, 6, "Edit");
    getTableCellButton(0, 6, "Apply").should("exist").should("be.visible");
    getTableCellButton(0, 6, "Cancel").should("exist").should("be.visible");
    testDecisionTableCellFormField("tableCellDropdown", "Rule Type", {
      defaultValue: "UM_REALTIME",
      expectedSelectOptions: [
        "Select one",
        "AG_REALTIME",
        "BATCH_DAILY",
        "BATCH_MONTHLY",
        "CM_REALTIME",
        "EXTERNAL_API_REALTIME",
        "PH_REALTIME",
        "PP_REALTIME",
        "UM_REALTIME",
      ],
    });
    selectFormField("tableCellDropdown", "CM_REALTIME");
    clickTableCellButton(0, 6, "Apply");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "01/02/2023",
      "04/11/2025",
      "CM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // edit an array of dropdowns
    testArrayCellMenuOptions(0, 8, 0, ["Edit", "Insert below", "Delete"]);
    testArrayCellMenuOptions(12, 8, 0, ["Insert"]);

    clickArrayCellButton(12, 8, "Menu", 0);
    cy.getByTestId("add-column-menu-item").click();
    getTableCellButton(12, 8, "Apply")
      .should("exist")
      .should("be.visible")
      .should("be.disabled");
    getTableCellButton(12, 8, "Cancel").should("exist").should("be.visible");
    selectFormField("tableCellDropdown", "ADDNEWDECISION");
    getTableCellButton(12, 8, "Apply").should("be.enabled");
    clickArrayCellButton(12, 8, "Apply", 0);
    testDecisionTableRow(12, [
      "RealTime_AG_RS",
      "Long_rule_name_to_test_the_display_of_the_text_within_the_UI_to_see_if_it_gets_displayed_properly",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // edit a checkbox field
    clickTableCellButton(0, 10);

    cy.getByTestId("saveBtn").should("exist").should("be.enabled").click();

    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);

    // test for save button disabled after saving
    cy.getByTestId("saveBtn").should("be.disabled");
  });

  it("should cancel editing an enum dropdown cell", () => {
    clickTableCellButton(11, 7, "Edit");
    getTableCellButton(11, 7, "Cancel").should("exist").click();
    clickTableCellButton(11, 7, "Edit");
    getTableCellButton(11, 7, "Apply").should("exist").should("be.disabled");
  });

  it("should cancel editing an array enum dropdown cell", () => {
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    clickArrayCellButton(0, 8, "Menu", 0);
    cy.getByTestId("add-column-menu-item").click();
    getTableCellButton(0, 8, "Cancel").should("exist").click();

    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    getTableCell(0, 8).should("not.contain", "€");
  });

  it("should display confirmation dialog and confirm when navigating away with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true; // Simulate clicking 'OK'
    });

    clickTableCellButton(0, 10);
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should("include", "/dashboard");
  });

  it("should display confirmation dialog and cancel when navigating away with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return false; // Simulate clicking 'Cancel'
    });

    clickTableCellButton(0, 10);
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should("include", "/rule-designer/configuration/rule-management");
  });

  it("should not display confirmation dialog when navigating away with saved changes", () => {
    cy.getByTestId("Dashboard-link").click();
    cy.wait(1000);
    cy.url().should("include", "/dashboard");
  });

  it("should filter the rule management table", () => {
    testFormField("decisionTableFilterField", "Filter Current Data", false, {
      defaultValue: "",
    });
    filterDecisionTable("apex");

    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(1, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // test filter clear button
    clearDecisionTableFilter();
    testFormFieldValue("decisionTableFilterField", "");

    testDecisionTableRow(1, [
      "Batch_Activity_RS",
      "GCCST_113475",
      "",
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // test empty results
    filterDecisionTable("no match");
    cy.getByTestId("noDataMessage").should("exist");

    // test enum type
    clearDecisionTableFilter();
    filterDecisionTable("CMPROGRAMEDIT");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_117226",
      "",
      "Test Description",
      "",
      "",
      "BATCH_DAILY",
      "BATCH",
      ["CMPROGRAMEDIT"],
      "POST",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should update a cell when the rule management table is filtered", () => {
    testDecisionTableRow(6, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    filterDecisionTable("apex");
    clickTableCellButton(1, 10);

    // clear the filter to ensure the cell still displays the updated text
    clearDecisionTableFilter();

    testDecisionTableRow(6, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should display an updated cell after the rule management table is filtered", () => {
    testDecisionTableRow(6, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    clickTableCellButton(6, 10);
    filterDecisionTable("apex");

    testDecisionTableRow(1, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should sort the rule management table", () => {
    // before sort
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* test sorting string column */
    cy.getByTestId("columnHeader2").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort descending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "descending");
    testDecisionTableRow(0, [
      "RealTime_AG_RS",
      "mikesRule1",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort none
    cy.get("@sortBtn").click();
    cy.get("@columnHeader").invoke("attr", "aria-sort").should("eq", "none");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* test sorting string column with null value */
    cy.getByTestId("columnHeader4").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_311_MH_Medicare_Advantage",
      { type: "tags", tags: ["GCRE-456"] },
      NULL_DISPLAY,
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort descending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "descending");
    testDecisionTableRow(0, [
      "mikeRS",
      "mike_new_rule",
      { type: "tags", tags: ["GCRE-123"] },
      "Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description ",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort none
    cy.get("@sortBtn").click();
    cy.get("@columnHeader").invoke("attr", "aria-sort").should("eq", "none");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* test sorting date column */
    cy.getByTestId("columnHeader5").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_117226",
      "",
      "Test Description",
      "",
      "",
      "BATCH_DAILY",
      "BATCH",
      ["CMPROGRAMEDIT"],
      "POST",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort descending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "descending");
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_311_MH_Commercial",
      "",
      "Test Description",
      "04/11/2025",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort none
    cy.get("@sortBtn").click();
    cy.get("@columnHeader").invoke("attr", "aria-sort").should("eq", "none");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* test sorting checkbox column */
    cy.getByTestId("columnHeader11").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_117226",
      "",
      "Test Description",
      "",
      "",
      "BATCH_DAILY",
      "BATCH",
      ["CMPROGRAMEDIT"],
      "POST",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort descending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "descending");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_113475",
      "",
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort none
    cy.get("@sortBtn").click();
    cy.get("@columnHeader").invoke("attr", "aria-sort").should("eq", "none");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // test sorting the event source column (array of arrays)
    cy.getByTestId("columnHeader9").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "RealTime_AG_RS",
      "Long_rule_name_to_test_the_display_of_the_text_within_the_UI_to_see_if_it_gets_displayed_properly",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      [""],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort descending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "descending");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort none
    cy.get("@sortBtn").click();
    cy.get("@columnHeader").invoke("attr", "aria-sort").should("eq", "none");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // test sorting tags
    cy.getByTestId("columnHeader3").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_113475",
      "",
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort descending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "descending");
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_311_MH_Medicare_Advantage",
      { type: "tags", tags: ["GCRE-456"] },
      NULL_DISPLAY,
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should edit an array cell after sorting the rule management table", () => {
    // before sort
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // test sorting the event source column (array of arrays)
    cy.getByTestId("columnHeader9").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "RealTime_AG_RS",
      "Long_rule_name_to_test_the_display_of_the_text_within_the_UI_to_see_if_it_gets_displayed_properly",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      [""],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // insert a new array item
    clickArrayCellButton(0, 8, "Menu", 0);
    cy.getByTestId("add-column-menu-item").click();
    getTableCellButton(0, 8, "Apply")
      .should("exist")
      .should("be.visible")
      .should("be.disabled");
    getTableCellButton(0, 8, "Cancel").should("exist").should("be.visible");
    selectFormField("tableCellDropdown", "ADDNEWDECISION");
    getTableCellButton(0, 8, "Apply").should("be.enabled");
    clickArrayCellButton(0, 8, "Apply", 0);
    testDecisionTableRow(0, [
      "RealTime_AG_RS",
      "Long_rule_name_to_test_the_display_of_the_text_within_the_UI_to_see_if_it_gets_displayed_properly",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // delete an array item
    clickArrayCellButton(1, 8, "Menu", 0);
    cy.getByTestId("user-tasks-menu-item").click();
    testDecisionTableRow(1, [
      "Batch_Activity_RS",
      "GCCST_117226",
      "",
      "Test Description",
      "",
      "",
      "BATCH_DAILY",
      "BATCH",
      [""],
      "POST",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should sort the event source column after setting a null array value", () => {
    // before sort
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // sort the event source column
    cy.getByTestId("columnHeader9").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();

    // pretend to insert a new array item
    clickArrayCellButton(0, 8, "Menu", 0);
    cy.getByTestId("add-column-menu-item").click();

    // now cancel inserting the item:
    getTableCellButton(0, 8, "Cancel").should("exist").click();

    // now sort the event source column again
    cy.get("@sortBtn").scrollIntoView();
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "descending");

    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should sort multiple columns without retaining the previous sort", () => {
    // before sort
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* test the rule name column ASC */
    cy.getByTestId("columnHeader2").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* sort the QA column ASC */
    cy.getByTestId("columnHeader11").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_117226",
      "",
      "Test Description",
      "",
      "",
      "BATCH_DAILY",
      "BATCH",
      ["CMPROGRAMEDIT"],
      "POST",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should sort and then filter the rule management table", () => {
    // before sort
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* sort by rule name column ASC */
    cy.getByTestId("columnHeader2").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* filter by "mike" */
    filterDecisionTable("mike");

    testDecisionTableRow(0, [
      "mikeRS",
      "mike_new_rule",
      { type: "tags", tags: ["GCRE-123"] },
      "Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description Test description ",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // sort ascending
    cy.get("@sortBtn").click();
    testDecisionTableRow(0, [
      "RealTime_AG_RS",
      "mikesRule1",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should retain the sort after filtering the rule management table", () => {
    // before sort
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    /* test sorting string column */
    cy.getByTestId("columnHeader2").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    // sort ascending
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");
    // after sort
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // filter the table
    filterDecisionTable("apex");

    // check that the sort is retained
    testDecisionTableRow(0, [
      "Batch_UM_RealTime_RS",
      "APEX_113",
      "",
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should retain the filter after sorting the rule management table", () => {
    cy.getByTestId("columnHeader2").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");

    // before filter
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // filter the table
    filterDecisionTable("GCCST");
    // test the first row
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_113475",
      "",
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // test the last row
    testDecisionTableRow(4, [
      "Batch_Activity_RS",
      "GCCST_90900",
      { type: "tags", tags: ["GCRE-123", "BusinessLibrary", "GCRE-456"] },
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // sort the rule name column descending
    cy.get("@sortBtn").click();
    cy.wait(500);
    cy.get("@sortBtn").click();

    // test the first row
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_90900",
      { type: "tags", tags: ["GCRE-123", "BusinessLibrary", "GCRE-456"] },
      "Test Description",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
    // test the last row
    testDecisionTableRow(4, [
      "Batch_Activity_RS",
      "GCCST_113475",
      "",
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should navigate to a rule set", () => {
    cy.wait(1000);
    getTableCell(0, 0).find("a").click();
    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS",
    );
  });

  it("should navigate to a rule", () => {
    cy.wait(1000);
    getTableCell(0, 1).find("a").click();
    cy.url().should(
      "include",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS/rule/Apex_582",
    );
  });

  it("should export the rule management table", () => {
    cy.wait(1000);
    cy.getByTestId("exportFileBtn").click();
    cy.wait(1000);
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_EXPORT);
    cy.readFile("cypress/downloads/MANAGEMENT_TABLE.xlsx").should("exist");
    cy.getByTestId("toast").should("not.exist");
  });

  it("should display all results when filter is reset while keeping the sorting applied on any column", () => {
    cy.getByTestId("decisionTable")
      .find("tbody tr")
      .its("length")
      .as("filteredRowCount");

    cy.get("@filteredRowCount").should("equal", 15);
    filterDecisionTable("batch");

    cy.getByTestId("decisionTable")
      .find("tbody tr")
      .its("length")
      .as("filteredRowCount");

    cy.get("@filteredRowCount").should("be.greaterThan", 0).and("equal", 9);

    cy.getByTestId("columnHeader3").as("columnHeader");
    cy.get("@columnHeader")
      .find("button[data-testid='sortColumnBtn']")
      .as("sortBtn");
    cy.get("@sortBtn").click();
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");

    // Verify first row after sorting with filter applied
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_113475",
      "",
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    clearDecisionTableFilter();
    testFormFieldValue("decisionTableFilterField", "");

    // Check that column still shows ascending sort indicator
    cy.get("@columnHeader")
      .invoke("attr", "aria-sort")
      .should("eq", "ascending");

    // Verify first row is still sorted correctly (should be APEX_113 as it's alphabetically first)
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "GCCST_113475",
      "",
      "Lorem Ipsum is simply dummy text",
      "12/29/2024",
      "04/11/2025",
      "PP_REALTIME",
      "PP",
      ["INTAKEDETAILS"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // Verify that sorting is applied to ALL rows, not just previously filtered ones
    // Check another row to ensure proper sorting across all data
    testDecisionTableRow(14, [
      "Batch_UM_RealTime_RS",
      "APEX_311_MH_Medicare_Advantage",
      "GCRE-456",
      "",
      "",
      "",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT"],
      "ALL",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("should add an environment type column", () => {
    cy.getByTestId("addEnvironmentTypeBtn")
      .should("exist")
      .contains("Add Environment Type")
      .click();
    testDialog(
      cy.getByTestId("addEnvironmentTypeBtn"),
      "Add Environment Type Column",
      "Apply",
      "Cancel",
    );

    openDialog(cy.getByTestId("addEnvironmentTypeBtn"));

    testFormField("envNameField", "Name", true, {
      defaultValue: "",
    });
    testFormField("cloneFromField", "Clone Values from Environment", false, {
      numSelectOptionsToTest: 5,
      expectedSelectOptions: ["Select one", "PREPROD", "PROD", "QA", "UAT"],
      defaultValue: "",
    });

    cy.getByTestId("dialog-submit-button").should("be.disabled");
    selectFormField("cloneFromSelect", "QA");

    // test validation
    cy.getByTestId("dialog-submit-button").should("be.enabled").click();
    testFormFieldValidation("envNameField", "Enter required field");
    typeFormField("envNameInput", "morethan10chars");
    testFormFieldValidation("envNameField", "Maximum length is 10 characters");
    clearFormField("envNameInput");
    typeFormField("envNameInput", "1invalid");
    testFormFieldValidation(
      "envNameField",
      "Field can only contain alphanumeric characters and underscores, and cannot start with a numeric value.",
    );
    clearFormField("envNameInput");
    typeFormField("envNameInput", "inv name");
    testFormFieldValidation(
      "envNameField",
      "Field can only contain alphanumeric characters and underscores, and cannot start with a numeric value.",
    );
    clearFormField("envNameInput");
    typeFormField("envNameInput", "inv-name!");
    testFormFieldValidation(
      "envNameField",
      "Field can only contain alphanumeric characters and underscores, and cannot start with a numeric value.",
    );
    clearFormField("envNameInput");
    typeFormField("envNameInput", "QA");
    testFormFieldValidation("envNameField", "Duplicate column name");
    clearFormField("envNameInput");
    typeFormField("envNameInput", "qa");
    testFormFieldValidation("envNameField", "Duplicate column name");

    // test new column is added with defaults
    clearFormField("envNameInput");
    typeFormField("envNameInput", "NEW");
    cy.getByTestId("dialog-submit-button").should("be.enabled").click();
    testDialogIsNotDisplayed();

    testDecisionTable(
      [
        "Rule Set",
        "Rule Name",
        "Tags",
        "Description",
        "Effective From",
        "Effective To",
        "Rule Type",
        "Module",
        "Event Source",
        "Event Type",
        "QA",
        "UAT",
        "PREPROD",
        "PROD",
        "NEW",
      ],
      [
        "Batch_Activity_RS",
        "Apex_582",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
        "Test Description",
        "12/29/2024",
        "04/11/2025",
        "UM_REALTIME",
        "UM",
        ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
        "ALL",
        { type: "checkbox", isChecked: true },
        { type: "checkbox", isChecked: true },
        { type: "checkbox", isChecked: false },
        { type: "checkbox", isChecked: false },
        { type: "checkbox", isChecked: true },
      ],
      true,
    );
    testDecisionTableRow(2, [
      "Batch_Activity_RS",
      "GCCST_117226",
      { type: "tags", tags: [] },
      "Test Description",
      "",
      "",
      "BATCH_DAILY",
      "BATCH",
      ["CMPROGRAMEDIT"],
      "POST",
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
    ]);

    // test new column is added without defaults
    openDialog(cy.getByTestId("addEnvironmentTypeBtn"));
    typeFormField("envNameInput", "NEW2");
    cy.getByTestId("dialog-submit-button").should("be.enabled").click();
    testDecisionTableRow(0, [
      "Batch_Activity_RS",
      "Apex_582",
      { type: "tags", tags: ["BusinessLibrary", "GCRE-123"] },
      "Test Description",
      "12/29/2024",
      "04/11/2025",
      "UM_REALTIME",
      "UM",
      ["PPSUBMITAUTHENTRYNEXT", "ADDNEWDECISION"],
      "ALL",
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: false },
      { type: "checkbox", isChecked: true },
      { type: "checkbox", isChecked: false },
    ]);
    cy.getByTestId("saveBtn").should("be.enabled");

    // test save button does not get disabled after filtering
    filterDecisionTable("21");
    cy.getByTestId("saveBtn").should("be.enabled");
  });
});
