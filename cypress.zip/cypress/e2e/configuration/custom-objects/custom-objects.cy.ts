import {
  openDialog,
  testDialog,
  testDialogIsNotDisplayed,
} from "../../../utils/dialog-utils";
import {
  testFormField,
  testNameFieldValidationWhenCloning,
} from "../../../utils/form-utils";
import {
  testRevisionHistoryDialogFromGrid,
  testRevisionCompareDialog,
  testRollback,
} from "../../../utils/revision-history-utils";
import { getRelativeDate } from "../../../utils/date-utils";
import { deleteArtifact, verifyInfoTooltip } from "../../../utils/utils";
import { skipOn } from "@cypress/skip-test";
import { testTable } from "../../../utils/grid-utils";

describe("custom objects", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/configuration/custom-objects");
    cy.wait(1000);
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testBrowserTitle("Custom Objects");
    cy.testHeaderAndFooter("Custom Objects");
    cy.testNavbar("Configuration");
    cy.testBreadcrumbs(["Home"]);

    cy.testSidebar("Configuration", "Custom Objects");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays a grid", () => {
    testTable(
      [
        { type: "button", ariaLabel: "Lock Status" },
        "Name",
        "Tags",
        "Last Committed",
        "Actions",
      ],
      [
        { type: "button", value: "checked out by me" },
        "ActiveRuleMetadata",
        { type: "tags", tags: ["TechnicalLibrary", "GCRE-123"] },
        getRelativeDate("2022-05-03 11:28:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for ActiveRuleMetadata",
          },
          { type: "button", value: "clone ActiveRuleMetadata" },
          {
            type: "button",
            value: "delete custom object ActiveRuleMetadata",
          },
        ],
      ],
    );
  });

  it("navigates to add a custom object", () => {
    cy.getByTestId("addCustomObjectPropBtn").click();
    cy.url().should(
      "include",
      "/rule-designer/configuration/custom-objects/_new",
    );
    //test header and footer
    cy.testBreadcrumbs(["Home", "Custom Objects"]);
    cy.testBrowserTitle("Create New Custom Object");
  });

  it("deletes a custom object", () => {
    // Test the delete dialog appears
    testDialog(cy.getByTestId("grid-delete-button-4"), "Delete Confirmation");

    // Open delete dialog and perform deletion
    openDialog(cy.getByTestId("grid-delete-button-4"));
    deleteArtifact();
  });

  it("verify the delete functionality Custom object if the Custom object is being referenced anywhere", () => {
    openDialog(cy.getByTestId("grid-delete-button-3"));

    deleteArtifact(
      "Unable to delete - the custom object is being referenced by 3 other items.",
    );
  });

  it("navigates to edit a custom object", () => {
    cy.getGridRowButtonOrLink(1, 1).click();
    cy.url().should(
      "include",
      "/rule-designer/configuration/custom-objects/test_123",
    );
    cy.testBreadcrumbs(["Home", "Custom Objects"]);
    cy.testHeaderAndFooter("test_123");
    cy.getByTestId("addCustomObjectPropBtn")
      .should("exist")
      .should("be.enabled");
  });

  it("displays revision history", () => {
    testRevisionHistoryDialogFromGrid(
      1,
      "test_123",
      [
        { type: "checkbox", isChecked: false },
        "2a8ca79",
        getRelativeDate("2024-11-13 09:49:17 -0500"),
        { type: "email", value: "mdickson1@gmail.com" },
        "test",
        { type: "button", value: "Rollback to this revision" },
      ],
      true,
    );

    testRevisionCompareDialog(
      1,
      1,
      2,
      "test_123 (Custom Object)",
      "429e207",
      getRelativeDate("2024-11-13 09:48:12 -0500"),
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
      undefined,
      {
        // version1Fields corresponds to LEFT panel (revision 429e207) - has 2 fields
        version1Fields: [
          {
            name: "t1",
            type: "String",
            isArray: false,
            required: false,
            nullable: true,
            auto: false,
          },
          {
            name: "t2",
            type: "ScriptInfo",
            isArray: false,
            required: false,
            nullable: true,
            auto: false,
          },
        ],
        // version2Fields corresponds to RIGHT panel (revision 2a8ca79) - has 4 fields
        version2Fields: [
          {
            name: "t1",
            type: "String",
            isArray: false,
            required: false,
            nullable: true,
            auto: false,
          },
          {
            name: "t2",
            type: "ScriptInfo",
            isArray: false,
            required: false,
            nullable: true,
            auto: false,
          },
          {
            name: "t3",
            type: "boolean",
            isArray: false,
            required: false,
            nullable: true,
            auto: true,
          },
          {
            name: "t4",
            type: "Warning",
            isArray: true,
            required: false,
            nullable: true,
            auto: true,
          },
        ],
      },
    );

    testRollback(1, 1);
  });

  it("clones a custom object", () => {
    testDialog(cy.getByTestId("grid-clone-button-1"), "Clone Custom Object");

    openDialog(cy.getByTestId("grid-clone-button-1"));
    cy.getByTestId("dialog-title").should("contain", "Clone Custom Object");
    cy.getByTestId("dialog-description").should("contain", "Cloning test_123");

    testFormField("filenameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false, {
      defaultValue: "cloned from test_123",
    });

    cy.getByTestId("dialog-cancel-button")
      .should("exist")
      .should("not.be.disabled")
      .contains("Cancel");
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled")
      .contains("Save & Commit");
    testNameFieldValidationWhenCloning();
  });
});
