import {
  openDialog,
  testDialog,
  testDialogIsNotDisplayed,
} from "../../../utils/dialog-utils";
import { testTable } from "../../../utils/grid-utils";
import { verifyInfoTooltip } from "../../../utils/utils";
import {
  testFormField,
  testFormFieldValidation,
  testNameFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";

describe("custom object", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/configuration/custom-objects");
  });

  it("navigates to nested object type and displays grid", () => {
    cy.getGridRowButtonOrLink(1, 1).click();
    cy.wait(1000);
    cy.url().should(
      "include",
      "/rule-designer/configuration/custom-objects/test_123",
    );
    cy.testBreadcrumbs(["Home", "Custom Objects"]);
    cy.testHeaderAndFooter("test_123");
    cy.testBrowserTitle("[test_123] BOM Type");
    testTable(
      [
        "Name",
        "Type",
        "Is Array?",
        "Is Required?",
        "Nullable",
        "Auto Instantiate?",
        "Actions",
      ],
      [
        "t1",
        "String",
        "",
        "",
        { type: "icon", value: "check", screenReaderText: "item is nullable" },
        "",
        { type: "button", value: "delete custom object field t1" },
      ],
    );

    //test nav to double-nested type
    cy.getGridRowButtonOrLink(1, 1).click();
    cy.url().should("include", "/rule-designer/configuration/bot/ScriptInfo");
    cy.testBreadcrumbs(["Home", "Business Object Model"]);
    cy.testHeaderAndFooter("ScriptInfo");
    cy.testBrowserTitle("[ScriptInfo] BOM Type");
  });

  it("should redirect to page not found when custom object type does not exist", () => {
    cy.testPageNotFound(
      "/rule-designer/configuration/custom-objects/DoesNotExist",
    );
  });

  it("creates a new custom object with validations", () => {
    // Navigate to create new custom object
    cy.getByTestId("addCustomObjectPropBtn").click();

    // Verify the form elements
    cy.getByTestId("btnFileFormSave")
      .should("exist")
      .should("be.disabled")
      .contains("Save & Commit");
    testFormField("fileFormNameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false);

    // Attempt to save without entering a name
    typeFormField("fileDescriptionInput", "Test custom object description");
    cy.getByTestId("btnFileFormSave").should("not.be.disabled").click();
    testFormFieldValidation("fileFormNameField", "Enter required field");

    // Attempt to save with invalid characters
    testNameFieldValidation();

    //Attempt to save with more than 100 characters
    typeFormField(
      "fileNameInput",
      "ThisIsAVeryLongCustomObjectNameThatExceedsTheMaximumAllowedLengthOfOneHundredCharactersWhichIsNotPermissible",
    );
    cy.getByTestId("btnFileFormSave").should("not.be.disabled").click();
    testFormFieldValidation(
      "fileFormNameField",
      "Maximum length is 100 characters",
    );
  });

  it("adds a property to a custom object", () => {
    // Navigate to a custom object
    cy.getGridRowButtonOrLink(1, 1).click();
    cy.wait(1000);

    // Test adding a new property via the Add Property dialog
    testDialog(cy.getByTestId("addCustomObjectPropBtn"), "Add Property");
    openDialog(cy.getByTestId("addCustomObjectPropBtn"));

    // Verify dialog elements
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled")
      .contains("Apply");

    // Test form fields
    testFormField("nameField", "Name", true);
    testFormField("typeField", "Type", true);
    testFormField("isArrayField", "Is Array?", false, { isCheckbox: true });
    testFormField("isRequiredField", "Is Required?", false, {
      isCheckbox: true,
    });

    verifyInfoTooltip(
      "For object types or arrays, setting this value to true will ensure the object is initialized to empty when this field is referenced in code",
    );

    // validate name field
    testNameFieldValidation("nameField", "nameInput", "dialog-submit-button");

    // Fill in property details
    typeFormField("nameInput", "newProperty");

    // Set as required property
    cy.getByTestId("isRequiredInput").click();

    // Save the new property
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testDialogIsNotDisplayed();

    // Verify the new property appears in the object's property list
    cy.getByTestId("scrollable-table").should("contain", "newProperty");
  });

  it("edits an existing property in a custom object", () => {
    // Navigate to a custom object
    cy.getGridRowButtonOrLink(1, 1).click();
    cy.wait(1000);

    // Test editing an existing property
    testDialog(cy.getByTestId("editCustomObjectFieldBtn-0"), "Edit Property");

    cy.wait(500);
    openDialog(cy.getByTestId("editCustomObjectFieldBtn-0"));

    // Verify the form is pre-populated with existing values
    cy.getByTestId("nameInput").should("have.value", "t1");
    cy.getByTestId("typeInput").should("contain", "String");

    // Update the property name
    cy.getByTestId("nameInput").clear();
    typeFormField("nameInput", "updatedDescription");

    // Save changes
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testDialogIsNotDisplayed();

    // Verify the updated property appears in the list
    cy.getByTestId("scrollable-table").should("contain", "updatedDescription");

    cy.getGridRowButtonOrLink(0, 1).click();

    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true; // Simulate clicking 'OK'
    });
  });

  it("should display compilation error indicator after saving a custom object with errors", () => {
    // Navigate to save-CustomObject which will have compile errors
    cy.visit("/rule-designer/configuration/custom-objects/save-CustomObject");
    cy.wait(2000);

    // Verify compilation error button is not displayed initially (fresh load)
    cy.getByTestId("compile-errors-btn").should("exist");

    // Edit one of the existing properties
    cy.getByTestId("editCustomObjectFieldBtn-0").should("exist").click();
    cy.wait(500);

    // Change the name and submit
    cy.getByTestId("nameInput").should("exist").clear();
    cy.getByTestId("nameInput").type("updatedFieldName");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();

    cy.getByTestId("dialog-container").should("not.exist");

    cy.getByTestId("saveCustomObjectBtn")
      .should("exist")
      .should("not.be.disabled")
      .click();

    cy.getByTestId("compile-errors-btn").should("exist");

    cy.getByTestId("compile-errors-btn").click();

    cy.getByTestId("bottom-drawer").should("exist");

    cy.getByTestId("compile-result-group-0")
      .find("li[data-testid='compile-result-item-0']")
      .should("exist")
      .as("compileResultItem0");
    cy.get("@compileResultItem0")
      .find("svg[data-icon='triangle-exclamation']")
      .should("exist");
    cy.get("@compileResultItem0")
      .find("div[data-testid='compile-result-text']")
      .should("contain", "invalid field reference save-CustomObject.temp123");

    cy.getByTestId("compile-result-group-0")
      .find("li[data-testid='compile-result-item-0'] a")
      .click();
    cy.url().should(
      "contain",
      "/rule-designer/designer/rule-sets/Batch_Activity_RS?designer",
    );
  });
});
