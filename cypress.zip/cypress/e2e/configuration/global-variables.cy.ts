import { skipOn } from "@cypress/skip-test";
import { getRelativeDate } from "../../utils/date-utils";
import {
  cancelDialog,
  openDialog,
  submitDialog,
  testDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../utils/dialog-utils";
import {
  clearFormField,
  selectFormField,
  testFormField,
  testFormFieldValidation,
  testNameFieldValidation,
  typeFormField,
} from "../../utils/form-utils";
import {
  clickGridRow,
  testColumnNotSortable,
  testColumnVisibility,
  testFilter,
  testPagination,
  testRow,
  testTable,
  toggleColumnVisibility,
} from "../../utils/grid-utils";
import {
  ToastMessage,
  ToastTitle,
  clickToastActionButton,
  testToast,
} from "../../utils/toast-utils";
import { deleteArtifact } from "../../utils/utils";
import {
  testAssociatedRecordsGrid,
  testAssociatedRecordsGridRow,
  testAssociatedRecordsSheet,
} from "../../utils/associated-records-utils";
import { testGlobalVariablesDataTable } from "../../utils/revision-history-utils";

describe("global variables", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/configuration/global-variables");
    cy.wait(1000);
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter("Global Variables");
    cy.testBrowserTitle("Global Variables");
    cy.testNavbar("Configuration");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Configuration", "Global Variables");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays item checked out by me icon", () => {
    cy.getByTestId("lock-button")
      .find("svg[data-icon='user-lock'].text-he-green-1")
      .should("exist");

    // test the tooltip
    cy.getByTestId("lock-button").should("exist").focus(); // make the tooltip appear
    cy.getByTestId("lock-tooltip").contains("Item checked out by me");
    cy.getByTestId("lock-tooltip").contains("06/06/2024, 5:39 pm");
    cy.getByTestId("lock-tooltip").contains(
      "Click to commit or revert changes",
    );
  });

  it("displays a grid", () => {
    testTable(
      ["Variable Name", "Type", "Is Array?", "Value", "Actions"],
      [
        "isTrue",
        "boolean",
        "",
        "true",
        { type: "button", value: "delete variable isTrue" },
      ],
    );
    testRow(2, [
      "ActiveRuleArray",
      "String",
      { type: "icon", value: "check", screenReaderText: "item is an array" },
      "",
      { type: "button", value: "delete variable ActiveRuleArray" },
    ]);

    // FOR SOME REASON THESE FILTER TESTS ARE NOT WORKING, BUT FILTERING WORKS FINE OUTSIDE OF MOCK, SO COMMENTING OUT
    // testFilter("empty", [
    //   "emptyString1",
    //   "String",
    //   "",
    //   '""',
    //   { type: "button", value: "delete variable emptyString1" },
    // ]);
    // testFilter('Logger.getLogger("GuidingSigns");', [
    //   "logger",
    //   "Logger",
    //   "",
    //   'Logger.getLogger("GuidingSigns");',
    //   { type: "button", value: "delete variable logger" },
    // ]);
    // for (let columnIndex = 0; columnIndex <= 4; columnIndex++) {
    //   testColumnNotSortable(columnIndex);
    // }
    testPagination(9);
    testColumnVisibility(["Type", "Is Array", "Value"]);
    // THESE ARE INTERMITTENTLY FAILING - COMMENTING OUT FOR NOW
    // toggleColumnVisibility("Type", [
    //   "Variable Name",
    //   "Is Array?",
    //   "Value",
    //   "Actions",
    // ]);
    // toggleColumnVisibility("Is Array?", [
    //   "Variable Name",
    //   "Type",
    //   "Value",
    //   "Actions",
    // ]);
    // toggleColumnVisibility("Value", [
    //   "Variable Name",
    //   "Type",
    //   "Is Array?",
    //   "Actions",
    // ]);
  });

  it("displays the compile errors button", () => {
    cy.getByTestId("bottom-drawer").should("not.exist");

    // Check if the compile errors button exists and is visible
    cy.getByTestId("compile-errors-btn")
      .should("exist")
      .should("be.visible")
      .click();

    // Verify that the compile results element is displayed
    cy.getByTestId("bottom-drawer").should("exist");
    cy.getByTestId("bottom-drawer-title").contains("Compile Results");
    cy.getByTestId("bottom-drawer-refresh-btn").should("not.exist");
    cy.getByTestId("bottom-drawer-content")
      .should("exist")
      .should("contain", "literalStringCheck")
      .should("contain", "Showing results for Global Variables")
      .should(
        "contain",
        "unresolved var my. Add quotes if you are specifying a literal string.",
      );

    // click the show all results button and verify the refresh button is displayed
    cy.getByTestId("showAllResults").should("exist").click();
    cy.getByTestId("bottom-drawer-refresh-btn").should("exist");
  });

  it("adds a new global variable", () => {
    skipOn("firefox");
    // eslint-disable-next-line cypress/no-assigning-return-values
    const triggerBtn = cy.getByTestId("addGlobalVariableBtn");

    testDialog(cy.getByTestId("addGlobalVariableBtn"), "Add Global Variable");

    openDialog(triggerBtn);
    cy.wait(500);
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      // .should("be.disabled")  // disabled until content assistant is taken care
      .contains("Save");

    // test form fields
    testFormField("varNameField", "Name", true);
    const expectedSelectOptions = [
      "Select one",
      "ActActivity",
      "ActAidSupplemental",
      "ActAlert",
      "ActAssignment",
      "ActAuthActivity",
      "ActAuthAssignment",
      "ActAuthProvider",
      "ActAuthRequest",
      "ActAuthServiceLine",
    ];
    testFormField("varTypeField", "Type", true, {
      expectedSelectOptions: expectedSelectOptions,
      numSelectOptionsToTest: 10,
    });
    cy.getByTestId("initExprField").should("exist");

    testFormField("varArrayField", "Is Array?", false, { isCheckbox: true });

    // test validation
    cy.getByTestId("arrayInput").click();
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testIsDialogDisplayed(); // dialog should not have closed due to validation error
    testFormFieldValidation("varNameField", "Enter required field");
    testFormFieldValidation("varTypeField", "Enter required field");

    // test name validation
    testNameFieldValidation(
      "varNameField",
      "varNameInput",
      "dialog-submit-button",
    );

    typeFormField("varNameInput", "valid_name123");

    // test instructional text for type=String
    cy.getByTestId("initExprField")
      .find("p.form-description")
      .should("not.exist");
    selectFormField("varTypeInput", "String");
    cy.getByTestId("initExprField")
      .find("p.form-description")
      .should("exist")
      .contains("Use quotes if you are specifying a literal string.");

    cancelDialog();

    // test duplicate check
    openDialog(triggerBtn);
    selectFormField("varTypeInput", "String");
    typeFormField("varNameInput", "logger");
    submitDialog();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_DUPLICATE);

    cy.wait(2000);

    // test save
    selectFormField("varTypeInput", "String");
    cy.getByTestId("initExprField")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("newValue");
    typeFormField("varNameInput", "newVar.test");
    submitDialog();
    testFormFieldValidation(
      "varNameField",
      "Field can only contain alphanumeric characters and underscores",
      true,
    );
    cy.getByTestId("varNameInput").clear();
    typeFormField("varNameInput", "newVar");
    submitDialog();
    cy.wait(500);
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE); // this will fail if the ERROR_DUPLICATE toast is still visible (GCRE-2097)

    // Check if the compile errors button exists and is visible
    cy.getByTestId("compile-errors-btn")
      .should("exist")
      .should("be.visible")
      .click();

    // Verify that the compile results element is displayed
    cy.getByTestId("bottom-drawer").should("exist");
    cy.getByTestId("bottom-drawer-title").contains("Compile Results");
    cy.getByTestId("bottom-drawer-refresh-btn").should("not.exist");
    cy.getByTestId("bottom-drawer-content")
      .should("exist")
      .should("contain", "literalStringCheck")
      .should(
        "contain",
        "unresolved var my. Add quotes if you are specifying a literal string.",
      );
  });

  it("edits a global variable", () => {
    // eslint-disable-next-line cypress/no-assigning-return-values
    const triggerBtn = cy.getGridRowButtonOrLink(0, 0);
    testDialog(triggerBtn, "Edit Global Variable");

    openDialog(triggerBtn);
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      // .should("be.disabled") // disabled until content assistant is taken care
      .contains("Save");

    testFormField("varNameField", "Name", true, { expectDisabled: false });
    testFormField("varTypeField", "Type", true, { expectDisabled: false });
    testFormField("varArrayField", "Is Array?", false, {
      isCheckbox: true,
      expectDisabled: false,
    });
    cy.getByTestId("initExprField").should("exist");

    cy.getByTestId("initExprField")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("editValue");
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("not.be.disabled")
      .contains("Save");
    submitDialog();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
  });

  it("deletes a variable", () => {
    testDialog(cy.getGridRowButtonOrLink(0, 4), "Delete Confirmation");
    openDialog(cy.getGridRowButtonOrLink(0, 4));
    deleteArtifact();
  });

  it("cannot delete a variable due to references", () => {
    skipOn("firefox");
    openDialog(cy.getGridRowButtonOrLink(1, 4));
    deleteArtifact(
      "Unable to delete - the item is being referenced by 2 other items",
    );
    clickToastActionButton();
    testAssociatedRecordsSheet("emptyString1", true);
    testAssociatedRecordsGrid(["Rule Set", "Batch_Activity_RS"], true);
    testAssociatedRecordsGridRow(1, ["Function", "entryPointFn"]);
  });

  it("cannot delete a variable due to server error", () => {
    openDialog(cy.getGridRowButtonOrLink(2, 4));
    deleteArtifact("There was a problem while deleting the item");
  });

  it("reorders the list of variables", () => {
    cy.getByTestId("reorderGlobalVariablesBtn").should("exist");

    // eslint-disable-next-line cypress/no-assigning-return-values
    const triggerBtn = cy.getByTestId("reorderGlobalVariablesBtn");
    testDialog(triggerBtn, "Reorder Global Variables");
    cy.getByTestId("reorderGlobalVariablesBtn").should("exist").click();
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled");
    cy.get("table tbody tr").eq(1).should("contain.text", "emptyString1");
    clickGridRow(2, 4, 1, "reorderVariablesGrid");
    cy.get("table tbody tr").eq(2).should("contain.text", "ActiveRuleArray");
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("not.be.disabled")
      .click();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.REORDER_VARIABLES);
    cy.getByTestId("reorderGlobalVariablesBtn").should("exist").click();
    testIsDialogDisplayed();
    cy.getByTestId("dialog-cancel-button").should("exist").click();
  });

  it("renames a variable", () => {
    skipOn("firefox"); // intermittent issues on firefox
    cy.wait(500);
    // eslint-disable-next-line cypress/no-assigning-return-values
    const triggerBtn = cy.getGridRowButtonOrLink(0, 0).as("editVarBtn");
    openDialog(triggerBtn);

    testFormField("varNameField", "Name", true, { expectDisabled: false });
    cy.getByTestId("varNameDescription").should("not.exist");

    // test renaming to something that already exists
    cy.getByTestId("varNameInput").clear();
    cy.getByTestId("varNameDescription")
      .should("exist")
      .contains(
        "Beware that renaming a variable could cause compilation errors if being referenced.",
      );
    typeFormField("varNameInput", "emptyString1");
    submitDialog();
    testIsDialogDisplayed();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_DUPLICATE);

    // test renaming to something that does not exist
    cy.getByTestId("varNameInput").clear();
    typeFormField("varNameInput", "renameVar");
    submitDialog();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
  });

  it("should be able to display the compare revision history dialog", () => {
    cy.getByTestId("git-info-button").should("exist");
    cy.getByTestId("git-info-button").click({ force: true });
    cy.getByTestId("view-revision-history-btn").should("exist");
    cy.getByTestId("view-revision-history-btn").click();
    cy.getByTestId("dialog-form-container").should("exist");

    // Verify that the compare revisions button exists
    cy.getByTestId("compare-revisions-btn").should("exist");
    // Verify the Compare column in the grid exists
    cy.getByTestId("dialog-content")
      .find("th")
      .contains("Compare")
      .should("exist");
    cy.getByTestId("dialog-content")
      .find("th")
      .contains("Revision ID")
      .should("exist");
    cy.getGridRowButtonOrLink(1, 0, 0, "revisionHistoryGrid").click();
    cy.getByTestId("compare-revisions-btn").should("be.disabled");
    cy.getGridRowButtonOrLink(2, 0, 0, "revisionHistoryGrid").click();
    cy.getByTestId("compare-revisions-btn").should("be.enabled");
    cy.getByTestId("compare-revisions-btn").click();

    cy.getByTestId("revision-compare-dialog-container").should("exist");
    cy.getByTestId("revision-compare-dialog-title").contains(
      "Compare Versions",
    );
    cy.getByTestId("revision-compare-dialog-container")
      .find("[data-testid='dialog-description']")
      .contains("Global Variables");

    // Validate version headers
    cy.getByTestId("version-1-panel-title").contains("Version d750ff4");
    cy.getByTestId("version-1-panel-title").contains(
      "Committed " + getRelativeDate("2025-06-10 23:24:53 -0400"),
    );
    cy.getByTestId("version-2-panel-title").contains("Version a635e6d");
    cy.getByTestId("version-2-panel-title").contains(
      "Committed " + getRelativeDate("2025-06-11 08:50:55 -0400"),
    );

    // Test global variables data tables - Version 1 (d750ff4) has 3 variables
    testGlobalVariablesDataTable("version-1-panel", [
      {
        varName: "aRealTimeConfigArray",
        varType: "RealTimeConfig",
        isArray: true,
        initExpr: "",
      },
      {
        varName: "currentAuthrequestRealtime",
        varType: "String",
        isArray: false,
        initExpr: "",
      },
      {
        varName: "currentComplaintRealtime",
        varType: "Complaint",
        isArray: true,
        initExpr: "",
      },
    ]);

    // Test global variables data tables - Version 2 (a635e6d) has 6 variables
    testGlobalVariablesDataTable("version-2-panel", [
      {
        varName: "aRealTimeConfigArray",
        varType: "RealTimeConfig",
        isArray: true,
        initExpr: "",
      },
      {
        varName: "currentAuthrequestRealtime",
        varType: "AuthRequest",
        isArray: false,
        initExpr: "",
      },
      {
        varName: "currentComplaintRealtime",
        varType: "Complaint",
        isArray: false,
        initExpr: "",
      },
      {
        varName: "ActiveRuleMetadataArray",
        varType: "ActiveRuleMetadata",
        isArray: true,
        initExpr: "",
      },
      {
        varName: "logger",
        varType: "Logger",
        isArray: false,
        initExpr: 'Logger.getLogger("GuidingSigns")',
      },
      {
        varName: "theRequest",
        varType: "Request",
        isArray: false,
        initExpr: "",
      },
    ]);

    // Close the compare dialog
    cy.getByTestId("revision-compare-dialog-cancel-button")
      .should("exist")
      .click();
    cy.getByTestId("revision-compare-dialog-container").should("not.exist");

    cy.getByTestId("dialog-cancel-button").click();
    cy.getByTestId("dialog-form-container").should("not.exist");
  });

  it("should compare uncommitted version against a committed revision", () => {
    cy.getByTestId("git-info-button").should("exist");
    cy.getByTestId("git-info-button").click({ force: true });
    cy.getByTestId("view-revision-history-btn").should("exist");
    cy.getByTestId("view-revision-history-btn").click();
    cy.getByTestId("dialog-form-container").should("exist");

    // Select the uncommitted version (row 0) and revision d750ff4 (row 1)
    cy.getGridRowButtonOrLink(0, 0, 0, "revisionHistoryGrid").click();
    cy.getByTestId("compare-revisions-btn").should("be.disabled");
    cy.getGridRowButtonOrLink(2, 0, 0, "revisionHistoryGrid").click();
    cy.getByTestId("compare-revisions-btn").should("be.enabled");
    cy.getByTestId("compare-revisions-btn").click();

    // Verify the compare dialog is displayed
    cy.getByTestId("revision-compare-dialog-container").should("exist");
    cy.getByTestId("revision-compare-dialog-title").contains(
      "Compare Versions",
    );
    cy.getByTestId("revision-compare-dialog-container")
      .find("[data-testid='dialog-description']")
      .contains("Global Variables");

    // Validate version headers
    cy.getByTestId("version-1-panel-title").contains("Version d750ff4");
    cy.getByTestId("version-1-panel-title").contains(
      "Committed " + getRelativeDate("2025-06-10 23:24:53 -0400"),
    );
    cy.getByTestId("version-2-panel-title").contains("Uncommitted Version");

    // Test global variables data tables - Version 1 (d750ff4) has 3 variables
    testGlobalVariablesDataTable("version-1-panel", [
      {
        varName: "aRealTimeConfigArray",
        varType: "RealTimeConfig",
        isArray: true,
        initExpr: "",
      },
      {
        varName: "currentAuthrequestRealtime",
        varType: "String",
        isArray: false,
        initExpr: "",
      },
      {
        varName: "currentComplaintRealtime",
        varType: "Complaint",
        isArray: true,
        initExpr: "",
      },
    ]);

    // Test global variables data tables - Uncommitted version has 7 variables
    testGlobalVariablesDataTable("version-2-panel", [
      {
        varName: "aRealTimeConfigArray",
        varType: "RealTimeConfig",
        isArray: true,
        initExpr: "",
      },
      {
        varName: "currentAuthrequestRealtime",
        varType: "AuthRequest",
        isArray: false,
        initExpr: "",
      },
      {
        varName: "currentComplaintRealtime",
        varType: "Complaint",
        isArray: false,
        initExpr: "",
      },
      {
        varName: "ActiveRuleMetadataArray",
        varType: "ActiveRuleMetadata",
        isArray: true,
        initExpr: "",
      },
      {
        varName: "logger",
        varType: "Logger",
        isArray: false,
        initExpr: 'Logger.getLogger("GuidingSigns")',
      },
      {
        varName: "theRequest",
        varType: "Request",
        isArray: false,
        initExpr: "",
      },
      {
        varName: "newVariable",
        varType: "Request",
        isArray: false,
        initExpr: "",
      },
    ]);

    // Close the compare dialog
    cy.getByTestId("revision-compare-dialog-cancel-button")
      .should("exist")
      .click();
    cy.getByTestId("revision-compare-dialog-container").should("not.exist");

    cy.getByTestId("dialog-cancel-button").click();
    cy.getByTestId("dialog-form-container").should("not.exist");
  });
});
