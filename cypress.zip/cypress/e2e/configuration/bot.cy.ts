import { skipOn } from "@cypress/skip-test";
import {
  testColumnVisibility,
  testFilter,
  testPagination,
  testRow,
  testSort,
  testTable,
  toggleColumnVisibility,
} from "../../utils/grid-utils";

describe("business object model", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/configuration/bot");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testBrowserTitle("Business Object Model");
    cy.testHeaderAndFooter("Business Object Model");
    cy.testNavbar("Configuration");
    cy.testBreadcrumbs(["Home"]);

    cy.testSidebar("Configuration", "Business Object Model");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays a grid", () => {
    testTable(["Name"], ["ActActivity"]);
    testFilter("Request", ["ActAuthRequest"]);
    testSort(0, ["ActActivity"], ["WorkQueue"], "ascending");
    // intermittently failing (not a bug):
    //testPagination(160, 100, ["Index"]);
  });

  it("navigates to nested business type and displays grid", () => {
    cy.getGridRowButtonOrLink(0, 0).click();
    cy.url().should("include", "/rule-designer/configuration/bot/ActActivity");
    cy.testBreadcrumbs(["Home", "Business Object Model"]);
    cy.testHeaderAndFooter("ActActivity");
    cy.testBrowserTitle("[ActActivity] BOM Type");
    testTable(
      [
        "Name",
        "Type",
        "Is Array?",
        "Is Required?",
        "Nullable?",
        "Auto Instantiate?",
      ],
      [
        "activityDuration",
        "String",
        "",
        { type: "icon", value: "check", screenReaderText: "item is required" },
        "",
        "",
      ],
    );
    testRow(8, [
      "conflictOfEventList",
      "ConflictOfEvent",
      { type: "icon", value: "check", screenReaderText: "item is an array" },
      { type: "icon", value: "check", screenReaderText: "item is required" },
      { type: "icon", value: "check", screenReaderText: "item is nullable" },
      {
        type: "icon",
        value: "check",
        screenReaderText: "item is auto instantiate",
      },
    ]);
    testColumnVisibility([
      "Type",
      "Is Array?",
      "Is Required?",
      "Nullable?",
      "Auto Instantiate?",
    ]);
    toggleColumnVisibility("Type", [
      "Name",
      "Is Array?",
      "Is Required?",
      "Nullable?",
      "Auto Instantiate?",
    ]);

    // test nav to double-nested type
    cy.getGridRowButtonOrLink(8, 1).click();
    cy.url().should(
      "include",
      "/rule-designer/configuration/bot/ActActivity/ConflictOfEvent",
    );
    cy.testBreadcrumbs(["Home", "Business Object Model", "ActActivity"]);
    cy.testHeaderAndFooter("ConflictOfEvent");
    cy.testBrowserTitle("[ConflictOfEvent] BOM Type");
  });
});

it("should redirect to page not found when bom does not exist", () => {
  cy.testPageNotFound(
    "/rule-designer/configuration/bot/ActActivity/DoesNotExist",
  );
});
