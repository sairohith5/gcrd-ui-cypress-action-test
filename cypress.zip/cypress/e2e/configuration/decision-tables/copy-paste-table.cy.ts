import {
  clickRowContextMenuOption,
  testRowContextMenu,
  testDecisionTableRow,
  getTableCell,
  getTableCellButton,
  NULL_DISPLAY,
  testCellConditionTooltip,
  clickColumnContextMenuOption,
  testColumnContextMenu,
  filterDecisionTable,
  clearDecisionTableFilter,
  clickTableCellButton,
} from "../../../utils/decision-table-utils";
import { clickAnywhere, deleteArtifact } from "../../../utils/utils";
import {
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";
import {
  testFormFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import { TIMEZONE_AWARE_TEST_DATES } from "../../../utils/date-utils";

describe("copy/paste decision table data", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/DT_TestCopyPaste");
  });

  it("should copy cell value along with cell condition", () => {
    cy.wait(1000);

    // Right-click copy first column's first row's value
    getTableCell(0, 0).should("contain.text", "abc");
    getTableCell(0, 0).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();

    // Go to second column, second row cell and right-click and verify that Paste is not exist in dropdown
    getTableCell(1, 3).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");

    // Close the context menu
    clickAnywhere();
    cy.wait(100);

    getTableCell(2, 0).should("contain.text", "ghi");
    // Go to first column third row cell and right-click and verify the paste exist and click
    getTableCell(2, 0).rightclick();
    cy.getByTestId("cellContextMenu")
      .should("contain.text", "Copy cell")
      .should("contain.text", "Paste cell");
    cy.getByTestId("paste-cell-menu-item").should("exist").click();

    // Verify the cell value is abc, cell condition is cellCondition1
    getTableCell(2, 0).should("contain.text", "abc");

    // Verify cell condition tooltip shows cellCondition1
    testCellConditionTooltip(2, 1, "cellCondition1", "theRequest");

    clickAnywhere();
    cy.wait(100);
    //verify that copied cell can be pasted multiple times
    getTableCell(1, 0).rightclick();
    cy.getByTestId("cellContextMenu")
      .should("contain.text", "Copy cell")
      .should("contain.text", "Paste cell");
    cy.getByTestId("paste-cell-menu-item").should("exist").click();

    getTableCell(1, 0).should("contain.text", "abc");

    testCellConditionTooltip(1, 1, "cellCondition1", "theRequest");

    //test integer column
    getTableCell(0, 1).should("contain.text", "2");
    getTableCell(0, 1).rightclick();
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(1, 3).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");
    clickAnywhere();
    cy.wait(100);
    getTableCell(2, 1).should("contain.text", "10");
    getTableCell(2, 1).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(2, 1).should("contain.text", "2");

    //test boolean column
    getTableCell(0, 2)
      .find("button")
      .should("exist")
      .should("have.attr", "aria-checked", "true");
    getTableCell(0, 2).rightclick();
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(1, 5).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");
    clickAnywhere();
    cy.wait(100);
    getTableCell(1, 2)
      .find("button")
      .should("exist")
      .should("have.attr", "aria-checked", "false");
    getTableCell(1, 2).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(1, 2)
      .find("button")
      .should("exist")
      .should("have.attr", "aria-checked", "true");

    //test date column
    getTableCell(0, 3).should("contain.text", "12/08/2025");
    getTableCell(0, 3).rightclick();
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(1, 4).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");
    clickAnywhere();
    cy.wait(100);
    getTableCell(2, 3).should("contain.text", NULL_DISPLAY);
    getTableCell(2, 3).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(2, 3).should("contain.text", "12/08/2025");

    //test datetime column
    getTableCell(0, 4).should(
      "contain.text",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
    );
    getTableCell(0, 4).rightclick();
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(1, 5).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");
    clickAnywhere();
    cy.wait(100);
    getTableCell(1, 4).should(
      "contain.text",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_17_2025_3_27_PM,
    );
    getTableCell(1, 4).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(1, 4).should(
      "contain.text",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
    );

    //test string array column
    getTableCell(0, 5).should("contain.text", "test1");
    getTableCell(0, 5).should("contain.text", "test2");
    getTableCell(0, 5).should("contain.text", "test3");
    getTableCell(0, 5).rightclick();
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(1, 2).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");
    clickAnywhere();
    cy.wait(100);
    getTableCell(1, 5).should("contain.text", "temp1");
    testCellConditionTooltip(1, 6, "defaultCondition", "theRequest");
    getTableCell(1, 5).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(1, 5).should("contain.text", "test1");
    getTableCell(1, 5).should("contain.text", "test2");
    getTableCell(1, 5).should("contain.text", "test3");
  });
  it("should copy and paste rows along with associate cell conditions", () => {
    cy.wait(1000);
    testDecisionTableRow(0, [
      "1",
      "abc",
      "2",
      { type: "checkbox", isChecked: true },
      "12/08/2025",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
      ["test1", "test2", "test3"],
      NULL_DISPLAY,
    ]);
    testCellConditionTooltip(0, 1, "cellCondition1", "theRequest");
    testRowContextMenu(0, [
      "Insert row below",
      "Move row down",
      "Copy row",
      "Duplicate row",
      "Delete row",
    ]);
    clickRowContextMenuOption(0, 2);
    testRowContextMenu(1, [
      "Insert row below",
      "Move row up",
      "Move row down",
      "Copy row",
      "Paste row",
      "Duplicate row",
      "Delete row",
    ]);
    clickRowContextMenuOption(2, 3);
    testDecisionTableRow(3, [
      "4",
      "abc",
      "2",
      { type: "checkbox", isChecked: true },
      "12/08/2025",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
      ["test1", "test2", "test3"],
      NULL_DISPLAY,
    ]);
    clickRowContextMenuOption(0, 3);
    testDecisionTableRow(1, [
      "2",
      "abc",
      "2",
      { type: "checkbox", isChecked: true },
      "12/08/2025",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
      ["test1", "test2", "test3"],
      NULL_DISPLAY,
    ]);
    testCellConditionTooltip(1, 1, "cellCondition1", "theRequest");
    testCellConditionTooltip(4, 1, "cellCondition1", "theRequest");
  });

  it("should paste copied row to the top when paste row option is clicked from column header", () => {
    cy.wait(3000);
    testColumnContextMenu(0, [
      "Insert column right",
      "Insert row below",
      "Apply Default Conditions",
    ]);
    clickRowContextMenuOption(0, 2);
    testColumnContextMenu(0, [
      "Insert column right",
      "Insert row below",
      "Paste row at first position",
      "Apply Default Conditions",
    ]);
    clickColumnContextMenuOption(0, 2);
    testDecisionTableRow(0, [
      "1",
      "abc",
      "2",
      { type: "checkbox", isChecked: true },
      "12/08/2025",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
      ["test1", "test2", "test3"],
      NULL_DISPLAY,
    ]);
    //can paste copied row multiple times
    clickRowContextMenuOption(3, 3);
    testDecisionTableRow(4, [
      "5",
      "abc",
      "2",
      { type: "checkbox", isChecked: true },
      "12/08/2025",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
      ["test1", "test2", "test3"],
      NULL_DISPLAY,
    ]);
  });

  it("should validate target position field when duplicating row and duplicate the row appropriately", () => {
    cy.wait(2000);
    testDecisionTableRow(0, [
      "1",
      "abc",
      "2",
      { type: "checkbox", isChecked: true },
      "12/08/2025",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
      ["test1", "test2", "test3"],
      NULL_DISPLAY,
    ]);
    testCellConditionTooltip(0, 1, "cellCondition1", "theRequest");
    testRowContextMenu(0, [
      "Insert row below",
      "Move row down",
      "Copy row",
      "Duplicate row",
      "Delete row",
    ]);
    clickRowContextMenuOption(0, 3);
    testIsDialogDisplayed("duplicate-row-position-0-dialog-container");
    cy.getByTestId("duplicate-row-position-0-dialog-submit-button")
      .should("be.disabled")
      .as("submitButton");
    cy.get('form[data-testid="duplicate-row-position-0-dialog-form"]').as(
      "form",
    );
    cy.getByTestId("position-range-info").contains("Valid range: 1 to 4");

    // verify cannot type in non-numeric characters
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "abc");
    cy.getByTestId("position-input").should("have.value", "");
    cy.get("@submitButton").should("be.disabled");

    // verify cannot type in 0
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "0");
    cy.getByTestId("position-input").should("have.value", "");
    cy.get("@submitButton").should("be.disabled");

    // verify cannot type in numbers greater than total rows + 1
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "5");
    cy.getByTestId("position-input").should("have.value", "");
    cy.get("@submitButton").should("be.disabled");

    // verify can type in valid position
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "2");
    cy.wait(500);
    cy.get("@form").submit();
    testDialogIsNotDisplayed("duplicate-row-position-0-dialog-container");
    testDecisionTableRow(1, [
      "2",
      "abc",
      "2",
      { type: "checkbox", isChecked: true },
      "12/08/2025",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
      ["test1", "test2", "test3"],
      NULL_DISPLAY,
    ]);
    testCellConditionTooltip(1, 1, "cellCondition1", "theRequest");
  });

  it("should filter decision table rows and copy/paste rows", () => {
    cy.wait(1000);
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("importFileBtn").click();

    const fileName = "DT_TestCopyPaste_MockData.xlsx";
    const fileType =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    cy.fixture(fileName, "binary")
      .then(Cypress.Blob.binaryStringToBlob)
      .then((blob) => {
        cy.get('input[type="file"]').attachFile({
          fileContent: blob,
          fileName,
          mimeType: fileType,
        });
      });
    cy.getByTestId("missingCellConditionsDialog-dialog-cancel-button").click();
    clickRowContextMenuOption(7, 3);
    filterDecisionTable("test50");
    clickRowContextMenuOption(0, 2);
    testDecisionTableRow(1, [
      "49",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
    clearDecisionTableFilter();
    testDecisionTableRow(48, [
      "49",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
    clickRowContextMenuOption(3, 4);
    testDecisionTableRow(4, [
      "5",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();
    clickRowContextMenuOption(15, 4);
    testDecisionTableRow(16, [
      "67",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
    filterDecisionTable("test71");
    clickRowContextMenuOption(0, 2);
    testDecisionTableRow(1, [
      "73",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
    clearDecisionTableFilter();
    cy.wait(500);
    cy.getByTestId("decisionTablePaginationLastPageBtn").click({ force: true });
    testDecisionTableRow(22, [
      "73",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
    filterDecisionTable("HealthEdge");
    testColumnContextMenu(0, [
      "Insert column right",
      "Insert row below",
      "Paste row at first position",
      "Apply Default Conditions",
    ]);
    clickColumnContextMenuOption(0, 2);
    testDecisionTableRow(0, [
      "1",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
    clearDecisionTableFilter();
    testDecisionTableRow(0, [
      "1",
      "Test5",
      "19",
      { type: "checkbox", isChecked: true },
      "20/08/2029",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test10"],
      NULL_DISPLAY,
    ]);
  });

  it("should duplicate row with cell conditions while filtering", () => {
    cy.wait(500);
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("importFileBtn").click();

    const fileName = "DT_TestCopyPaste_MockData.xlsx";
    const fileType =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    cy.fixture(fileName, "binary")
      .then(Cypress.Blob.binaryStringToBlob)
      .then((blob) => {
        cy.get('input[type="file"]').attachFile({
          fileContent: blob,
          fileName,
          mimeType: fileType,
        });
      });
    cy.getByTestId("missingCellConditionsDialog-dialog-cancel-button").click();
    filterDecisionTable("test37");
    cy.wait(500);
    clickRowContextMenuOption(1, 2);
    cy.getByTestId("duplicate-row-position-1-dialog-submit-button")
      .should("be.disabled")
      .as("submitButton");
    cy.get('form[data-testid="duplicate-row-position-1-dialog-form"]').as(
      "form",
    );
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "1");
    cy.wait(500);
    cy.get("@form").submit();
    clearDecisionTableFilter();
    testDecisionTableRow(0, [
      "1",
      "Test37",
      "51",
      { type: "checkbox", isChecked: true },
      "20/08/2061",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test42"],
      NULL_DISPLAY,
    ]);
    testCellConditionTooltip(0, 1, "cellCondition1", "theRequest");
    //duplicate at 55th position
    filterDecisionTable("test37");
    cy.wait(500);
    clickRowContextMenuOption(2, 2);
    cy.getByTestId("duplicate-row-position-2-dialog-submit-button")
      .should("be.disabled")
      .as("submitButton");
    cy.get('form[data-testid="duplicate-row-position-2-dialog-form"]').as(
      "form",
    );
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "55");
    cy.wait(500);
    cy.get("@form").submit();
    clearDecisionTableFilter();
    cy.wait(500);
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();
    testDecisionTableRow(4, [
      "55",
      "Test37",
      "51",
      { type: "checkbox", isChecked: true },
      "20/08/2061",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test42"],
      NULL_DISPLAY,
    ]);
    testCellConditionTooltip(4, 1, "cellCondition1", "theRequest");
    //duplicate at the end of the table
    filterDecisionTable("test37");
    cy.wait(500);
    clickRowContextMenuOption(3, 2);
    cy.getByTestId("duplicate-row-position-3-dialog-submit-button")
      .should("be.disabled")
      .as("submitButton");
    cy.get('form[data-testid="duplicate-row-position-3-dialog-form"]').as(
      "form",
    );
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "72");
    cy.wait(500);
    cy.get("@form").submit();
    clearDecisionTableFilter();
    cy.wait(500);
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();
    testDecisionTableRow(21, [
      "72",
      "Test37",
      "51",
      { type: "checkbox", isChecked: true },
      "20/08/2061",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_2_26_PM,
      ["test4", "test5", "test42"],
      NULL_DISPLAY,
    ]);
    testCellConditionTooltip(21, 1, "cellCondition1", "theRequest");
  });

  it("should not allow pasting when the cell is in edit mode", () => {
    cy.wait(1000);

    // Right-click copy first column's first row's value
    getTableCell(0, 0).should("contain.text", "abc");
    getTableCell(0, 0).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();

    clickTableCellButton(2, 0);
    getTableCell(2, 0).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");

    //integer type column
    getTableCell(0, 1).should("contain.text", "2");
    getTableCell(0, 1).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();

    clickTableCellButton(2, 1);
    getTableCell(2, 1).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");

    //date type column
    getTableCell(0, 3).should("contain.text", "12/08/2025");
    getTableCell(0, 3).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();

    clickTableCellButton(2, 3);
    getTableCell(2, 3).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");

    //date-time type column
    getTableCell(0, 4).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();

    clickTableCellButton(2, 4);
    getTableCell(2, 4).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("not.exist");
  });

  it("should allow copying cell when the cell is in edit mode and validate whether the unsaved value is pasted", () => {
    cy.wait(1000);

    // Right-click copy first column's first row's value
    getTableCell(0, 0).should("contain.text", "abc");
    clickTableCellButton(0, 0);
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("testing");
    getTableCell(0, 0).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();

    getTableCell(2, 0).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(2, 0).should("contain.text", "abc");

    //integer type column
    getTableCell(0, 1).should("contain.text", "2");
    clickTableCellButton(0, 1);
    cy.getByTestId("numCell").clear();
    cy.getByTestId("numCell").type("90");
    getTableCell(0, 1).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(2, 1).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(2, 1).should("contain.text", "2");

    //date type column
    getTableCell(0, 3).should("contain.text", "12/08/2025");
    clickTableCellButton(0, 3);
    cy.get("[data-testid='dateCellBox'] input").as("dateCell");
    cy.get("@dateCell").type("01-02-2023", { force: true });
    getTableCell(0, 3).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(2, 3).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(2, 3).should("contain.text", "12/08/2025");

    //date-time type column
    getTableCell(0, 4).should(
      "contain.text",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
    );
    clickTableCellButton(0, 4);
    cy.get("[data-testid='datetimeCellBox'] input").as("datetimeCell");
    cy.get("@datetimeCell").type("01-02-2023 12:30 PM", { force: true });
    getTableCell(0, 4).rightclick();
    cy.getByTestId("cellContextMenu").should("contain.text", "Copy cell");
    cy.getByTestId("copy-cell-menu-item").should("exist").click();
    getTableCell(2, 4).rightclick();
    cy.getByTestId("paste-cell-menu-item").should("exist").click();
    getTableCell(2, 4).should(
      "contain.text",
      TIMEZONE_AWARE_TEST_DATES.AUGUST_7_2025_3_26_PM,
    );
  });
});
