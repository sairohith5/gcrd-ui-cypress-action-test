import {
  clickColumnContextMenuOption,
  testDecisionTableRow,
  getTableCell,
  NULL_DISPLAY,
} from "../../../utils/decision-table-utils";
import { selectFormField } from "../../../utils/form-utils";

import "cypress-file-upload";

describe("data type conversions", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypeConversion");
  });

  describe("String to other types conversion", () => {
    it("should convert String to Number (Integer/Long/Double)", () => {
      // Test String to Integer conversion
      clickColumnContextMenuOption(1, 0); // Edit String column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "int");
      cy.getByTestId("dialog-submit-button").click();

      // Verify conversions:
      // "abc" -> NULL, "" -> NULL, "85" -> 85, "TRUE" -> NULL
      getTableCell(0, 0).should("contain", NULL_DISPLAY);
      getTableCell(1, 0).should("contain", NULL_DISPLAY);
      getTableCell(2, 0).should("contain", "85");
      getTableCell(3, 0).should("contain", NULL_DISPLAY);
      getTableCell(5, 0).should("contain", NULL_DISPLAY);
    });

    it("should convert String to Boolean", () => {
      clickColumnContextMenuOption(1, 0); // Edit String column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "boolean");
      cy.getByTestId("dialog-submit-button").click();

      // Verify conversions:
      // "abc" -> FALSE, "" -> FALSE, "85" -> FALSE, "TRUE" -> TRUE
      getTableCell(0, 0)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(1, 0)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(2, 0)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(3, 0)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "checked");
      getTableCell(5, 0)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
    });

    it("should convert String to Date/DateTime", () => {
      clickColumnContextMenuOption(1, 0); // Edit String column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "Date");
      cy.getByTestId("dialog-submit-button").click();

      // All string values should convert to NULL
      getTableCell(0, 0).should("contain", NULL_DISPLAY);
      getTableCell(1, 0).should("contain", NULL_DISPLAY);
      getTableCell(2, 0).should("contain", NULL_DISPLAY);
      getTableCell(3, 0).should("contain", NULL_DISPLAY);
      getTableCell(5, 0).should("contain", NULL_DISPLAY);
    });
  });

  describe("Number to other types conversion", () => {
    it("should convert Number to String", () => {
      clickColumnContextMenuOption(2, 0); // Edit Integer column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "String");
      cy.getByTestId("dialog-submit-button").click();

      // All numeric values should convert to strings
      getTableCell(0, 1).should("have.text", "85");
      getTableCell(1, 1).should("have.text", "1");
      getTableCell(2, 1).should("have.text", "0");
      getTableCell(3, 1).should("have.text", "85");
    });

    it("should convert Number to Boolean", () => {
      clickColumnContextMenuOption(2, 0); // Edit Integer column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "boolean");
      cy.getByTestId("dialog-submit-button").click();

      // 85 should convert to FALSE (only 0->FALSE, 1->TRUE, others->FALSE)
      getTableCell(0, 1)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(1, 1)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "checked");
      getTableCell(2, 1)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(3, 1)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
    });

    it("should convert Integer to Double", () => {
      clickColumnContextMenuOption(2, 0); // Edit Integer column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "double");
      cy.getByTestId("dialog-submit-button").click();

      // Integer values should convert to corresponding Double values
      getTableCell(0, 1).should("have.text", "85");
      getTableCell(1, 1).should("have.text", "1");
      getTableCell(2, 1).should("have.text", "0");
      getTableCell(3, 1).should("have.text", "85");
    });

    it("should convert Double to Integer with range checking", () => {
      clickColumnContextMenuOption(4, 0); // Edit Double column (42.75)
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "int");
      cy.getByTestId("dialog-submit-button").click();

      // 42.75 should round to 43 and convert to Integer
      getTableCell(0, 3).should("have.text", "43");
      getTableCell(1, 3).should("have.text", "1");
      getTableCell(2, 3).should("have.text", "43");
      getTableCell(3, 3).should("have.text", "NULL");
    });
  });

  describe("Boolean to other types conversion", () => {
    it("should convert Boolean to String", () => {
      clickColumnContextMenuOption(5, 0); // Edit Boolean column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "String");
      cy.getByTestId("dialog-submit-button").click();

      // TRUE should convert to "TRUE"
      getTableCell(0, 4).should("have.text", "TRUE");
      getTableCell(1, 4).should("have.text", "TRUE");
      getTableCell(2, 4).should("have.text", "FALSE");
      getTableCell(3, 4).should("have.text", "FALSE");
    });

    it("should convert Boolean to Number", () => {
      clickColumnContextMenuOption(5, 0); // Edit Boolean column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "int");
      cy.getByTestId("dialog-submit-button").click();

      // TRUE should convert to 1
      getTableCell(0, 4).should("have.text", "1");
      getTableCell(1, 4).should("have.text", "1");
      getTableCell(2, 4).should("have.text", "0");
      getTableCell(3, 4).should("have.text", "0");
    });

    it("should convert Boolean to Date/DateTime", () => {
      clickColumnContextMenuOption(5, 0); // Edit Boolean column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "Date");
      cy.getByTestId("dialog-submit-button").click();

      // All boolean values should convert to NULL
      getTableCell(0, 4).should("have.text", NULL_DISPLAY);
      getTableCell(1, 4).should("have.text", NULL_DISPLAY);
      getTableCell(2, 4).should("have.text", NULL_DISPLAY);
      getTableCell(3, 4).should("have.text", NULL_DISPLAY);
    });
  });

  describe("Date/DateTime to other types conversion", () => {
    it("should convert Date/DateTime to String", () => {
      clickColumnContextMenuOption(6, 0); // Edit Date column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "String");
      cy.getByTestId("dialog-submit-button").click();

      // All date/datetime values should convert to NULL
      getTableCell(0, 5).should("have.text", NULL_DISPLAY);
      getTableCell(1, 5).should("have.text", NULL_DISPLAY);
      getTableCell(2, 5).should("have.text", NULL_DISPLAY);
      getTableCell(3, 5).should("have.text", NULL_DISPLAY);
    });

    it("should convert Date/DateTime to Boolean", () => {
      clickColumnContextMenuOption(6, 0); // Edit Date column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "boolean");
      cy.getByTestId("dialog-submit-button").click();

      // All date/datetime values should convert to FALSE
      getTableCell(0, 5)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(1, 5)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(2, 5)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
      getTableCell(3, 5)
        .find('button[role="checkbox"]')
        .should("have.attr", "data-state", "unchecked");
    });

    it("should convert Date/DateTime to Number", () => {
      clickColumnContextMenuOption(6, 0); // Edit Date column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "long");
      cy.getByTestId("dialog-submit-button").click();

      // Date values should convert to corresponding numeric value (timestamp)
      getTableCell(0, 5).should("have.text", "1734264720000");
      getTableCell(1, 5).should("have.text", "1734264720000");
      getTableCell(2, 5).should("have.text", "1734264720000");
      getTableCell(3, 5).should("have.text", "1734264720000");
    });

    it("should convert Date/DateTime to Integer (NULL due to range)", () => {
      clickColumnContextMenuOption(6, 0); // Edit Date column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "int");
      cy.getByTestId("dialog-submit-button").click();

      // Date timestamps are too large for Integer, should convert to NULL
      getTableCell(0, 5).should("have.text", NULL_DISPLAY);
      getTableCell(1, 5).should("have.text", NULL_DISPLAY);
      getTableCell(2, 5).should("have.text", NULL_DISPLAY);
      getTableCell(3, 5).should("have.text", NULL_DISPLAY);
    });
  });

  describe("Array to non-array conversion", () => {
    it("should convert String array to String value", () => {
      clickColumnContextMenuOption(8, 0); // Edit String array column
      cy.getByTestId("dialog-title").contains("Edit Column");
      cy.getByTestId("isArrayInput").click();
      cy.getByTestId("dialog-submit-button").click();

      // ["abc", "def"] should convert to "abc,def"
      getTableCell(0, 7).should("have.text", "abc,def");
      getTableCell(3, 7).should("have.text", "abc");
      getTableCell(4, 7).should("have.text", "def");
      getTableCell(5, 7).should("have.text", "");
    });

    it("should convert String array to Numeric value", () => {
      clickColumnContextMenuOption(8, 0); // Edit String array column
      cy.getByTestId("dialog-title").contains("Edit Column");
      cy.getByTestId("isArrayInput").click();
      selectFormField("typeInput", "int");
      cy.getByTestId("dialog-submit-button").click();

      // String array to numeric should convert to NULL
      getTableCell(0, 7).should("have.text", NULL_DISPLAY);
      getTableCell(3, 7).should("have.text", NULL_DISPLAY);
      getTableCell(4, 7).should("have.text", NULL_DISPLAY);
      getTableCell(5, 7).should("have.text", NULL_DISPLAY);
    });

    it("should convert Numeric array to Numeric value", () => {
      clickColumnContextMenuOption(9, 0); // Edit Int array column
      cy.getByTestId("dialog-title").contains("Edit Column");
      cy.getByTestId("isArrayInput").click();
      cy.getByTestId("dialog-submit-button").click();

      // [1, 2, 3] should convert to 1 (first element)
      getTableCell(0, 8).should("have.text", "1");
      getTableCell(1, 8).should("have.text", "0");
      getTableCell(2, 8).should("have.text", "1");
      getTableCell(3, 8).should("have.text", "1");
    });
  });

  describe("Non-array to array conversion", () => {
    it("should convert String to String array", () => {
      clickColumnContextMenuOption(1, 0); // Edit String column
      cy.getByTestId("dialog-title").contains("Edit Column");
      cy.getByTestId("isArrayInput").click();
      cy.getByTestId("dialog-submit-button").click();

      getTableCell(0, 0)
        .find("button[data-testid='cell-menu']")
        .should("exist");

      testDecisionTableRow(0, [
        "1",
        ["abc"],
        "85",
        "123456789",
        "42.75",
        { type: "checkbox", isChecked: true },
        "12/15/2024",
        "12/15/2024 07:12",
        ["abc", "def"],
        ["1", "2", "3"],
        ["12/15/2024", "08/04/2025"],
      ]);
    });

    it("should convert Numeric to Numeric array", () => {
      clickColumnContextMenuOption(2, 0); // Edit Integer column
      cy.getByTestId("dialog-title").contains("Edit Column");
      cy.getByTestId("isArrayInput").click();
      cy.getByTestId("dialog-submit-button").click();

      getTableCell(0, 1)
        .find("button[data-testid='cell-menu']")
        .should("exist");

      testDecisionTableRow(0, [
        "1",
        "abc",
        ["85"],
        "123456789",
        "42.75",
        { type: "checkbox", isChecked: true },
        "12/15/2024",
        "12/15/2024 07:12",
        ["abc", "def"],
        ["1", "2", "3"],
        ["12/15/2024", "08/04/2025"],
      ]);
    });
  });

  describe("Array type conversion", () => {
    // only testing a couple of these because the logic is reused to convert non-array to non-array types
    it("should convert String array to Numeric array", () => {
      clickColumnContextMenuOption(8, 0); // Edit String array column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "int");
      cy.getByTestId("dialog-submit-button").click();

      testDecisionTableRow(0, [
        "1",
        "abc",
        ["85"],
        "123456789",
        "42.75",
        { type: "checkbox", isChecked: true },
        "12/15/2024",
        "12/15/2024 07:12",
        ["NULL", "NULL"],
        ["1", "2", "3"],
        ["12/15/2024", "08/04/2025"],
      ]);
    });

    it("should convert Numeric array to String array", () => {
      clickColumnContextMenuOption(9, 0); // Edit Int array column
      cy.getByTestId("dialog-title").contains("Edit Column");
      selectFormField("typeInput", "String");
      cy.getByTestId("dialog-submit-button").click();

      testDecisionTableRow(0, [
        "1",
        "abc",
        ["85"],
        "123456789",
        "42.75",
        { type: "checkbox", isChecked: true },
        "12/15/2024",
        "12/15/2024 07:12",
        ["abc", "def"],
        ["1", "2", "3"],
        ["12/15/2024", "08/04/2025"],
      ]);
    });
  });
});
