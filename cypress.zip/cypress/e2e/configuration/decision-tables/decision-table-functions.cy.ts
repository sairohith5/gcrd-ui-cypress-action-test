import { getRelativeDate } from "../../../utils/date-utils";
import {
  openDialog,
  submitDialog,
  testDialog,
  testDialogIsNotDisplayed,
} from "../../../utils/dialog-utils";
import { testFilter, testRow, testTable } from "../../../utils/grid-utils";
import {
  testRevisionCompareDialog,
  testRevisionHistoryDialogFromGrid,
  testRollback,
} from "../../../utils/revision-history-utils";
import {
  testToast,
  ToastMessage,
  ToastTitle,
} from "../../../utils/toast-utils";

describe("table functions tab", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
    cy.wait(1000);
    cy.clickTabByIndex(1, "decisionTableTabs");
  });

  it("should display the table functions grid", () => {
    testTable(
      [
        { type: "button", ariaLabel: "Lock Status" },
        "Name",
        "Tags",
        "Last Committed",
        "Actions",
      ],
      [
        "",
        "defaultRule",
        { type: "tags", tags: ["BusinessLibrary", "GCRE-123", "GCRE-456"] },
        getRelativeDate("2024-05-03 13:13:33 -0400"),
        [
          {
            type: "button",
            value: "view revision history for defaultRule",
          },
        ],
      ],
    );

    testRow(1, [
      "",
      "tableFunction2",
      { type: "tags", tags: ["BusinessLibrary"] },
      getRelativeDate("2022-05-03 11:28:33 -0400"),
      "",
    ]);

    testFilter("tableFunction3", [
      "",
      "tableFunction3",
      "",
      getRelativeDate("2023-12-03 07:18:33 -0400"),
      "",
    ]);
  });

  // TODO: removing ability to add table functions for Phase 1
  it.skip("should navigate to add a table function", () => {
    cy.getByTestId("addRuleBtn").click();
    cy.url().should(
      "include",
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance/function/_new",
    );
  });

  // TODO: removing ability to delete table functions for Phase 1
  it.skip("should delete a table function", () => {
    // eslint-disable-next-line cypress/no-assigning-return-values
    const triggerBtn = cy.getGridRowButtonOrLink(0, 4);
    testDialog(triggerBtn.first(), "Delete Confirmation");
    openDialog(triggerBtn);
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("not.be.disabled")
      .contains("Confirm");
    submitDialog();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_DELETE);
  });

  it("displays revision history", () => {
    testRevisionHistoryDialogFromGrid(0, "defaultRule", [
      { type: "checkbox", isChecked: false },
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
      { type: "email", value: "mdickson1@gmail.com" },
      "test",
      {
        type: "button",
        value: "You must check out the item to rollback",
        isDisabled: true,
      },
    ]);
    testRevisionCompareDialog(
      0,
      1,
      2,
      "defaultRule (Decision Table Function)",
      "429e207",
      getRelativeDate("2024-11-13 09:48:12 -0500"),
      "2a8ca79",
      getRelativeDate("2024-11-13 09:49:17 -0500"),
    );
    testRollback(0, 1, false);
  });
});
