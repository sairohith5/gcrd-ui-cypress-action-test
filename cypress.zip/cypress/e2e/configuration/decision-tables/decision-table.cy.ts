import {
  getDecisionTableHeader,
  clickColumnContextMenuOption,
  clickRowContextMenuOption,
  testColumnContextMenu,
  testDecisionTable,
  testDecisionTableRow,
  testRowContextMenu,
  testDecisionTableHeader,
  clickTableCellButton,
  getTableCell,
  getTableCellButton,
  testDecisionTableCellFormField,
  clickArrayCellButton,
  NULL_DISPLAY,
  EMPTY_STRING_DISPLAY,
  filterDecisionTable,
  insertRowBelow,
  clearDecisionTableFilter,
  deleteRow,
  insertColumnRight,
  deleteColumn,
  testNumRowsInDecisionTable,
  testCellConditionTooltip,
  testColumnHasDefaultConditions,
  verifyDecisionTableIsReadonly,
} from "../../../utils/decision-table-utils";
import {
  selectFormField,
  testDescriptionEditForm,
  testFormField,
  testFormFieldValidation,
  testFormFieldValue,
  typeFormField,
} from "../../../utils/form-utils";
import { testTabs } from "../../../utils/tab-utils";
import {
  ToastMessage,
  ToastTitle,
  testToast,
} from "../../../utils/toast-utils";
import { getLocalDateTime } from "../../../utils/date-utils";
import "cypress-file-upload";
import { clickAnywhere, deleteArtifact } from "../../../utils/utils";
import { skipOn } from "@cypress/skip-test";
import { testPagination } from "../../../utils/grid-utils";
import {
  testAssociatedRecordNavigation,
  testAssociatedRecordsGrid,
  testAssociatedRecordsGridRow,
  testAssociatedRecordsSheet,
} from "../../../utils/associated-records-utils";
import {
  cancelDialog,
  submitDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";

describe("decision table tab", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter(
      "DT_MasterTableForHierarchyRootPathInstance",
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus rutrum elit vulputate interdum suscipit.",
    );
    cy.testBrowserTitle("[DT_MasterTableForHierarchyRootPathInstance] Table");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home", "Decision Tables"]);
    cy.testSidebar("Designer", "Decision Tables");
    cy.getByTestId("tags-container").should("exist");
  });

  it("maximizes and restores content", () => {
    cy.testMaximizeToggleButton();

    cy.getByTestId("maximizeToggleBtn").click();
    cy.getByTestId("saveBtn").should("exist");
    cy.getByTestId("maximizeToggleBtn").click();
    cy.getByTestId("cancelBtn").should("exist");
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("exportFileBtn").should("exist");
  });

  it("cancels decision table edits and navigates back to decision tables screen", () => {
    cy.getByTestId("cancelBtn")
      .should("exist")
      .should("not.be.disabled")
      .contains("Cancel");
    cy.getByTestId("cancelBtn").click();
    cy.url().should("include", "/rule-designer/designer/decision-tables");
  });

  it("displays tabs", () => {
    testTabs(
      "decisionTableTabs",
      ["Decision Table", "Table Functions"],
      "Decision Table",
      ["decisionTableTabPanel", "tableFunctionsTabPanel"],
    );
  });

  it("edits description", () => {
    testDescriptionEditForm();
  });

  it("exports decision table", () => {
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("exportFileBtn")
      .should("exist")
      .should("not.be.disabled")
      .contains("Export");

    // TODO: is there anything we can actually test here (i.e., is it even possible to test if the export was valid)?
  });

  it("should display associated items", () => {
    testAssociatedRecordsSheet("DT_MasterTableForHierarchyRootPathInstance");
    testAssociatedRecordsGrid(["Rule", "Apex_582 (Batch_Activity_RS)"]);
    testAssociatedRecordsGridRow(1, ["Rule", "Apex_583 (Batch_Activity_RS)"]);
    testAssociatedRecordsGridRow(2, ["Rule Set", "Batch_Activity_RS"]);
    testAssociatedRecordsGridRow(3, [
      "Decision Table",
      "DT_MessagePriorityInstance",
    ]);
    testAssociatedRecordsGridRow(4, ["Main Flow", "Main Flow"]);
    testAssociatedRecordsGridRow(5, [
      "Table Function",
      "defaultRule (DT_MasterTableForHierarchyRootPathInstance)",
    ]);
    testAssociatedRecordsGridRow(6, ["Function", "entryPointFn"]);
  });

  it("should navigate to an associated rule", () => {
    testAssociatedRecordNavigation(1, "Rule");
  });

  it("should navigate to an associated rule set", () => {
    testAssociatedRecordNavigation(2, "Rule Set");
  });

  it("should navigate to an associated decision table", () => {
    testAssociatedRecordNavigation(3, "Decision Table");
  });

  it("should navigate to an associated main flow", () => {
    testAssociatedRecordNavigation(4, "Main Flow");
  });

  it("should navigate to an associated function", () => {
    testAssociatedRecordNavigation(6, "Function");
  });

  it("should navigate to an associated table function", () => {
    testAssociatedRecordNavigation(5, "Table Function");
  });

  it("displays the compile errors button", () => {
    cy.getByTestId("bottom-drawer").should("not.exist");

    // Check if the compile errors button exists and is visible
    cy.getByTestId("compile-errors-btn")
      .should("exist")
      .should("be.visible")
      .click();

    // Verify that the compile results element is displayed
    cy.getByTestId("bottom-drawer").should("exist");
    cy.getByTestId("bottom-drawer-title").contains("Compile Results");
    cy.getByTestId("bottom-drawer-refresh-btn").should("not.exist");
    cy.getByTestId("bottom-drawer-content")
      .should("exist")
      .should(
        "contain",
        "Showing results for DT_MasterTableForHierarchyRootPathInstance",
      )
      .should(
        "contain",
        "DT_MasterTableForHierarchyRootPathInstance.defaultRule: for used as if statement at node 98",
      );

    // click the show all results button and verify the refresh button is displayed
    cy.getByTestId("showAllResults").should("exist").click();
    cy.getByTestId("bottom-drawer-refresh-btn").should("exist");
  });

  it("should test if the view code link is present in the more actions menu", () => {
    cy.getByTestId("nav-menu-more").should("exist").click({ force: true });
    cy.getByTestId("viewCodeLink").should("not.exist");
  });
});

describe("displaying decision table", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });

  it("should display the decision table", () => {
    cy.wait(500);
    testDecisionTable(
      [
        "Row",
        "Description",
        "String",
        "Integer",
        "Long",
        "Double",
        "Boolean",
        "Date",
        "Date + Time",
        "Integer Array",
        "String Array",
      ],
      [
        "1",
        "Sunny Day 1",
        "abc",
        "21",
        "9223372036854",
        "42.5",
        { type: "checkbox", isChecked: true },
        "04/01/2024",
        getLocalDateTime(1734264720000),
        "8",
        "string1",
      ],
    );

    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      { type: "checkbox", isChecked: false },
      "12/15/2024",
      "12/15/2024",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);

    testDecisionTableRow(2, [
      "3",
      "Nulls",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);

    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      EMPTY_STRING_DISPLAY,
      "0",
      "0",
      "0",
      { type: "checkbox", isChecked: false },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should display condition and action columns", () => {
    getDecisionTableHeader(2)
      .find("span.sr-only")
      .should("have.text", "condition column type");

    getDecisionTableHeader(10)
      .find("span.sr-only")
      .should("have.text", "action column type");
  });
});

describe("column context menu", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });

  it("should display the column context menu", () => {
    testColumnContextMenu(0, [
      "Insert column right",
      "Insert row below",
      "Apply Default Conditions",
    ]);
    testColumnContextMenu(1, [
      "Edit column",
      "Insert column right",
      "Delete column",
    ]);
  });

  it("should edit a column", () => {
    clickColumnContextMenuOption(2, 0);
    cy.wait(1000);
    cy.getByTestId("dialog-title").contains("Edit Column");
    testFormField("varNameField", "Column ID", true, {
      expectDisabled: false,
      defaultValue: "string2",
    });
    testFormField("displayNameField", "Column Display Name", true, {
      expectDisabled: false,
      defaultValue: "String",
    });
    testFormField("typeField", "Type", true, {
      expectDisabled: false,
      defaultValue: "String",
    });
    testFormField("isArrayField", "Is Array?", false, {
      isCheckbox: false,
      expectDisabled: false,
    });
    testFormField("dispositionField", "Column Type", false, {
      isRadioButton: true,
      expectedRadioButtonOptions: ["Condition", "Action"],
      expectedRadioButtonSelected: "Condition",
    });
    testFormField("descriptionField", "Description", false, {
      expectDisabled: false,
      defaultValue: "String field",
    });

    testDecisionTableHeader([
      "Row",
      "Description",
      "String",
      "Integer",
      "Long",
      "Double",
      "Boolean",
      "Date",
      "Date + Time",
      "Integer Array",
      "String Array",
    ]);
  });

  it("should insert a column to the right", () => {
    clickColumnContextMenuOption(1, 1);
    cy.getByTestId("dialog-title").contains("Add Column");
    cy.getByTestId("dialog-cancel-button")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled");
    testFormField("varNameField", "Column ID", true, { expectDisabled: false });
    testFormField("displayNameField", "Column Display Name", true, {
      expectDisabled: false,
    });
    const expectedSelectOptions = [
      "Select one",
      "Boolean",
      "Date",
      "Datetime",
      "Double",
      "Integer",
      "Long",
      "String",
    ];
    testFormField("typeField", "Type", true, {
      expectedSelectOptions: expectedSelectOptions,
      numSelectOptionsToTest: 8,
    });
    testFormField("isArrayField", "Is Array", false, { isCheckbox: true });
    testFormField("descriptionField", "Description", false, {
      expectDisabled: false,
    });
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled");
    cy.getByTestId("varNameInput").type("test_col");
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("not.be.disabled");
    cy.getByTestId("dialog-submit-button").should("exist").click();
    testFormFieldValidation("displayNameField", "Enter required field");
    cy.getByTestId("displayNameInput").type("test_display");
    cy.getByTestId("dialog-submit-button").should("exist").click();
    testDecisionTableHeader([
      "Row",
      "Description",
      "test_display",
      "String",
      "Integer",
      "Long",
      "Double",
      "Boolean",
      "Date",
      "Date + Time",
      "Integer Array",
      "String Array",
    ]);
  });

  it("should list date formats in the date format dropdown", () => {
    clickColumnContextMenuOption(7, 0);
    cy.getByTestId("dialog-title").contains("Edit Column");

    testFormField("formatField", "Date Format", false, {
      expectedSelectOptions: [
        "Select one",
        "DD/MM/YYYY (e.g., 15/12/2024)",
        "dddd, MMMM Do YYYY (e.g., Sunday, December 15th 2024)",
        "MM/DD/YYYY (e.g., 12/15/2024)",
      ],
    });
  });

  it("should list datetime formats in the date format dropdown", () => {
    clickColumnContextMenuOption(8, 0);
    cy.getByTestId("dialog-title").contains("Edit Column");

    testFormField("formatField", "Datetime Format", false, {
      expectedSelectOptions: [
        "Select one",
        "DD/MM/YYYY HH:mm (e.g., 15/12/2024 07:12)",
        "dddd, MMMM Do YYYY, h:mm a (e.g., Sunday, December 15th 2024, 7:00 am)",
        "MM/DD/YYYY HH:mm (e.g., 12/15/2024 07:12)",
        "YYYY-MM-DDTHH:mmZ (e.g., 2024-12-15T07:00-05:00)",
      ],
    });
  });

  it("should not allow inserting a duplicate column ID", () => {
    clickColumnContextMenuOption(1, 1);
    cy.getByTestId("dialog-title").contains("Add Column");

    // enter a duplicate column ID
    cy.getByTestId("varNameInput").type("string2");
    cy.getByTestId("displayNameInput").type("test_display");
    cy.getByTestId("dialog-submit-button").should("exist").click();

    testIsDialogDisplayed();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_DT_COLUMN_NAME_EXISTS, true);

    // change the column ID to a unique value
    cy.getByTestId("varNameInput").clear();
    cy.getByTestId("varNameInput").type("test_col");
    cy.getByTestId("dialog-submit-button").should("exist").click();

    testDialogIsNotDisplayed();
  });

  it("should allow editing a column without changing the column ID", () => {
    clickColumnContextMenuOption(1, 0);
    cy.getByTestId("dialog-title").contains("Edit Column");

    // change description and try to save (should not get flagged as duplicate column id)
    cy.getByTestId("descriptionInput").clear();
    cy.getByTestId("descriptionInput").type("test_description");
    cy.getByTestId("dialog-submit-button").should("exist").click();
    testDialogIsNotDisplayed();
  });

  it("should delete a column", () => {
    clickColumnContextMenuOption(2, 2);
    testDecisionTableHeader([
      "Row",
      "Description",
      "String",
      "Integer",
      "Long",
      "Double",
      "Boolean",
      "Date",
      "Date + Time",
      "Integer Array",
      "String Array",
    ]);
  });
});

describe("row context menu", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });

  it("should display the row context menu", () => {
    testRowContextMenu(0, [
      "Insert row below",
      "Move row down",
      "Copy row",
      "Duplicate row",
      "Delete row",
    ]);
    testRowContextMenu(1, [
      "Insert row below",
      "Move row up",
      "Move row down",
      "Copy row",
      "Duplicate row",
      "Delete row",
    ]);
  });

  it("should insert a row below", () => {
    clickRowContextMenuOption(2, 0);
    testDecisionTableRow(3, [
      "4",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
    clickColumnContextMenuOption(0, 1);
    testDecisionTableRow(3, [
      "4",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should delete a row", () => {
    clickRowContextMenuOption(2, 5);
    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
  });
});

describe("edit decision table", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });
  it("should display the edit button", () => {
    getTableCellButton(0, 0, "Edit").should("exist");
  });

  it("should put the cell in edit mode", () => {
    getTableCellButton(0, 0, "Apply").should("not.exist");
    getTableCellButton(0, 0, "Cancel").should("not.exist");
    clickTableCellButton(0, 0, "Edit");
    getTableCellButton(0, 0, "Apply").should("exist").should("be.visible");
    getTableCellButton(0, 0, "Cancel").should("exist").should("be.visible");
  });

  it("should cancel editing a cell", () => {
    clickTableCellButton(0, 0);
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("abc");
    clickTableCellButton(0, 0, "Cancel");
    cy.getByTestId("decisionTableCell-0-1").should("have.text", "Sunny Day 1");
    getTableCellButton(0, 0, "Apply").should("not.exist");
    getTableCellButton(0, 0, "Cancel").should("not.exist");
    cy.getByTestId("tableCell").should("not.exist");
  });

  it("should edit a string cell", () => {
    cy.getByTestId("decisionTableCell-0-1").should("have.text", "Sunny Day 1");
    clickTableCellButton(0, 0);
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("Sunny Day 1");
    cy.getByTestId("tableCell").should("exist");
    clickTableCellButton(0, 0, "Apply");
    cy.getByTestId("decisionTableCell-0-1").should("have.text", "Sunny Day 1");
    cy.getByTestId("tableCell").should("not.exist");
  });

  it("should edit an integer cell", () => {
    getTableCell(0, 2).should("have.text", "21");
    clickTableCellButton(0, 2, "Edit");
    cy.getByTestId("numCell").clear();
    cy.getByTestId("numCell").type("21asdf");
    clickTableCellButton(0, 2, "Apply");
    getTableCell(0, 2).should("have.text", "21");
  });

  it("should edit a long cell", () => {
    getTableCell(0, 3).should("have.text", "9223372036854");
    clickTableCellButton(0, 3);
    cy.getByTestId("numCell").clear();
    cy.getByTestId("numCell").type("9223372036854.efsfgf");
    clickTableCellButton(0, 3, "Apply");
    getTableCell(0, 3).should("have.text", "9223372036854");
  });

  it("should edit a double cell", () => {
    getTableCell(0, 4).should("have.text", "42.5");
    clickTableCellButton(0, 4);
    cy.getByTestId("numCell").clear();
    cy.getByTestId("numCell").type("42.5efsfgf");
    clickTableCellButton(0, 4, "Apply");
    getTableCell(0, 4).should("have.text", "42.5");
  });

  it("should edit a date cell", () => {
    getTableCell(0, 6).should("have.text", "04/01/2024");
    clickTableCellButton(0, 6);
    cy.get("[data-testid='dateCellBox'] input").as("dateCell");
    cy.get("@dateCell").type("01-02-2023", { force: true });
    clickTableCellButton(0, 6, "Apply");
    getTableCell(0, 6).should("have.text", "01/02/2023");
    getTableCellButton(0, 6, "Apply").should("not.exist");
    getTableCellButton(0, 6, "Cancel").should("not.exist");
  });

  it("should edit a datetime cell", () => {
    getTableCell(0, 7).should("have.text", getLocalDateTime(1734264720000));
    clickTableCellButton(0, 7);
    cy.get("[data-testid='datetimeCellBox'] input").as("datetimeCell");
    cy.get("@datetimeCell").type("12-15-2023 07:53 AM", { force: true });
    clickTableCellButton(0, 7, "Apply");

    // TODO: when clicking Save, the newly-typed value is not saved (this is a Cypress problem, not an application bug):
    // getTableCell(0, 7).should(
    //   "have.text",
    //   "12/15/2023 07:53",
    // );
    getTableCellButton(0, 7, "Apply").should("not.exist");
    getTableCellButton(0, 7, "Cancel").should("not.exist");
  });

  it("should add an array cell", () => {
    clickArrayCellButton(1, 9, "Edit", 0);
    cy.getByTestId("add-column-menu-item").click();
    cy.wait(500);
    cy.getByTestId("tableCell").type("abc");
    clickArrayCellButton(1, 9, "Apply", 1);
    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024", // leaving the time off here so we don't fail due to time zone issues
      ["899", "5", "14"],
      ["string1", "abc", "string2", "string3"],
    ]);
  });
  it("should edit an array cell", () => {
    clickArrayCellButton(1, 9, "Edit", 0);
    cy.getByTestId("edit-column-menu-item").click();
    cy.wait(100);
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("abc");
    clickArrayCellButton(1, 9, "Apply", 0);
    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024", // leaving the time off here so we don't fail due to time zone issues
      ["899", "5", "14"],
      ["abc", "string2", "string3"],
    ]);
  });
  it("should delete an array cell", () => {
    clickArrayCellButton(1, 9, "Edit", 0);
    cy.getByTestId("user-tasks-menu-item").click();
    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024", // leaving the time off here so we don't fail due to time zone issues
      ["899", "5", "14"],
      ["string2", "string3"],
    ]);
  });

  it("should not add a cell when a new cell is cancelled", () => {
    clickArrayCellButton(1, 9, "Edit", 1);
    cy.getByTestId("add-column-menu-item").click();
    cy.wait(100);
    cy.getByTestId("tableCell").type("abc");
    clickArrayCellButton(1, 9, "Cancel", 2);
    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024", // leaving the time off here so we don't fail due to time zone issues
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
  });

  it("should display the array cell context menu", () => {
    clickArrayCellButton(1, 9, "Edit", 0);
    cy.getByTestId("arrayCellContextMenu").should("exist");
    cy.getByTestId("arrayCellContextMenu")
      .find("div[role='menuitem']")
      .then((items) => {
        expect(items.length).to.equal(3);
        expect(items[0].innerText).to.contain("Edit");
        expect(items[1].innerText).to.contain("Insert below");
        expect(items[2].innerText).to.contain("Delete");
      });
    clickAnywhere();
    cy.wait(100); // give time for the context menu to close
    clickArrayCellButton(3, 9, "Edit", 0);
    cy.getByTestId("arrayCellContextMenu").should("exist");
    cy.getByTestId("arrayCellContextMenu")
      .find("div[role='menuitem']")
      .then((items) => {
        expect(items.length).to.equal(1);
        expect(items[0].innerText).to.contain("Insert");
      });
  });

  it("validate numeric fields", () => {
    clickTableCellButton(0, 2, "Edit");
    cy.getByTestId("numCell").clear();
    cy.getByTestId("numCell").type("9223372036854775808");
    clickTableCellButton(0, 2, "Apply");
    testToast(ToastTitle.ERROR, ToastMessage.MAXIMUM_VALUE_EXCEEDED);
    getTableCell(0, 2).should("have.text", Number.MAX_SAFE_INTEGER);
    clickTableCellButton(1, 2, "Edit");
    cy.getByTestId("numCell").clear();
    cy.getByTestId("numCell").type("-9223372036854775809");
    clickTableCellButton(1, 2, "Apply");
    testToast(ToastTitle.ERROR, ToastMessage.MINIMUM_VALUE_EXCEEDED);
  });

  it("imports a file into decision table", () => {
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("importFileBtn").click();

    const fileName = "import_test_file.xlsx";
    const fileType =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    cy.fixture(fileName, "binary")
      .then(Cypress.Blob.binaryStringToBlob)
      .then((blob) => {
        cy.get('input[type="file"]').attachFile({
          fileContent: blob,
          fileName,
          mimeType: fileType,
        });
      });
    cy.wait(500);
    testDecisionTable(
      [
        "Row",
        "Description",
        "String",
        "Integer",
        "Long",
        "Double",
        "Boolean",
        "Date",
        "Date + Time",
        "Integer Array",
        "String Array",
      ],
      [
        "1",
        "Sunny Day New",
        "abc New",
        "21",
        "9223372036854",
        "42.5",
        "",
        "04/01/2024",
        "12/15/2024 06:12",
        "8",
        "string1",
      ],
    );

    testDecisionTableRow(1, [
      "2",
      "Sunny Day New 1",
      "xyz New",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
    testToast(ToastTitle.SUCCESS, ToastMessage.IMPORT_FILE_SUCCESS);
  });

  it("import a file into decision table with null and empty values", () => {
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("importFileBtn").click();
    const fileName = "import_null_test_file.xlsx";
    const fileType =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    cy.fixture(fileName, "binary")
      .then(Cypress.Blob.binaryStringToBlob)
      .then((blob) => {
        cy.get('input[type="file"]').attachFile({
          fileContent: blob,
          fileName,
          mimeType: fileType,
        });
      });
    cy.wait(500);
    testDecisionTableRow(4, [
      "5",
      "NewRow",
      EMPTY_STRING_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      "23",
      { type: "checkbox", isChecked: true },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      [EMPTY_STRING_DISPLAY],
    ]);
    testToast(ToastTitle.SUCCESS, ToastMessage.IMPORT_FILE_SUCCESS);
  });

  it("should not import a file into decision table when there are pending changes", () => {
    clickTableCellButton(1, 1, "Edit");
    cy.getByTestId("tableCell").type("test");
    clickTableCellButton(1, 1, "Apply");
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("importFileBtn").click();
    cy.getByTestId("dialog-title").contains("Unsaved Changes");
  });

  //TODO: Identify the root cause in cypress why the dialog box is getting closed automatically after typing the message
  it.skip("should allow user to edit a column when it is not being referenced elsewhere", () => {
    cy.visit("/rule-designer/designer/decision-tables/temptable");
    testColumnContextMenu(1, [
      "Edit column",
      "Insert column right",
      "Delete column",
    ]);
    clickColumnContextMenuOption(1, 0);
    cy.getByTestId("dialog-title").contains("Edit Column");
    cy.getByTestId("dialog-submit-button").should("not.be.enabled");
    cy.getByTestId("varNameInput")
      .should("have.value", "aPathName")
      .should("not.be.disabled");
    cy.getByTestId("varNameInput").should("exist").type("newPathName");
    cy.getByTestId("dialog-submit-button").should("be.enabled");
    typeFormField("varNameInput", "aPathName");
    cy.getByTestId("dialog-submit-button").should("not.be.enabled");
    selectFormField("typeInput", "Long");
    cy.getByTestId("dialog-submit-button").should("be.enabled");
  });

  it("should not allow user to edit a column when it is being referenced elsewhere", () => {
    cy.visit("/rule-designer/designer/decision-tables/temptable");
    cy.wait(1000);
    testColumnContextMenu(3, ["Edit column", "Insert column right"]);
    clickColumnContextMenuOption(3, 0);
    cy.getByTestId("dialog-title").contains("Edit Column");
    cy.getByTestId("varNameInput")
      .should("have.value", "Result")
      .should("be.disabled");
  });

  it("should delete a decision table from the decision table screen", () => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
    cy.wait(500);
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("deleteArtifactBtn").click();
    deleteArtifact();
    cy.url().should("include", "/rule-designer/designer/decision-tables");
  });
});

describe("readonly decision table", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_RealTimeRulesConfiguration",
    );
  });

  it("should be readonly when not checked out", () => {
    cy.getByTestId("lock-button").should("not.exist");
    verifyDecisionTableIsReadonly();
  });
});

describe("column info icon tooltip", () => {
  it("should display the column info icon button and tooltip", () => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");

    // info icon should be displayed for the second column
    getDecisionTableHeader(1)
      .find(`[data-testid='column-header-info-icon']`)
      .should("exist");

    cy.wait(500);

    // info icon should not be displayed for the first "Row" column
    getDecisionTableHeader(0)
      .find(`[data-testid='column-header-info-icon']`)
      .should("not.exist");

    cy.wait(500);

    // test for the first column
    getDecisionTableHeader(1)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon");

    cy.get("@infoIcon").should("not.be.visible").focus();

    cy.getByTestId("column-header-tooltip").should("exist");

    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-badge']")
      .as("columnheaderBadge");
    cy.get("@columnheaderBadge").should("exist");
    cy.get("@columnheaderBadge").contains("Condition");

    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-id']")
      .as("columnheaderId");
    cy.get("@columnheaderId")
      .should("exist")
      .should("include.text", "Column ID")
      .should("include.text", "string1");

    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-datatype']")
      .as("columnheaderDataType");
    cy.get("@columnheaderDataType")
      .should("exist")
      .should("include.text", "Data Type")
      .should("include.text", "String");

    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-description']")
      .as("columnheaderDescription");
    cy.get("@columnheaderDescription")
      .should("exist")
      .should("include.text", "Description")
      .should("include.text", "what is this row testing?");

    // test an Action column
    getDecisionTableHeader(10)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon");

    cy.get("@infoIcon").should("not.be.visible").focus();

    cy.getByTestId("column-header-tooltip").should("exist");
    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-badge']")
      .as("columnheadertooltip");
    cy.get("@columnheadertooltip").should("exist");
    cy.get("@columnheadertooltip").contains("Action");

    cy.wait(500);

    // test an array column
    getDecisionTableHeader(9)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon");

    cy.get("@infoIcon").should("not.be.visible").focus();
    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-datatype']")
      .as("columnheadertooltipdatatype");
    cy.get("@columnheadertooltipdatatype").should("exist");
    cy.get("@columnheadertooltipdatatype").contains("int Array");

    cy.wait(500);

    // test a column with no description
    getDecisionTableHeader(10)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon");
    cy.get("@infoIcon").should("not.be.visible").focus();
    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-description']")
      .should("not.exist");
  });

  it("should display the column info icon button for a readonly decision table", () => {
    cy.visit(
      "rule-designer/designer/decision-tables/DT_MessagePriorityInstance",
    );

    getDecisionTableHeader(1)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon")
      .should("exist");
  });
});

describe("saving decision table", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
  });

  it("should enable the save button when a cell is edited", () => {
    // test for save button initially disabled
    cy.getByTestId("saveBtn").should("be.disabled");

    // test for enabling save button
    clickTableCellButton(0, 0, "Edit");
    cy.getByTestId("tableCell").type("test");
    clickTableCellButton(0, 0, "Apply");
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
  });

  it("should enable the save button when a checkbox cell is toggled", () => {
    // test for save button initially disabled
    cy.getByTestId("saveBtn").should("be.disabled");

    // test for enabling save button
    clickTableCellButton(0, 4);
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
  });

  it("should enable the save button when a column is added", () => {
    // test for save button initially disabled
    cy.getByTestId("saveBtn").should("be.disabled");

    // test for enabling save button
    clickTableCellButton(0, 0, "Edit");
    cy.getByTestId("tableCell").type("test");
    clickTableCellButton(0, 0, "Apply");
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
  });

  it("should enable the save button when a column is deleted", () => {
    // test for save button initially disabled
    cy.getByTestId("saveBtn").should("be.disabled");

    // test for enabling save button
    clickColumnContextMenuOption(2, 2); // delete column
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
  });

  // *** TODO: skipping this until we get the column definition edit working
  it.skip("should enable the save button when a column definition is edited", () => {
    // test for save button initially disabled
    cy.getByTestId("saveBtn").should("be.disabled");

    // test for enabling save button
    clickColumnContextMenuOption(2, 0); // edit column
    cy.getByTestId("displayNameInput").type("test");
    cy.getByTestId("dialog-submit-button").click();
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
  });

  it("should enable the save button when a row is added", () => {
    // test for save button initially disabled
    cy.getByTestId("saveBtn").should("be.disabled");

    // test for enabling save button
    clickRowContextMenuOption(1, 0); // insert row below
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
  });

  it("should enable the save button when a row is deleted", () => {
    // test for save button initially disabled
    cy.getByTestId("saveBtn").should("be.disabled");

    // test for enabling save button
    clickRowContextMenuOption(1, 1); // delete row
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
  });

  it("should save the decision table", () => {
    clickTableCellButton(0, 4);
    cy.getByTestId("saveBtn").should("be.enabled").click();

    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);

    // test for save button disabled after saving
    cy.getByTestId("saveBtn").should("be.disabled");
  });

  it("should open the dialog when unlock button is clicked with unsaved changes", () => {
    clickTableCellButton(1, 1);
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("test");
    cy.getByTestId("tableCell").should("exist");
    clickTableCellButton(1, 1, "Apply");
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
    cy.getByTestId("lock-button").click();
    cy.getByTestId("dialog-container").should("exist");
    cy.getByTestId("dialog-title").contains("Unsaved Changes");
  });
});

describe("dropdowns", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestDropdowns_DT");
  });

  it("should display dropdown details in the column info tooltip", () => {
    // test tooltip for a single dropdown column
    getDecisionTableHeader(1)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon");

    cy.get("@infoIcon").should("not.be.visible").focus();
    cy.wait(200);
    cy.getByTestId("column-header-tooltip").should("exist");
    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-datatype']")
      .should("exist")
      .should("include.text", "Data Type")
      .should("include.text", "String Dropdown");

    cy.wait(500);

    // test tooltip for an array dropdown column
    getDecisionTableHeader(2)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon");

    cy.get("@infoIcon").should("not.be.visible").focus();
    cy.wait(200);
    cy.getByTestId("column-header-tooltip").should("exist");
    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-datatype']")
      .should("exist")
      .should("include.text", "Data Type")
      .should("include.text", "String Dropdown Array");
  });

  it("should display a dropdown in a cell and allow editing", () => {
    cy.wait(500);
    // displays the string value
    testDecisionTableRow(0, ["1", "item", ["item1", "item2"]]);
    testDecisionTableRow(1, ["2", "item with spaces", "item1"]);
    testDecisionTableRow(3, ["4", "itemNotInDomain", ""]);

    // verify dropdown cell is not in edit mode
    getTableCellButton(0, 0, "Edit").should("exist");
    getTableCellButton(0, 0, "Apply").should("not.exist");
    getTableCellButton(0, 0, "Cancel").should("not.exist");

    // click the edit button
    clickTableCellButton(0, 0, "Edit");

    // verify the dropdown cell is in edit mode
    getTableCellButton(0, 0, "Apply").should("exist").should("be.visible");
    getTableCellButton(0, 0, "Cancel").should("exist").should("be.visible");

    // verify the drodown
    testDecisionTableCellFormField("tableCellDropdown", "Dropdown", {
      defaultValue: "item",
      expectedSelectOptions: [
        "Select one",
        "extraItem",
        "item",
        "item with spaces",
        "itemWithSignificantAmountOfText",
      ],
    });

    // select a different value
    selectFormField("tableCellDropdown", "item with spaces");

    // cancel the value and verify it does not change
    clickTableCellButton(0, 0, "Cancel");
    testDecisionTableRow(0, ["1", "item", ["item1", "item2"]]);

    // edit the value and verify it changes
    clickTableCellButton(0, 0, "Edit");
    testDecisionTableCellFormField("tableCellDropdown", "Dropdown", {
      defaultValue: "item",
      expectedSelectOptions: [
        "Select one",
        "extraItem",
        "item",
        "item with spaces",
        "itemWithSignificantAmountOfText",
      ],
    });
    selectFormField("tableCellDropdown", "item with spaces");
    clickTableCellButton(0, 0, "Apply");
    testDecisionTableRow(0, ["1", "item with spaces", ["item1", "item2"]]);
  });

  it("should cancel editing a dropdown array cell", () => {
    cy.wait(500);
    testDecisionTableRow(0, ["1", "item", ["item1", "item2"]]);

    clickArrayCellButton(0, 1, "Menu", 0);
    cy.getByTestId("add-column-menu-item").click();
    getTableCellButton(0, 1, "Cancel").should("exist").click();

    testDecisionTableRow(0, ["1", "item", ["item1", "item2"]]);
    getTableCell(0, 1).should("not.contain", "€");
  });
});

describe("columns mismatch", () => {
  it("should gracefully handle columns mismatch", () => {
    cy.visit("/rule-designer/designer/decision-tables/DT_ColumnsMismatch");

    testToast(ToastTitle.ERROR, ToastMessage.ERROR_DT_COLUMNS_MISMATCH);
    testDecisionTable(["Row", "Column 1"], ["1", "value1", "rmr0"]);

    // test that the table is readonly
    getDecisionTableHeader(1)
      .find("button[data-testid='cell-menu'][aria-label='cell options']")
      .should("exist")
      .should("not.be.visible");

    cy.getByTestId(`rowHeader${1}`).as("rowHeader");
    cy.getByTestId("row-context-menu").should("not.exist");
    getTableCellButton(0, 0, "Edit").should("not.exist");
  });
});

describe("null and empty values", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });

  it("should display null and empty values when table is initially loaded", () => {
    cy.wait(500);
    testDecisionTableRow(2, ["3", "Nulls", "", "", "", "", "", "", "", "", ""]);
    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      EMPTY_STRING_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should edit cells to be null", () => {
    cy.wait(500);
    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      EMPTY_STRING_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);

    // null out a string cell
    clickTableCellButton(3, 1, "Edit");
    cy.getByTestId("tableCell").type("gibberish");
    clickTableCellButton(3, 1, "Delete");
    // check to make sure the cell is empty after deleting the value
    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      NULL_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);

    // check that cancel doesn’t treat null as a string
    clickTableCellButton(3, 1, "Edit");
    clickTableCellButton(3, 1, "Cancel");
    clickTableCellButton(3, 1, "Edit");
    getTableCell(3, 1).find("input").should("have.value", "");
    clickTableCellButton(3, 1, "Cancel");

    // check to make sure the delete button is not displayed
    clickTableCellButton(3, 1, "Edit");
    getTableCellButton(3, 1, "Delete").should("not.exist");
    clickTableCellButton(3, 1, "Cancel");

    // null out a numeric cell (but first, set it something other than null)
    clickTableCellButton(3, 2, "Edit");
    getTableCell(3, 2).find("input").should("have.value", "0");
    clickTableCellButton(3, 2, "Delete");
    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      NULL_DISPLAY,
      NULL_DISPLAY,
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
    clickTableCellButton(3, 2, "Edit");
    getTableCell(3, 2).find("input").should("have.value", "");

    // null out a date cell
    clickTableCellButton(0, 7, "Edit");
    clickTableCellButton(0, 7, "Delete");
    testDecisionTableRow(0, [
      "1",
      "Sunny Day 1",
      "abc",
      "21",
      "9223372036854",
      "42.5",
      { type: "checkbox", isChecked: true },
      "04/01/2024",
      NULL_DISPLAY,
      "8",
      "string1",
    ]);
  });

  it("should edit a cell to be an empty string", () => {
    clickTableCellButton(2, 1, "Edit");
    cy.getByTestId("tableCell").clear();
    typeFormField("tableCell", " ");
    clickTableCellButton(2, 1, "Apply");

    // check to make sure the cell shows an empty string after entering a space
    testDecisionTableRow(2, [
      "3",
      "Nulls",
      EMPTY_STRING_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should continue to display an empty string after canceling an edit", () => {
    cy.wait(500);
    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      EMPTY_STRING_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);

    clickTableCellButton(3, 1, "Edit");
    clickTableCellButton(3, 1, "Cancel");

    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      EMPTY_STRING_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should type NULL in a cell and save it as null", () => {
    clickTableCellButton(3, 1, "Edit");
    cy.getByTestId("tableCell").type("NULL");
    clickTableCellButton(3, 1, "Apply");

    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      NULL_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });
  it("should save as an emppty string when a cell is cleared", () => {
    clickTableCellButton(3, 0, "Edit");
    cy.getByTestId("tableCell").clear();
    clickTableCellButton(3, 0, "Apply");

    testDecisionTableRow(3, [
      "4",
      EMPTY_STRING_DISPLAY,
      EMPTY_STRING_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });
  it("should delete a cell and save it as null", () => {
    clickTableCellButton(3, 1, "Edit");
    cy.getByTestId("tableCell").type("gibberish");
    clickTableCellButton(3, 1, "Delete");

    testDecisionTableRow(3, [
      "4",
      "Empty/zero values",
      NULL_DISPLAY,
      "0",
      "0",
      "0",
      "",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should not display NaN when converting a datetime column to a string", () => {
    cy.wait(500);
    testDecisionTableRow(2, [
      "3",
      "Nulls",
      "NULL",
      "NULL",
      "NULL",
      "NULL",
      { type: "checkbox", isChecked: false },
      "NULL",
      "NULL",
      "NULL",
      "NULL",
    ]);

    // edit and click apply without changing the value:
    clickTableCellButton(2, 7, "Edit");
    clickTableCellButton(2, 7, "Apply");

    // change the column type from Date + Time to String
    cy.getByTestId("column-context-menu").should("not.exist");
    clickColumnContextMenuOption(8, 0); // edit column def
    cy.getByTestId("typeField").should("exist");
    selectFormField("typeInput", "String");
    cy.getByTestId("dialog-submit-button").click();

    testDecisionTableRow(2, [
      "3",
      "Nulls",
      "NULL",
      "NULL",
      "NULL",
      "NULL",
      { type: "checkbox", isChecked: false },
      "NULL",
      "NULL",
      "NULL",
      "NULL",
    ]);
  });
});

it("should redirect to page not found when decision table does not exist", () => {
  cy.testPageNotFound("/rule-designer/designer/decision-tables/DoesNotExist");
});

describe("unsaved decision table changes", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });

  it("should display confirmation dialog and confirm when navigating away with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true; // Simulate clicking 'OK'
    });

    clickTableCellButton(0, 0);
    cy.getByTestId("tableCell").type("gibberish");
    clickTableCellButton(0, 0, "Apply");
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should("include", "/dashboard");
  });

  it("should display confirmation dialog and cancel when navigating away with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return false; // Simulate clicking 'Cancel'
    });

    clickTableCellButton(0, 0);
    cy.getByTestId("tableCell").type("gibberish");
    clickTableCellButton(0, 0, "Apply");
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should(
      "include",
      "/rule-designer/designer/decision-tables/TestTypes_DT",
    );
  });

  // test navigating to table function tab when unsaved decision table changes
  it("should display confirmation dialog and confirm when clicking table function tab", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true; // Simulate clicking 'OK'
    });

    clickTableCellButton(0, 0);
    cy.getByTestId("tableCell").type("gibberish");
    clickTableCellButton(0, 0, "Apply");
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");

    cy.getByTestId("tableFunctionsTab").click();
    cy.wait(1000);
    cy.getByTestId("tableFunctionsTab").should(
      "have.attr",
      "data-state",
      "active",
    );
  });

  it("should display confirmation dialog and cancel when navigating to table functions tab with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return false; // Simulate clicking 'Cancel'
    });

    clickTableCellButton(0, 0);
    cy.getByTestId("tableCell").type("gibberish");
    clickTableCellButton(0, 0, "Apply");
    cy.getByTestId("saveBtn").should("exist").should("be.enabled");
    cy.getByTestId("tableFunctionsTab").click();
    cy.wait(1000);
    cy.getByTestId("decisionTableTab").should(
      "have.attr",
      "data-state",
      "active",
    );
  });
});

describe("add/edit decision table conditions", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
  });
  it("should add a new cell condition to the existing column", () => {
    clickColumnContextMenuOption(1, 0);
    cy.getByTestId("addColConditionBtn").click();
    cy.getByTestId("cellConditionInput").type("test", { force: true });
    cy.getByTestId("addCellPredicateDialog-dialog-submit-button").click();
    cy.getByTestId("expressionField").contains("Enter required field");
    cy.getByTestId("expressionField")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("theRequest");
    cy.getByTestId("addCellPredicateDialog-dialog-submit-button").click();
    cy.get("table tbody tr").eq(4).should("contain.text", "test");
  });
  it("should edit a cell condition", () => {
    clickColumnContextMenuOption(1, 0);
    cy.getByTestId("editCellConditionBtn").first().click();
    cy.getByTestId("expressionField")
      .find("textarea.inputarea")
      .type("{selectall}{backspace}", { force: true });
    cy.getByTestId("expressionField")
      .find(".monaco-scrollable-element")
      .find(".lines-content")
      .find(".view-line")
      .type("newValueTest");
    cy.getByTestId("addCellPredicateDialog-dialog-submit-button")
      .should("be.enabled")
      .click();
  });
  it("delete a cell condition", () => {
    clickColumnContextMenuOption(1, 0);
    cy.getByTestId("deleteCellConditionBtn").first().click();
    cy.getByTestId("dialog-destructive-button").click();
  });
});

describe("add/edit decision table actions", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
  });
  it("should add a new cell condition to the existing cell", () => {
    cy.get(
      `[data-testid='decisionTableCell-0-1'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellActionBtn");
    cy.get("@cellActionBtn").should("exist").scrollIntoView();
    cy.get("@cellActionBtn").click();
    cy.getByTestId("cellConditionInput").should("be.visible").select("2");
    cy.get(
      `[data-testid='decisionTableCell-0-1'] button[aria-label="Apply"]`,
    ).click();
  });
  it("should display the cell condition details", () => {
    cy.get(
      `[data-testid='decisionTableCell-1-1'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellConditionBtn");
    testCellConditionTooltip(1, 1, "Not Applicable", "true");
  });
  it("should move the cell condition to corresponding cell on moving the row", () => {
    clickRowContextMenuOption(1, 1);
    testCellConditionTooltip(0, 1, "Not Applicable", "true");
  });
});

describe("delete rows appropriately in the decision table", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/DT_New");
  });
  it("should add/delete rows in the decision table appropriately", () => {
    clickRowContextMenuOption(0, 1);
    clickColumnContextMenuOption(0, 1);
    testDecisionTableRow(0, [
      "1",
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
    ]);
  });
  it("should test DT features while importing", () => {
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("importFileBtn").click();

    const fileName = "Test_Import_Delete_Row.xlsx";
    const fileType =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    cy.fixture(fileName, "binary")
      .then(Cypress.Blob.binaryStringToBlob)
      .then((blob) => {
        cy.get('input[type="file"]').attachFile({
          fileContent: blob,
          fileName,
          mimeType: fileType,
        });
      });
    cy.wait(1000);
    cy.getByTestId("decisionTablePaginationNextPageBtn")
      .should("not.be.disabled")
      .click();
    clickRowContextMenuOption(1, 5);
    testDecisionTableRow(1, [
      "52",
      "Test53",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(2, [
      "53",
      "Test54",
      { type: "checkbox", isChecked: true },
    ]);
    clickRowContextMenuOption(1, 0);
    testDecisionTableRow(2, [
      "53",
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
    ]);
    clickRowContextMenuOption(3, 1);
    testDecisionTableRow(2, [
      "53",
      "Test54",
      { type: "checkbox", isChecked: true },
    ]);
    cy.wait(500);
    filterDecisionTable("Test53");
    clickRowContextMenuOption(0, 0);
    cy.getByTestId("decisionTableFilterResetBtn").click();
    cy.wait(500);
    cy.getByTestId("decisionTablePaginationNextPageBtn")
      .should("not.be.disabled")
      .click();
    testDecisionTableRow(2, [
      "53",
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
    ]);
  });
});

describe("decision table import validation enhancement", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/Import_Validation");
  });

  it("should import cell conditions and display a warning if there are missing cell conditions", () => {
    cy.getByTestId("nav-menu-more").click();
    cy.getByTestId("importFileBtn").click();

    const fileName = "Test_Import_Validation.xlsx";
    const fileType =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    cy.fixture(fileName, "binary")
      .then(Cypress.Blob.binaryStringToBlob)
      .then((blob) => {
        cy.get('input[type="file"]').attachFile({
          fileContent: blob,
          fileName,
          mimeType: fileType,
        });
      });

    testIsDialogDisplayed("missingCellConditionsDialog-dialog-container");
    cy.getByTestId("missingCellConditionsDialog-dialog-title").contains(
      "Missing Cell Conditions",
    );
    cy.getByTestId("missingCellConditionsDialog-dialog-content")
      .should("exist")
      .should(
        "include.text",
        "There are missing cell conditions in the imported data. If you want to apply default cell conditions to all cells with missing conditions, choose Apply Default Conditions from the Row header menu",
      );

    cy.getByTestId("missingCellConditionsDialog-dialog-cancel-button").click();
    testDecisionTableRow(6, [
      "7",
      "Test Column5",
      "Test Column6",
      { type: "checkbox", isChecked: false },
    ]);
    cy.get(
      `[data-testid='decisionTableCell-1-2'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellConditionBtn");
    cy.get("@cellConditionBtn").focus();
    cy.getByTestId("cell-augmentation-tooltip").should("be.visible");
    cy.getByTestId("cell-augmentation-tooltip")
      .should("exist")
      .should("include.text", "Click to select a custom condition");
    clickColumnContextMenuOption(0, 2);
    cy.getByTestId(
      "applyDefaultConditionsDialog-dialog-secondary-button",
    ).click();
    cy.get(
      `[data-testid='decisionTableCell-1-2'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellConditionBtn");
    cy.get("@cellConditionBtn").focus();
    cy.getByTestId("cell-augmentation-tooltip").should("be.visible");
    cy.getByTestId("cell-augmentation-tooltip")
      .should("exist")
      .should("include.text", "Click to select a custom condition");
    clickColumnContextMenuOption(0, 2);
    cy.getByTestId("applyDefaultConditionsDialog-dialog-submit-button").click();
    // Test that default conditions have been applied to all rows in column 2
    testColumnHasDefaultConditions(2, "cellCond1");
    testToast(ToastTitle.SUCCESS, ToastMessage.APPLIED_DEFAULT_CELL_CONDITIONS);
    clickColumnContextMenuOption(0, 2);
    cy.getByTestId("applyDefaultConditionsDialog-dialog-submit-button").click();
    testToast(ToastTitle.WARNING, ToastMessage.NO_DEFAULT_CELL_CONDITIONS);
  });

  it("should apply default cell conditions", () => {
    cy.visit("/rule-designer/designer/decision-tables/Apply_DefaultCondition");
    cy.wait(1000);
    // test for the first column
    getDecisionTableHeader(3)
      .find(`[data-testid='column-header-info-icon']`)
      .as("infoIcon");

    cy.get("@infoIcon").should("not.be.visible").focus();

    cy.getByTestId("column-header-tooltip").should("exist");

    cy.getByTestId("column-header-tooltip")
      .find("[data-testid='column-header-tooltip-cellCondition']")
      .as("defaultCondition");
    cy.get("@defaultCondition")
      .should("exist")
      .should("include.text", "Default Cell Condition")
      .should("include.text", "defaultCellCond");

    clickColumnContextMenuOption(0, 2);

    cy.getByTestId("applyDefaultConditionsDialog-dialog-title").should(
      "be.visible",
    );
    cy.getByTestId("applyDefaultConditionsDialog-dialog-content")
      .should("exist")
      .should(
        "include.text",
        "Applying default conditions will apply the default condition for all cells that do not",
      )
      .should("include.text", "already have a cell condition configured.")
      .should(
        "include.text",
        "Are you sure you want to apply default cell conditions?",
      );

    cy.getByTestId(
      "applyDefaultConditionsDialog-dialog-secondary-button",
    ).click();

    testDialogIsNotDisplayed();

    cy.get(
      `[data-testid='decisionTableCell-1-2'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellConditionBtn");
    cy.get("@cellConditionBtn").focus();
    cy.getByTestId("cell-augmentation-tooltip")
      .should("exist")
      .should("include.text", "Click to select a custom condition");

    clickColumnContextMenuOption(0, 2);
    cy.getByTestId("applyDefaultConditionsDialog-dialog-submit-button").click();
    testToast(ToastTitle.SUCCESS, ToastMessage.APPLIED_DEFAULT_CELL_CONDITIONS);
    testColumnHasDefaultConditions(3, "defaultCellCond");
    testCellConditionTooltip(0, 6, "condition1", "theRequest");
    testCellConditionTooltip(1, 6, "condition2", "theRequest");
    testCellConditionTooltip(2, 6, "condition1", "theRequest");
    testCellConditionTooltip(3, 6, "condition1", "theRequest");
    testCellConditionTooltip(4, 6, "condition1", "theRequest");
    testCellConditionTooltip(5, 6, "condition2", "theRequest");
    clickColumnContextMenuOption(0, 2);
    cy.getByTestId("applyDefaultConditionsDialog-dialog-submit-button").click();
    testToast(ToastTitle.WARNING, ToastMessage.NO_DEFAULT_CELL_CONDITIONS);
  });

  it("should display toast message when no default cell conditions are set", () => {
    clickColumnContextMenuOption(2, 0);
    cy.getByTestId("defaultCellConditionCheckbox").first().click();
    cy.getByTestId("dialog-submit-button").click();
    clickColumnContextMenuOption(0, 2);
    cy.getByTestId("applyDefaultConditionsDialog-dialog-submit-button").click();
    testToast(ToastTitle.WARNING, ToastMessage.NO_DEFAULT_CELL_CONDITIONS);
  });
});

describe("converting condition type to actions", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/DT_ConditionAction");
  });
  it("should delete the condition data by converting condition column to action", () => {
    getTableCell(0, 0).should("have.text", "test_1");
    getTableCell(1, 0).should("have.text", "test_2");
    testCellConditionTooltip(1, 1, "condition1", "theRequest");
    testCellConditionTooltip(0, 1, "condition2", "theRequest");
    clickAnywhere();
    clickColumnContextMenuOption(1, 0); // Edit condition column
    cy.getByTestId("dataTableContainer").should("exist");
    cy.get('[data-testid="dispositionField"]').contains("Action").click();
    cy.getByTestId("dialog-submit-button").click();
    testIsDialogDisplayed(
      "conditionToActionConfirmationDialog-dialog-container",
    );
    cy.getByTestId("conditionToActionConfirmationDialog-dialog-content").should(
      "have.text",
      "Changing a Condition column to an Action column will remove the cell conditions defined on the column and assigned to cells.Do you want to proceed?",
    );
    cy.getByTestId("conditionToActionConfirmationDialog-dialog-content")
      .find("div.font-semibold")
      .should("have.text", "Do you want to proceed?");
    cy.getByTestId("conditionToActionConfirmationDialog-dialog-cancel-button")
      .should("have.text", "Cancel")
      .click({ force: true });
    testDialogIsNotDisplayed(
      "conditionToActionConfirmationDialog-dialog-container",
    );
    cy.getByTestId("dialog-submit-button").click();
    cy.getByTestId("conditionToActionConfirmationDialog-dialog-submit-button")
      .should("have.text", "Delete")
      .click({ force: true });
    cy.getByTestId("dataTableContainer").should("not.exist");
    cy.get(
      `[data-testid='decisionTableCell-0-1'] button[data-testid='cell-augmentation-trigger']`,
    ).should("not.exist");
    cy.get(
      `[data-testid='decisionTableCell-1-1'] button[data-testid='cell-augmentation-trigger']`,
    ).should("not.exist");
    getTableCell(0, 0).should("have.text", "test_1");
    getTableCell(1, 0).should("have.text", "test_2");
    clickColumnContextMenuOption(2, 0);
    cy.get('[data-testid="dispositionField"]').contains("Action").click();
    cy.getByTestId("dialog-submit-button").click();
    testDialogIsNotDisplayed(
      "conditionToActionConfirmationDialog-dialog-container",
    );
    clickColumnContextMenuOption(1, 0); // Edit condition column
    cy.get('[data-testid="dispositionField"]').contains("Condition").click();
    cy.getByTestId("dialog-submit-button").click();
    testDialogIsNotDisplayed(
      "conditionToActionConfirmationDialog-dialog-container",
    );
    cy.get(
      `[data-testid='decisionTableCell-0-1'] button[data-testid='cell-augmentation-trigger']`,
    ).should("not.exist");
    cy.get(
      `[data-testid='decisionTableCell-1-1'] button[data-testid='cell-augmentation-trigger']`,
    ).should("not.exist");
    clickColumnContextMenuOption(0, 2);
    cy.getByTestId("applyDefaultConditionsDialog-dialog-submit-button").click();
    testToast(ToastTitle.WARNING, ToastMessage.NO_DEFAULT_CELL_CONDITIONS);
    clickColumnContextMenuOption(2, 0); // Edit condition column
    cy.get('[data-testid="dispositionField"]').contains("Condition").click();
    cy.getByTestId("dialog-submit-button").click();
    testDialogIsNotDisplayed(
      "conditionToActionConfirmationDialog-dialog-container",
    );
  });
});

describe("date and datetime formats", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });

  it("should default date format to MM/DD/YYYY", () => {
    // TEST NEW COLUMN
    clickColumnContextMenuOption(1, 1);
    typeFormField("varNameInput", "dateColumn");
    typeFormField("displayNameInput", "dateColumn");
    selectFormField("typeInput", "Date");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY (e.g., 12/15/2024");
    submitDialog();
    // reopen to ensure date format sticks:
    clickColumnContextMenuOption(2, 0);
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY (e.g., 12/15/2024");
    cancelDialog();

    // TEST CONVERTING STRING COLUMN TO DATE
    clickColumnContextMenuOption(3, 0);
    cy.getByTestId("typeInput").should("exist").should("have.value", "String");
    selectFormField("typeInput", "Date");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY (e.g., 12/15/2024");
    submitDialog();
    // reopen to ensure date format sticks:
    clickColumnContextMenuOption(3, 0);
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY (e.g., 12/15/2024");
    cancelDialog();

    // TEST CONVERTING DATETIME COLUMN TO DATE
    clickColumnContextMenuOption(9, 0);
    cy.getByTestId("typeInput")
      .should("exist")
      .should("have.value", "Timestamp");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY HH:mm");
    selectFormField("typeInput", "Date");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY (e.g., 12/15/2024)");
    submitDialog();
    // reopen to ensure date format sticks:
    clickColumnContextMenuOption(9, 0);
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY (e.g., 12/15/2024)");
    cancelDialog();
  });

  it("should default datetime format to MM/DD/YYYY HH:mm", () => {
    // TEST NEW COLUMN
    clickColumnContextMenuOption(1, 1);
    typeFormField("varNameInput", "datetimeColumn");
    typeFormField("displayNameInput", "datetimeColumn");
    selectFormField("typeInput", "Timestamp");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY HH:mm")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY HH:mm (e.g., 12/15/2024 07:12)");
    submitDialog();
    // reopen to ensure date format sticks:
    clickColumnContextMenuOption(2, 0);
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY HH:mm")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY HH:mm (e.g., 12/15/2024 07:12)");
    cancelDialog();

    // TEST CONVERTING STRING COLUMN TO DATETIME
    clickColumnContextMenuOption(3, 0);
    cy.getByTestId("typeInput").should("exist").should("have.value", "String");
    selectFormField("typeInput", "Timestamp");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY HH:mm")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY HH:mm (e.g., 12/15/2024 07:12)");
    submitDialog();
    // reopen to ensure date format sticks:
    clickColumnContextMenuOption(3, 0);
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY HH:mm")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY HH:mm (e.g., 12/15/2024 07:12)");
    cancelDialog();

    // TEST CONVERTING DATE COLUMN TO DATETIME
    clickColumnContextMenuOption(8, 0);
    cy.getByTestId("typeInput").should("exist").should("have.value", "Date");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY");
    selectFormField("typeInput", "Timestamp");
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY HH:mm")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY HH:mm (e.g., 12/15/2024 07:12)");
    submitDialog();
    // reopen to ensure date format sticks:
    clickColumnContextMenuOption(8, 0);
    cy.getByTestId("formatInput")
      .should("exist")
      .should("have.value", "MM/DD/YYYY HH:mm")
      .find("option:selected")
      .should("contain.text", "MM/DD/YYYY HH:mm (e.g., 12/15/2024 07:12)");
    cancelDialog();
  });
});

describe("make Decision table RowIDs static", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/DT_TestStaticRow");
  });

  it("should insert a row after a specific row in normal view", () => {
    cy.wait(500);
    // Precondition: Decision table has rows with rowIds 1, 2, 3, 4, 5, 6
    testNumRowsInDecisionTable(50);
    testDecisionTableRow(0, [
      "1",
      "test1",
      "temp1",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t1", "theRequest");
    testDecisionTableRow(30, [
      "31",
      "test29",
      "temp29",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(30, 2, "t2", "ruleManagementTable");
    clickRowContextMenuOption(29, 0); // Insert row after row 30
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(30, [
      "31",
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(31, [
      "32",
      "test29",
      "temp29",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(31, 2, "t2", "ruleManagementTable");
  });

  it("should insert a row after a specific row in filtered view", () => {
    cy.wait(500);
    testDecisionTableRow(5, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    // Click to open the pagination dropdown
    cy.getByTestId("decisionTablePaginationRowsPerPageBtn").click();
    cy.get('[role="option"]').eq(5).click();
    testDecisionTableRow(54, [
      "55",
      "test50",
      "temp50",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(54, 2, "t2", "ruleManagementTable");
    filterDecisionTable("test5");
    testDecisionTableRow(0, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(1, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(1, 2, "t1", "theRequest");
    testDecisionTableRow(3, [
      "55",
      "test50",
      "temp50",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(3, 2, "t2", "ruleManagementTable");
    clickRowContextMenuOption(2, 0);
    testDecisionTableRow(3, [
      "33",
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
    ]);
    clearDecisionTableFilter();
    testDecisionTableRow(32, [
      "33",
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
    ]);
    // In addition to it, tested pasting a row below a specific row in filtered view
    clickRowContextMenuOption(29, 3);
    filterDecisionTable("test5");
    testDecisionTableRow(7, [
      "61",
      "test54",
      "temp54",
      { type: "checkbox", isChecked: false },
    ]);
    clickRowContextMenuOption(3, 2);
    testDecisionTableRow(4, [
      "57",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(4, 2, "t1", "theRequest");
  });

  it("should delete a specific row in normal view", () => {
    cy.wait(500);
    testNumRowsInDecisionTable(50);
    testDecisionTableRow(5, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t1", "theRequest");
    testDecisionTableRow(30, [
      "31",
      "test29",
      "temp29",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(30, 2, "t2", "ruleManagementTable");
    clickRowContextMenuOption(4, 5); // Delete row 5
    testDecisionTableRow(4, [
      "5",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(28, [
      "29",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(28, 2, "t1", "theRequest");
    testDecisionTableRow(29, [
      "30",
      "test29",
      "temp29",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t2", "ruleManagementTable");
  });

  it("should delete a specific row in filtered view", () => {
    cy.wait(500);

    // Verify initial state in normal view
    testDecisionTableRow(5, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t1", "theRequest");

    // Apply filter to show only rows containing "test5"
    filterDecisionTable("test5");

    // Verify filtered results before deletion
    testDecisionTableRow(0, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(1, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(1, 2, "t1", "theRequest");

    // Delete the first filtered row (row with ID "6")
    clickRowContextMenuOption(0, 3); // Delete row

    // Verify the deleted row is no longer in filtered view
    // The row that was at index 1 should now be at index 0
    testDecisionTableRow(0, [
      "29",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(0, 2, "t1", "theRequest");

    // Clear the filter to verify changes in normal view
    clearDecisionTableFilter();
    cy.wait(500);

    // Verify the row was actually deleted from the table
    // The row that was originally at index 5 should be gone
    // and subsequent rows should have shifted up
    testDecisionTableRow(5, [
      "6",
      "test6",
      "temp6",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(28, [
      "29",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(28, 2, "t1", "theRequest");
  });

  it("should duplicate a specific row in filtered view", () => {
    cy.wait(500);
    testNumRowsInDecisionTable(50);

    testDecisionTableRow(5, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t1", "theRequest");

    // Apply filter to show only rows containing "test5"
    filterDecisionTable("test5");

    // Verify filtered results before duplication
    testDecisionTableRow(0, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(1, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(1, 2, "t1", "theRequest");

    // Duplicate the second filtered row (row with ID "30")
    clickRowContextMenuOption(1, 2); // Duplicate row (index 1, option 3 which is "Duplicate row")

    // The duplicate dialog should appear - we need to specify position
    cy.getByTestId("duplicate-row-position-1-dialog-submit-button")
      .should("be.disabled")
      .as("submitButton");
    cy.get('form[data-testid="duplicate-row-position-1-dialog-form"]').as(
      "form",
    );

    // Set position to duplicate at the end of the table (position 51)
    cy.getByTestId("position-input").clear();
    typeFormField("position-input", "51");
    cy.wait(500);
    cy.get("@form").submit();

    testDecisionTableRow(1, [
      "3",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(3, 2, "t1", "theRequest");

    // Clear the filter to verify the duplication in normal view
    clearDecisionTableFilter();
    cy.wait(500);

    // Navigate to the next page to see the duplicated row at position 51
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();

    // Verify the duplicated row appears at position 51 with the same data and cell conditions
    testDecisionTableRow(0, [
      "51",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(0, 2, "t1", "theRequest");

    // Verify total row count increased by 1
    cy.getByTestId("decisionTablePaginationPreviousPageBtn").click();

    // Verify original rows are still intact
    testDecisionTableRow(5, [
      "6",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: true },
    ]);
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t1", "theRequest");
  });

  it("should add a new row at specified position on 3rd page", () => {
    cy.wait(500);
    testNumRowsInDecisionTable(50);
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();
    cy.wait(500);
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();
    cy.wait(500);
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();
    clickRowContextMenuOption(10, 0);
    testDecisionTableRow(11, [
      "112",
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox", isChecked: false },
    ]);
  });

  it("verify the move row up/down functionality", () => {
    cy.wait(500);
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t1", "theRequest");
    testDecisionTableRow(28, [
      "29",
      "test28",
      "temp28",
      { type: "checkbox", isChecked: false },
    ]);
    cy.get(
      `[data-testid='decisionTableCell-28-2'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellConditionBtn");
    cy.get("@cellConditionBtn").focus();
    cy.getByTestId("cell-augmentation-tooltip")
      .should("exist")
      .should("include.text", "Click to select a custom condition");
    clickRowContextMenuOption(29, 1); // Move row 30 up
    testDecisionTableRow(28, [
      "29",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(28, 2, "t1", "theRequest");
    testDecisionTableRow(29, [
      "30",
      "test28",
      "temp28",
      { type: "checkbox", isChecked: false },
    ]);
    cy.get(
      `[data-testid='decisionTableCell-29-2'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellConditionBtn");
    cy.get("@cellConditionBtn").focus();
    cy.getByTestId("cell-augmentation-tooltip")
      .should("exist")
      .should("include.text", "Click to select a custom condition");

    // Test moving the same row down
    clickRowContextMenuOption(28, 2); // Move row 29 (test5) down
    testDecisionTableRow(28, [
      "29",
      "test28",
      "temp28",
      { type: "checkbox", isChecked: false },
    ]);
    cy.get(
      `[data-testid='decisionTableCell-28-2'] button[data-testid='cell-augmentation-trigger']`,
    ).as("cellConditionBtn");
    cy.get("@cellConditionBtn").focus();
    cy.getByTestId("cell-augmentation-tooltip")
      .should("exist")
      .should("include.text", "Click to select a custom condition");
    testDecisionTableRow(29, [
      "30",
      "test5",
      "temp5",
      { type: "checkbox", isChecked: false },
    ]);
    testCellConditionTooltip(29, 2, "t1", "theRequest");

    // Move the bottom row down
    testDecisionTableRow(49, [
      "50",
      "test46",
      "temp46",
      { type: "checkbox", isChecked: false },
    ]);
    clickRowContextMenuOption(49, 2); // Move row 50 (test47) down
    testDecisionTableRow(49, [
      "50",
      "test47",
      "temp47",
      { type: "checkbox", isChecked: false },
    ]);
    cy.getByTestId("decisionTablePaginationNextPageBtn").click();
    testDecisionTableRow(0, [
      "51",
      "test46",
      "temp46",
      { type: "checkbox", isChecked: false },
    ]);
  });
});
