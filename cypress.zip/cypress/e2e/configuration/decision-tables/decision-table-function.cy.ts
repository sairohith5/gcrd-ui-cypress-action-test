import { skipOn } from "@cypress/skip-test";
import {
  testDescriptionEditForm,
  testFormField,
  testFormFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import {
  testAssociatedRecordsGrid,
  testAssociatedRecordsGridRow,
  testAssociatedRecordsSheet,
} from "../../../utils/associated-records-utils";
import { NODE_X, NODE_Y } from "../../../utils/constants";

describe("table function graph screen", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance/function/defaultRule",
    );
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter("defaultRule", "row match result 0");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs([
      "Home",
      "Decision Tables",
      "Decision Table: DT_MasterTableForHierarchyRootPathInstance",
      "Table Functions",
    ]);
    cy.testSidebar("Designer", "Decision Tables");
  });

  it("edits description", () => {
    testDescriptionEditForm();
  });

  it("should display associated items", () => {
    // most of the associated items testing is done in decision-table.cy.ts, so just testing a few things here
    testAssociatedRecordsSheet(
      "DT_MasterTableForHierarchyRootPathInstance",
      false,
      true,
    );
  });

  it("should open the properties panel of the start node and verify if both arguments grid and return type drop-down are displayed", () => {
    cy.wait(2000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const startNodeX = 10 + NODE_X;
      const startNodeY = 10 + NODE_Y;

      cy.wrap(canvas).trigger("mousemove", {
        focus: true,
        x: startNodeX,
        y: startNodeY,
      });

      cy.wrap(canvas).dblclick(startNodeX, startNodeY);
      cy.wait(1000);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.getByTestId("argumentsAccordion").should("exist");
      cy.getByTestId("returnTypeInput").should("exist");
    });
  });

  it("should test if the view code link is present in the more actions menu", () => {
    cy.getByTestId("nav-menu-more").should("exist").click({ force: true });
    cy.getByTestId("viewCodeLink")
      .should("exist")
      .should(
        "have.attr",
        "href",
        "/rule-designer/code-viewer?graphName=defaultRule&parentName=DT_MasterTableForHierarchyRootPathInstance&type=TABLE_ROW_FUNCTION",
      );
  });
});

describe("adding a table function", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance/function/_new",
    );
  });

  it("displays the add table function screen", () => {
    cy.testHeaderAndFooter(
      "Create New Table Function",
      "Enter a name and click the Save button to design a new Table Function.",
    );

    cy.testNavbar("Designer");
    cy.testBreadcrumbs([
      "Home",
      "Decision Tables",
      "Decision Table: DT_MasterTableForHierarchyRootPathInstance",
      "Table Functions",
    ]);
    cy.testSidebar("Designer", "Decision Tables");

    testFormField("fileFormNameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false);
  });

  it("validates the form", () => {
    cy.getByTestId("btnFileFormSave")
      .should("exist")
      .should("be.disabled")
      .contains("Save");
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("btnFileFormSave")
      .should("exist")
      .should("not.be.disabled")
      .contains("Save");
    cy.getByTestId("btnFileFormSave").click();

    testFormFieldValidation("fileFormNameField", "Enter required field");
    cy.url().should(
      "include",
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance/function/_new",
    );
  });

  it("adds a table function", () => {
    typeFormField("fileNameInput", "newTableFunction");
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("btnFileFormSave").click();
    cy.url().should(
      "include",
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance/function/newTableFunction",
    );
  });
});

describe("Return node Expression field validation for Decision Table Functions", () => {
  beforeEach(() => {
    cy.visit(
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance/function/defaultRule",
    );
    cy.wait(1000);
  });

  it("verify that expression field should be visible and required for defaultRule function in decision table with non-void return type", () => {
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const startNodeX = NODE_X;
      const startNodeY = NODE_Y;

      // Open Start node properties panel
      cy.wrap(canvas).dblclick(startNodeX, startNodeY);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Set return type to Integer (non-void)
      cy.getByTestId("returnTypeInput").should("exist").select("Integer");
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.wait(500);

      // Add a Return node to the function
      const returnNodeX = 400 + NODE_X;
      const returnNodeY = NODE_Y;
      cy.getByTestId("return-shape").should("exist");
      cy.getByTestId("return-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX - 100,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wait(500);

      // Open the property panel for the Return node
      cy.wrap(canvas).dblclick(returnNodeX, returnNodeY + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Expected Result: The Expression field should be visible
      cy.getByTestId("swcRetExpression").should("exist");
      cy.getByTestId("swcRetExpression").should("be.visible");

      // Add something in Description text box
      cy.getByTestId("varDescriptionTextArea").should("exist");
      cy.getByTestId("varDescriptionTextArea").type(
        "Test return node description for decision table function",
      );

      // Click apply and validate Expression field is displaying mandatory field validation
      cy.getByTestId("propsPanelApplyBtn").should("exist");
      cy.getByTestId("propsPanelApplyBtn").should("be.enabled");
      cy.getByTestId("propsPanelApplyBtn").click();

      // Validate that mandatory field validation is displayed for Expression field
      cy.getByTestId("errorMessage")
        .should("exist")
        .should("contain.text", "Enter required field");

      // Expected Result: The Expression field should be marked as required
      // Now add an expression and verify it enables successful save
      cy.getByTestId("swcRetExpression")
        .find(".monaco-scrollable-element")
        .find(".lines-content")
        .find(".view-line")
        .type("123");

      cy.getByTestId("propsPanelApplyBtn").should("not.be.disabled");
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });

  it("verify that expression field should be hidden for defaultRule function in decision table with void return type", () => {
    cy.wait(1000);
    cy.getByTestId("mainGraphCanvas").then(($canvas) => {
      const canvas = $canvas[0];
      const startNodeX = NODE_X;
      const startNodeY = NODE_Y;

      // Open Start node properties panel
      cy.wrap(canvas).dblclick(startNodeX, startNodeY);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Set return type to void
      cy.getByTestId("returnTypeInput").should("exist").select("void");
      cy.getByTestId("propsPanelApplyBtn").click();
      cy.wait(500);

      // Add a Return node to the function
      const returnNodeX = 400 + NODE_X;
      const returnNodeY = NODE_Y;
      cy.getByTestId("return-shape").should("exist");
      cy.getByTestId("return-shape").trigger("mousedown", {
        which: 1,
        pageX: 100,
        pageY: 100,
      });

      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX - 100,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mousemove", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wrap(canvas).trigger("mouseup", {
        x: returnNodeX,
        y: returnNodeY,
      });
      cy.wait(500);

      // Open the property panel for the Return node
      cy.wrap(canvas).dblclick(returnNodeX, returnNodeY + 50);
      cy.getByTestId("propertiesPanel").should("exist");
      cy.wait(500);

      // Expected Result: The Expression field should not be visible
      cy.getByTestId("swcRetExpression").should("not.exist");

      // Expected Result: User cannot enter or edit an expression
      // Return node acts as a simple exit - verify we can close without expression
      cy.getByTestId("propsPanelApplyBtn").should("exist");
      cy.getByTestId("propsPanelApplyBtn").should("be.disabled");

      // Close properties panel
      cy.getByTestId("propsPanelCancelBtn").should("exist").click();
      cy.getByTestId("propertiesPanel").should("not.exist");
    });
  });
});

it("should redirect to page not found when decision table function does not exist", () => {
  cy.testPageNotFound(
    "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance/function/DoesNotExist",
  );
});
