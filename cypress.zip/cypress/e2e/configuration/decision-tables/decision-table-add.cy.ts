import {
  clickColumnContextMenuOption,
  clickTableCellButton,
} from "../../../utils/decision-table-utils";
import {
  openDialog,
  testDialog,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";
import {
  selectFormField,
  testFormField,
  testFormFieldValidation,
  testNameFieldValidation,
  typeFormField,
} from "../../../utils/form-utils";
import {
  clickGridRow,
  testColumnNotSortable,
  testFilterShouldNotExist,
  testRow,
  testTable,
} from "../../../utils/grid-utils";
import {
  ToastMessage,
  ToastTitle,
  testToast,
} from "../../../utils/toast-utils";
import "cypress-file-upload";

describe("add new decision table", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/_new");
    cy.wait(2000);
  });

  it("adds a decision table and validate required fields", () => {
    cy.testHeaderAndFooter(
      "Create New Decision Table",
      "Enter a name and click the Save button to design a new Decision Table.",
    );
    cy.testBrowserTitle("New Decision Table");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home", "Decision Tables"]);
    cy.testSidebar("Designer", "Decision Tables");

    testFormField("fileFormNameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false);
    testFormField("fileCommitMessageField", "Commit Message", false);

    cy.getByTestId("btnFileFormSave")
      .should("exist")
      .should("be.disabled")
      .should("have.text", "Save & Commit");
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("btnFileFormSave").should("exist").should("not.be.disabled");
    cy.getByTestId("btnFileFormSave").click();

    testFormFieldValidation("fileFormNameField", "Enter required field");

    testNameFieldValidation();

    typeFormField("fileNameInput", "new");

    cy.getByTestId("btnFileFormSave").click();
    cy.getByTestId("pageHeader").should("have.text", "new");
    cy.getByTestId("tagline").should("have.text", "test new decision table");
    cy.url().should("include", "/rule-designer/designer/decision-tables/new");

    clickColumnContextMenuOption(1, 0);
    cy.wait(1000);
    cy.getByTestId("dialog-title").contains("Edit Column");
    testFormField("varNameField", "Column ID", true, {
      expectDisabled: true,
      defaultValue: "Column1",
    });
    // Verify tooltip is present for Column ID when column is in use
    cy.getByTestId("columnIdTooltipBtn").should("exist").focus();
    cy.getByTestId("columnIdTooltipContent")
      .should("be.visible")
      .contains(
        "This column is currently being referenced within a rule or function, and therefore cannot be changed.",
      );

    testFormField("displayNameField", "Column Display Name", true, {
      expectDisabled: false,
      defaultValue: "Column1",
    });
    testFormField("typeField", "Type", true, {
      expectDisabled: false,
      defaultValue: "String",
    });

    testFormField("isArrayField", "Is Array?", false, {
      isCheckbox: true,
      expectDisabled: false,
    });

    testFormField("dispositionField", "Column Type", false, {
      isRadioButton: true,
      expectedRadioButtonOptions: ["Condition", "Action"],
      expectedRadioButtonSelected: "Condition",
    });
    testFormField("descriptionField", "Description", false, {
      expectDisabled: false,
      defaultValue: "",
    });
  });

  it("checks for duplicate table name", () => {
    typeFormField("fileNameInput", "duplicate");
    cy.getByTestId("btnFileFormSave").click();
    testToast(
      ToastTitle.ERROR,
      "There was a problem saving the item. Name is not unique",
    );
    cy.url().should("include", "/rule-designer/designer/decision-tables/_new");
  });

  it("should cancel adding a decision table", () => {
    cy.url().should("include", "/rule-designer/designer/decision-tables/_new");
    cy.getByTestId("btnFileFormCancel").should("exist").click();
    cy.window().then((win) => {
      cy.stub(win.history, "back").as("routerBack");
    });
  });

  it("should display confirmation dialog and confirm when navigating away from a new decision table with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return true; // Simulate clicking 'OK'
    });

    typeFormField("fileNameInput", "new");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should("include", "/dashboard");
  });

  it("should display confirmation dialog and cancel when navigating away from a new decision table with unsaved changes", () => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.equal(
        "Your changes have not been saved. Do you wish to leave this page without saving?",
      );
      return false; // Simulate clicking 'Cancel'
    });

    typeFormField("fileNameInput", "new");
    cy.getByTestId("Dashboard-link").click();

    cy.wait(1000);
    cy.url().should("include", "/rule-designer/designer/decision-tables/_new");
  });

  it("should display default values for default rule properties", () => {
    // test that input arguments grid is displayed
    testTable(
      ["Name", "Type", "Is Array?", "Actions"],
      [
        {
          type: "button",
          value: "edit argument inputArg1",
        },
        "String",
        "",
        [
          {
            type: "button",
            value: "delete inputArg1",
          },
        ],
      ],
    );
    for (let columnIndex = 0; columnIndex <= 3; columnIndex++) {
      testColumnNotSortable(columnIndex);
    }

    // test the Return Type fields
    testFormField("returnTypeField", "Return Type", true, {
      expectedSelectOptions: [
        "Select one",
        "ActActivity",
        "ActAidSupplemental",
        "ActAlert",
      ],
      numSelectOptionsToTest: 4,
      defaultValue: "boolean",
    });

    testFormField("varArrayField", "Is Array?", false, {
      isCheckbox: true,
      expectDisabled: false,
    });
  });

  it("should add, edit and delete an input argument", () => {
    // edit an existing input argument
    clickGridRow(0, 0, 0);
    testIsDialogDisplayed();

    typeFormField("varNameInput", "Edited");
    selectFormField("argTypeInput", "ActActivity");
    cy.getByTestId("varArrayInput").click();
    cy.getByTestId("dialog-submit-button").click();
    testRow(0, [
      {
        type: "button",
        value: "edit argument Edited",
      },
      "ActActivity",
      { type: "icon", value: "check", screenReaderText: "item is an array" },
      [
        {
          type: "button",
          value: "delete Edited",
        },
      ],
    ]);

    // delete the existing input argument
    clickGridRow(0, 3, 0);
    testIsDialogDisplayed();
    cy.getByTestId("dialog-destructive-button").click();
    testTable(["Name", "Type", "Is Array?", "Actions"], "No results.");

    // add a new input argument
    openDialog(cy.getByTestId("addArgumentBtn"));
    typeFormField("varNameInput", "inputArg2");
    selectFormField("argTypeInput", "ActActivity");
    cy.getByTestId("varArrayInput").click();
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();

    testRow(0, [
      {
        type: "button",
        value: "edit argument inputArg2",
      },
      "ActActivity",
      { type: "icon", value: "check", screenReaderText: "item is an array" },
      [
        {
          type: "button",
          value: "delete inputArg2",
        },
      ],
    ]);
  });

  it("should validate default rule properties", () => {
    // delete the existing input argument
    clickGridRow(0, 3, 0);
    testIsDialogDisplayed();
    cy.getByTestId("dialog-destructive-button").click();

    // validate that at least one input argument is required:
    typeFormField("fileNameInput", "new");
    cy.getByTestId("btnFileFormSave").click();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_DT_INPUT_ARGS);

    // test the input argument dialog and form fields
    testDialog(cy.getByTestId("addArgumentBtn"), "Add Argument");
    openDialog(cy.getByTestId("addArgumentBtn"));
    testFormField("varNameField", "Name", true);
    testFormField("argTypeField", "Type", true, {
      expectedSelectOptions: [
        "Select one",
        "ActActivity",
        "ActAidSupplemental",
        "ActAlert",
      ],
      numSelectOptionsToTest: 4,
      defaultValue: "",
    });
    testFormField("varArrayField", "Is Array?", false, {
      isCheckbox: true,
      expectDisabled: false,
    });

    // test that an input argument cannot be added without a name and type
    cy.getByTestId("dialog-submit-button").click();
    testFormFieldValidation("varNameField", "Enter required field");
    testFormFieldValidation("argTypeField", "Select an option");
  });
});
