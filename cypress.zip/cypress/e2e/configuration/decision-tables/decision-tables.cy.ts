import { skipOn } from "@cypress/skip-test";
import { getRelativeDate } from "../../../utils/date-utils";
import {
  openDialog,
  testDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "../../../utils/dialog-utils";
import {
  testColumnVisibility,
  testFilter,
  testPagination,
  testRow,
  testSort,
  testTable,
} from "../../../utils/grid-utils";
import {
  testRevisionCompareDialog,
  testRevisionHistoryDialogFromGrid,
  testRollback,
} from "../../../utils/revision-history-utils";
import {
  ToastMessage,
  ToastTitle,
  testToast,
} from "../../../utils/toast-utils";
import { deleteArtifact } from "../../../utils/utils";
import {
  clearFormField,
  testFormField,
  testFormFieldValidation,
  testNameFieldValidationWhenCloning,
  typeFormField,
} from "../../../utils/form-utils";

describe("decision tables", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables");
  });

  it("displays header, footer, sidebar and breadcrumbs", () => {
    skipOn("firefox");
    cy.testHeaderAndFooter("Decision Tables");
    cy.testBrowserTitle("Decision Tables");
    cy.testNavbar("Designer");
    cy.testBreadcrumbs(["Home"]);
    cy.testSidebar("Designer", "Decision Tables");
    cy.getByTestId("tags-container").should("not.be.visible");
  });

  it("displays a grid", () => {
    cy.wait(1000);
    testTable(
      [
        { type: "button", ariaLabel: "Lock Status" },
        "Name",
        "Tags",
        "Last Committed",
        "Actions",
      ],
      [
        { type: "button", value: "checked out by me" },
        "DT_MasterTableForHierarchyRootPathInstance",
        { type: "tags", tags: ["TechnicalLibrary", "GCRE-123"] },
        getRelativeDate("2022-05-03 11:28:33 -0400"),
        [
          {
            type: "button",
            value:
              "view revision history for DT_MasterTableForHierarchyRootPathInstance",
          },
          {
            type: "button",
            value: "clone DT_MasterTableForHierarchyRootPathInstance",
          },
          {
            type: "button",
            value: "Export DT_MasterTableForHierarchyRootPathInstance",
          },
          {
            type: "button",
            value:
              "delete decision table DT_MasterTableForHierarchyRootPathInstance",
          },
        ],
      ],
    );
    testRow(1, [
      { type: "button", value: "checked out by mdickson@healthedge.com" },
      "DT_MessagePriorityInstance",
      { type: "tags", tags: ["GCRE-789"] },
      getRelativeDate("2022-05-03 11:28:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for DT_MessagePriorityInstance",
        },
        { type: "button", value: "clone DT_MessagePriorityInstance" },
        {
          type: "button",
          value: "Export DT_MessagePriorityInstance",
        },
      ],
    ]);
    testFilter("Rule_", [
      "",
      "Rule_Status_Tracking_DT",
      "",
      getRelativeDate("2022-05-03 13:13:33 -0400"),
      [
        {
          type: "button",
          value: "view revision history for Rule_Status_Tracking_DT",
        },
        { type: "button", value: "clone Rule_Status_Tracking_DT" },
        {
          type: "button",
          value: "Export Rule_Status_Tracking_DT",
        },
      ],
    ]);
    testSort(
      1,
      [
        "",
        "TestTypes_DT",
        "",
        getRelativeDate("2022-05-03 13:13:33 -0400"),
        "",
      ],
      [
        "",
        "DT_ColumnsMismatch",
        "",
        getRelativeDate("2022-05-03 13:13:33 -0400"),
        "",
      ],
    );
    // test sort of the tags column
    testSort(
      2,
      [
        "",
        "DT_RealTimeRulesConfiguration",
        "",
        getRelativeDate("2023-12-03 07:18:33 -0400"),
        "",
      ],
      [
        { type: "button", value: "checked out by mdickson@healthedge.com" },
        "DT_MessagePriorityInstance",
        { type: "tags", tags: ["GCRE-789"] },
        getRelativeDate("2022-05-03 11:28:33 -0400"),
        "",
      ],
    );

    testPagination(10);
    testColumnVisibility([
      "Lock Status",
      "Tags",
      "Last Committed",
      "Committed By",
      "Message",
    ]);
  });

  it("deletes a decision table", () => {
    testDialog(cy.getGridRowButtonOrLink(0, 4, 3), "Delete Confirmation");
    openDialog(cy.getGridRowButtonOrLink(0, 4, 3));
    deleteArtifact();
  });

  it("navigates to edit a decision table", () => {
    cy.getGridRowButtonOrLink(0, 1).click();
    cy.url().should(
      "include",
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
  });

  it("navigates to add a decision table", () => {
    cy.getByTestId("btnDTAdd").click();
    cy.url().should("include", "/rule-designer/designer/decision-tables/_new");
  });

  it("exports a decision table", () => {
    cy.getGridRowButtonOrLink(0, 4, 2).click();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_EXPORT);
  });

  it("displays an error while exporting a decision table", () => {
    cy.getGridRowButtonOrLink(8, 4, 2).click();
    testToast(ToastTitle.ERROR, ToastMessage.ERROR_EXPORT_MISMATCH);
  });

  it("navigates to edit a decision table", () => {
    cy.getGridRowButtonOrLink(0, 1).click();
    cy.url().should(
      "include",
      "/rule-designer/designer/decision-tables/DT_MasterTableForHierarchyRootPathInstance",
    );
  });

  it("displays revision history", () => {
    testRevisionHistoryDialogFromGrid(
      0,
      "DT_MasterTableForHierarchyRootPathInstance",
      [
        { type: "checkbox", isChecked: false },
        "b7f3b8f",
        getRelativeDate("2024-11-15 16:53:38 -0500"),
        { type: "email", value: "mdickson1@gmail.com" },
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.",
        { type: "button", value: "Rollback to this revision" },
      ],
    );
    testRevisionCompareDialog(
      0,
      1,
      2,
      "DT_MasterTableForHierarchyRootPathInstance (Decision Table)",
      "b04ff81",
      getRelativeDate("2024-11-15 15:35:01 -0500"),
      "b7f3b8f",
      getRelativeDate("2024-11-15 16:53:38 -0500"),
      "table",
    );
    testRollback(0, 1);
  });

  it("clones a decision table", () => {
    // Open the clone dialog
    testDialog(cy.getGridRowButtonOrLink(0, 4, 1), "Clone Decision Table");
    openDialog(cy.getGridRowButtonOrLink(0, 4, 1));

    // Verify the dialog elements
    cy.getByTestId("dialog-submit-button")
      .should("exist")
      .should("be.disabled")
      .contains("Save & Commit");
    testFormField("filenameField", "Name", true);
    testFormField("fileFormDescriptionField", "Description", false, {
      defaultValue: "cloned from DT_MasterTableForHierarchyRootPathInstance",
    });
    cy.getByTestId("rulegroupInput").should("not.exist");

    // Attempt to save without entering a name
    typeFormField("fileDescriptionInput", "test");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testFormFieldValidation("filenameField", "Enter required field");
    testIsDialogDisplayed();

    testNameFieldValidationWhenCloning();

    // Attempt to save with a duplicate name
    typeFormField("filenameInput", "duplicate");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testIsDialogDisplayed();
    testToast(
      ToastTitle.ERROR,
      "There was a problem saving the item. Name is not unique",
    );

    // Save with a valid name
    clearFormField("filenameInput");
    typeFormField("filenameInput", "cloneTable");
    cy.getByTestId("dialog-submit-button").should("not.be.disabled").click();
    testDialogIsNotDisplayed();
    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_CLONE, true);
  });
});
