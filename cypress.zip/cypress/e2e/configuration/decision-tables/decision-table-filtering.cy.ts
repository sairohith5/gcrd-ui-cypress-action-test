import {
  testDecisionTable,
  testDecisionTableRow,
  testRowContextMenu,
  clickTableCellButton,
  NULL_DISPLAY,
  filterDecisionTable,
  insertRowBelow,
  clearDecisionTableFilter,
  deleteRow,
  insertColumnRight,
  deleteColumn,
  testNumRowsInDecisionTable,
} from "../../../utils/decision-table-utils";
import { testFormField, testFormFieldValue } from "../../../utils/form-utils";
import { getLocalDateTime } from "../../../utils/date-utils";
import "cypress-file-upload";
import { testPagination } from "../../../utils/grid-utils";

describe("decision table filtering", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/TestTypes_DT");
  });

  it("should filter the decision table for string", () => {
    testFormField("decisionTableFilterField", "Filter Current Data", false, {
      defaultValue: "",
    });
    filterDecisionTable('"Sunny Day 2"');
    testNumRowsInDecisionTable(1);

    testDecisionTable(
      [
        "Row",
        "Description",
        "String",
        "Integer",
        "Long",
        "Double",
        "Boolean",
        "Date",
        "Date + Time",
        "Integer Array",
        "String Array",
      ],
      [
        "2",
        "Sunny Day 2",
        "xyz",
        "19",
        "-922337203685",
        "",
        "",
        "12/15/2024",
        "12/15/2024",
        ["899", "5", "14"],
        ["string1", "string2", "string3"],
      ],
    );
  });

  it("should filter the decision table for integer", () => {
    filterDecisionTable("21");
    testNumRowsInDecisionTable(1);

    testDecisionTableRow(0, [
      "1",
      "Sunny Day 1",
      "abc",
      "21",
      "9223372036854",
      "42.5",
      { type: "checkbox", isChecked: true },
      "04/01/2024",
      "12/15/2024 07:12",
      "8",
      "string1",
    ]);
  });

  it("should filter the decision table for double", () => {
    filterDecisionTable("42.5");
    testNumRowsInDecisionTable(1);

    testDecisionTableRow(0, [
      "1",
      "Sunny Day 1",
      "abc",
      "21",
      "9223372036854",
      "42.5",
      { type: "checkbox", isChecked: true },
      "04/01/2024",
      "12/15/2024 07:12",
      "8",
      "string1",
    ]);
  });

  it("should filter the decision table for long", () => {
    filterDecisionTable("-922337203685");
    testNumRowsInDecisionTable(1);

    testDecisionTableRow(0, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "0",
      { type: "checkbox", isChecked: false },
      "12/15/2024",
      "12/15/2024 07:12",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
  });

  it("should filter the decision table for boolean false", () => {
    filterDecisionTable("false");
    testNumRowsInDecisionTable(2);

    testDecisionTableRow(0, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "0",
      { type: "checkbox", isChecked: false },
      "12/15/2024",
      "12/15/2024 07:12",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
  });

  it("should filter the decision table for boolean true", () => {
    filterDecisionTable("true");
    testNumRowsInDecisionTable(1);

    testDecisionTableRow(0, [
      "1",
      "Sunny Day 1",
      "abc",
      "21",
      "9223372036854",
      "42.5",
      { type: "checkbox", isChecked: true },
      "04/01/2024",
      "12/15/2024 07:12",
      "8",
      "string1",
    ]);
  });

  it("should filter the decision table for date", () => {
    filterDecisionTable("12/15/2024");
    testNumRowsInDecisionTable(2);

    testDecisionTableRow(0, [
      "1",
      "Sunny Day 1",
      "abc",
      "21",
      "9223372036854",
      "42.5",
      { type: "checkbox", isChecked: true },
      "04/01/2024",
      "12/15/2024 07:12",
      "8",
      "string1",
    ]);
  });

  it("should filter the decision table for time", () => {
    filterDecisionTable("07:12");

    testDecisionTableRow(0, [
      "1",
      "Sunny Day 1",
      "abc",
      "21",
      "9223372036854",
      "42.5",
      { type: "checkbox", isChecked: true },
      "04/01/2024",
      "12/15/2024 07:12",
      "8",
      "string1",
    ]);

    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "0",
      { type: "checkbox", isChecked: false },
      "12/15/2024",
      "12/15/2024 07:12",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);

    testNumRowsInDecisionTable(2);
  });

  it("should filter the decision table for integer array", () => {
    filterDecisionTable("899");
    testNumRowsInDecisionTable(1);

    testDecisionTableRow(0, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "0",
      { type: "checkbox", isChecked: false },
      "12/15/2024",
      "12/15/2024 07:12",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
  });

  it("should filter the decision table for string array", () => {
    filterDecisionTable("string2");
    testNumRowsInDecisionTable(1);

    testDecisionTableRow(0, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "0",
      { type: "checkbox", isChecked: false },
      "12/15/2024",
      "12/15/2024 07:12",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
  });

  it("should clear the filter", () => {
    filterDecisionTable('"Sunny Day 2"');
    testDecisionTable(
      [
        "Row",
        "Description",
        "String",
        "Integer",
        "Long",
        "Double",
        "Boolean",
        "Date",
        "Date + Time",
        "Integer Array",
        "String Array",
      ],
      [
        "2",
        "Sunny Day 2",
        "xyz",
        "19",
        "-922337203685",
        "",
        "",
        "12/15/2024",
        "12/15/2024",
        ["899", "5", "14"],
        ["string1", "string2", "string3"],
      ],
    );

    testFormFieldValue("decisionTableFilterField", '"Sunny Day 2"');
    clearDecisionTableFilter();
    testFormFieldValue("decisionTableFilterField", "");
    testDecisionTable(
      [
        "Row",
        "Description",
        "String",
        "Integer",
        "Long",
        "Double",
        "Boolean",
        "Date",
        "Date + Time",
        "Integer Array",
        "String Array",
      ],
      [
        "1",
        "Sunny Day 1",
        "abc",
        "21",
        "9223372036854",
        "42.5",
        "",
        "04/01/2024",
        getLocalDateTime(1734264720000),
        "8",
        "string1",
      ],
    );
  });

  it("should display a message when no rows match the filter", () => {
    filterDecisionTable("no match");
    cy.getByTestId("noDataMessage").should("exist");
  });

  it("should update a cell when the table is filtered", () => {
    filterDecisionTable('"Sunny Day 2"');
    clickTableCellButton(0, 1, "Edit");
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("updated text");
    clickTableCellButton(0, 1, "Apply");
    cy.getByTestId("decisionTableCell-0-2").should("have.text", "updated text");

    // clear the filter to ensure the cell still displays the updated text
    cy.getByTestId("decisionTableFilterResetBtn").click();
    cy.getByTestId("decisionTableCell-1-2").should("have.text", "updated text");
  });

  it("should display an updated cell after a table is filtered", () => {
    clickTableCellButton(1, 1, "Edit");
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("updated text");
    clickTableCellButton(1, 1, "Apply");

    cy.getByTestId("decisionTableFilterInput").type('"Sunny Day 2"');
    cy.wait(500);
    cy.getByTestId("decisionTableCell-0-2").should("have.text", "updated text");
  });

  it("should insert a row in a filtered table", () => {
    filterDecisionTable('"Sunny Day 2"');

    cy.wait(1000);
    // test inserting a row at the top, and just below the filtered row
    insertRowBelow(0);
    insertRowBelow(2);

    clearDecisionTableFilter();

    // verify the inserted rows display in the right order after resetting the filter
    testDecisionTableRow(0, [
      "1",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox" },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
    testDecisionTableRow(2, [
      "3",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
    testDecisionTableRow(3, [
      "4",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox" },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should delete a row in a filtered table", () => {
    cy.wait(500);
    testDecisionTableRow(1, [
      "2",
      "Sunny Day 2",
      "xyz",
      "19",
      "-922337203685",
      "",
      "",
      "12/15/2024",
      "12/15/2024",
      ["899", "5", "14"],
      ["string1", "string2", "string3"],
    ]);
    filterDecisionTable('"Sunny Day 2"');
    deleteRow(0);
    cy.getByTestId("noDataMessage").should("exist");
    clearDecisionTableFilter();

    // after deleting the row, the table should the following row in row 1
    testDecisionTableRow(1, [
      "2",
      "Nulls",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox" },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should insert a column in a filtered table", () => {
    filterDecisionTable("Nulls");
    testDecisionTableRow(0, [
      "3",
      "Nulls",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox" },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
    insertColumnRight(0, "newColumn1");
    clearDecisionTableFilter();
    testDecisionTableRow(2, [
      "3",
      NULL_DISPLAY,
      "Nulls",
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      { type: "checkbox" },
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
      NULL_DISPLAY,
    ]);
  });

  it("should delete a column in a filtered table", () => {
    filterDecisionTable("Nulls");
    testDecisionTable(
      [
        "Row",
        "Description",
        "String",
        "Integer",
        "Long",
        "Double",
        "Boolean",
        "Date",
        "Date + Time",
        "Integer Array",
        "String Array",
      ],
      [
        "3",
        "Nulls",
        NULL_DISPLAY,
        NULL_DISPLAY,
        NULL_DISPLAY,
        NULL_DISPLAY,
        { type: "checkbox" },
        NULL_DISPLAY,
        NULL_DISPLAY,
        NULL_DISPLAY,
        NULL_DISPLAY,
      ],
    );

    deleteColumn(2);
    clearDecisionTableFilter();

    testDecisionTable(
      [
        "Row",
        "Description",
        "Integer",
        "Long",
        "Double",
        "Boolean",
        "Date",
        "Date + Time",
        "Integer Array",
        "String Array",
      ],
      [
        "1",
        "Sunny Day 1",
        "21",
        "9223372036854",
        "42.5",
        "",
        "04/01/2024",
        getLocalDateTime(1734264720000),
        "8",
        "string1",
      ],
    );
  });

  it("should not let user move rows in a filtered table", () => {
    testRowContextMenu(0, [
      "Insert row below",
      "Move row down",
      "Copy row",
      "Duplicate row",
      "Delete row",
    ]);

    filterDecisionTable("Nulls");

    // test that the up and down buttons are removed
    testRowContextMenu(0, [
      "Insert row below",
      "Copy row",
      "Duplicate row",
      "Delete row",
    ]);
  });
});

describe("pagination and filtering decision table", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/DT_TestBigData");
  });
  it("should test pagination on a decision table", () => {
    cy.wait(3000);
    testPagination(
      4941,
      50,
      [
        "1",
        "0.8361246513074537",
        "0.7033143878759311",
        "0.8173999291655843",
        "0.476156587020665",
        "0.7985887933633219",
        "0.07545784156229296",
        "0.5898995972221298",
        "0.4289237915635309",
        "0.8161044316365427",
        "0.4547851016656118",
        "0.4892844485383192",
        "0.6837073849684705",
        "0.2638548296166532",
        "0.7502248567705804",
        "0.31652742417491764",
        "0.4364929532436218",
        "0.9993779198107383",
        "0.6331343492594511",
        "0.891238677333938",
        "0.9324518664370383",
        "0.9503409214313386",
        "0.6439617081529189",
        "0.4942037140822567",
        "0.5173518214676028",
      ],
      "decisionTable",
      50,
    );
  });

  it("should filter the decision table", () => {
    filterDecisionTable("test");
    cy.wait(500);
    testDecisionTableRow(0, [
      "2802",
      "0.18058522390355458",
      "0.659354621315547",
      "0.23658141116712805",
      "0.09619930625825701",
      "test",
      "0.4892720461123944",
      "0.9015019241267661",
      "0.9449198008151157",
      "0.3202453525651038",
      "0.9669280154463189",
      "0.21001923648565368",
      "0.3466768159501279",
      "0.5642986069365724",
      "0.2033361589440409",
      "0.32813930980864114",
      "0.21304940764277414",
      "0.10066381995813178",
      "0.14574147072749133",
      "0.9998853256180864",
      "0.12717095857934924",
      "0.14701980468695863",
      "0.43029434625518903",
      "0.11110676825246868",
      "0.5827104880954423",
    ]);
  });
});

describe("enhanced decision table filtering", () => {
  beforeEach(() => {
    cy.visit("/rule-designer/designer/decision-tables/FilterEnhancements");
    cy.wait(2000); // Allow time for table to load
  });

  it("should apply column-specific filter for existing columns", () => {
    // string
    filterDecisionTable("authtype:Inpatient");
    testDecisionTableRow(0, [
      "2",
      "Outpatient",
      "Inpatient",
      "UST",
      ["899", "NULL", "0"],
      ["12/15/2024"],
      "01/07/2025 16:18",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(1, [
      "5",
      "foo:Inpatient",
      "bar:Inpatient",
      "Auto-Approve",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();

    // date
    filterDecisionTable("dateArray:12/18/2024");
    testDecisionTableRow(0, [
      "1",
      "Inpatient",
      "Outpatient",
      "UST",
      ["899", "5", "18"],
      ["12/16/2024", "12/18/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(1, [
      "4",
      "Outpatient",
      "Dental Visit",
      "Auto-Approve",
      ["NULL"],
      ["12/16/2024", "12/18/2024"],
      "04/10/2025 01:58",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();

    // datetime
    filterDecisionTable("timestamp:04/10/2025 01:58");
    testDecisionTableRow(0, [
      "4",
      "Outpatient",
      "Dental Visit",
      "Auto-Approve",
      ["NULL"],
      ["12/16/2024", "12/18/2024"],
      "04/10/2025 01:58",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(1);
    clearDecisionTableFilter();

    // boolean
    filterDecisionTable("boolean:TRUE");
    testDecisionTableRow(0, [
      "3",
      "Inpatient",
      "Pharmacy Claim",
      "UST",
      ["NULL"],
      ["12/15/2024"],
      "01/19/2025 00:35",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();

    filterDecisionTable("boolean:FALSE");
    testDecisionTableRow(0, [
      "1",
      "Inpatient",
      "Outpatient",
      "UST",
      ["899", "5", "18"],
      ["12/16/2024", "12/18/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(6);
    clearDecisionTableFilter();

    // numeric
    filterDecisionTable("intArray:5");
    testDecisionTableRow(0, [
      "1",
      "Inpatient",
      "Outpatient",
      "UST",
      ["899", "5", "18"],
      ["12/16/2024", "12/18/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(1);
    clearDecisionTableFilter();
  });

  it("should handle column-specific filter for non-existing columns", () => {
    filterDecisionTable("foo:Inpatient");
    testDecisionTableRow(0, [
      "5",
      "foo:Inpatient",
      "bar:Inpatient",
      "Auto-Approve",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(1);
    clearDecisionTableFilter();

    filterDecisionTable("bar:Inp");
    testDecisionTableRow(0, [
      "5",
      "foo:Inpatient",
      "bar:Inpatient",
      "Auto-Approve",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(1);
    clearDecisionTableFilter();
  });

  it("should filter with column name and value with spaces", () => {
    // column name with spaces:
    filterDecisionTable('"Auth Type":Inpatient');
    testDecisionTableRow(2, [
      "5",
      "foo:Inpatient",
      "bar:Inpatient",
      "Auto-Approve",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(3);
    clearDecisionTableFilter();

    // value with spaces:
    filterDecisionTable('authtype:"Pharmacy Claim"');
    testDecisionTableRow(0, [
      "3",
      "Inpatient",
      "Pharmacy Claim",
      "UST",
      ["NULL"],
      ["12/15/2024"],
      "01/19/2025 00:35",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();

    // column name and value with spaces:
    filterDecisionTable('"Auth Type":"In Patient"');
    testDecisionTableRow(0, [
      "8",
      "In Patient",
      "Out Patient",
      "",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(1);
    clearDecisionTableFilter();
  });

  it("should combine column-specific filter with general search", () => {
    filterDecisionTable('authtype:"Pharmacy Claim" UST');
    testDecisionTableRow(0, [
      "3",
      "Inpatient",
      "Pharmacy Claim",
      "UST",
      ["NULL"],
      ["12/15/2024"],
      "01/19/2025 00:35",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(1);
    clearDecisionTableFilter();
  });

  it("should combine multiple column-specific filters with general search", () => {
    filterDecisionTable('"Auth Type":Inpatient authOwner:UST Pharmacy');
    testDecisionTableRow(0, [
      "3",
      "Inpatient",
      "Pharmacy Claim",
      "UST",
      ["NULL"],
      ["12/15/2024"],
      "01/19/2025 00:35",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(1);
    clearDecisionTableFilter();
  });

  it("should filter with empty string value", () => {
    filterDecisionTable('""');
    testDecisionTableRow(0, [
      "7",
      "Outpatient",
      "pharmacy claim",
      "",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();

    filterDecisionTable('authOwner:""');
    testDecisionTableRow(0, [
      "7",
      "Outpatient",
      "pharmacy claim",
      "",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();

    filterDecisionTable('authtype:""');
    testNumRowsInDecisionTable(0);
    clearDecisionTableFilter();
  });

  it("should filter with case-insensitive values", () => {
    filterDecisionTable("AUTHtype:InPATIENT");
    testDecisionTableRow(0, [
      "2",
      "Outpatient",
      "Inpatient",
      "UST",
      ["899", "NULL", "0"],
      ["12/15/2024"],
      "01/07/2025 16:18",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(1, [
      "5",
      "foo:Inpatient",
      "bar:Inpatient",
      "Auto-Approve",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();
  });

  it("should not filter for NULL values", () => {
    filterDecisionTable("NULL");
    testNumRowsInDecisionTable(0);
    clearDecisionTableFilter();

    filterDecisionTable("authtype:NULL");
    testNumRowsInDecisionTable(0);
    clearDecisionTableFilter();
  });

  it("should display filter tooltip with enhanced filtering instructions", () => {
    // Check if the filter tooltip button exists
    cy.getByTestId("filter-tooltip-btn").should("exist");

    // Click or hover to trigger the tooltip
    cy.getByTestId("filter-tooltip-btn").should("exist").focus();
    cy.getByTestId("filter-tooltip-content")
      .should("be.visible")
      .contains("Filter Options:");
  });

  it("should re-filter after saving changes to the decision table", () => {
    filterDecisionTable("authtype:Inpatient");
    testDecisionTableRow(0, [
      "2",
      "Outpatient",
      "Inpatient",
      "UST",
      ["899", "NULL", "0"],
      ["12/15/2024"],
      "01/07/2025 16:18",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(1, [
      "5",
      "foo:Inpatient",
      "bar:Inpatient",
      "Auto-Approve",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(2);
    clickTableCellButton(0, 1, "Edit");
    cy.getByTestId("tableCell").clear();
    cy.getByTestId("tableCell").type("updated text");
    clickTableCellButton(0, 1, "Apply");
    cy.wait(500);
    cy.getByTestId("decisionTableCell-0-2").should("have.text", "updated text");
    cy.getByTestId("saveBtn").click();
    cy.wait(500);
    testDecisionTableRow(0, [
      "5",
      "foo:Inpatient",
      "bar:Inpatient",
      "Auto-Approve",
      ["NULL"],
      ["12/15/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: true },
    ]);
    testNumRowsInDecisionTable(1);
  });

  it("should re-filter when a column-specific value is removed", () => {
    // test this with a column name without spaces
    filterDecisionTable("authtype:Outpatient authOwner:UST");
    testDecisionTableRow(0, [
      "1",
      "Inpatient",
      "Outpatient",
      "UST",
      ["899", "5", "18"],
      ["12/16/2024", "12/18/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(1);

    // remove the "UST" filter value from the authOwner column
    cy.getByTestId("decisionTableFilterInput").type(
      "{backspace}{backspace}{backspace}",
    );
    cy.wait(1100);
    testDecisionTableRow(0, [
      "1",
      "Inpatient",
      "Outpatient",
      "UST",
      ["899", "5", "18"],
      ["12/16/2024", "12/18/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testDecisionTableRow(1, [
      "6",
      "bar:Outpatient",
      "foo:Outpatient",
      "NULL",
      ["NULL"],
      ["12/17/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(2);
    clearDecisionTableFilter();

    // now test with a column name with spaces
    filterDecisionTable('"auth type":out');
    testDecisionTableRow(0, [
      "2",
      "Outpatient",
      "Inpatient",
      "UST",
      ["899", "NULL", "0"],
      ["12/15/2024"],
      "01/07/2025 16:18",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(4);

    // remove the "out" filter value from the authOwner column
    cy.getByTestId("decisionTableFilterInput").type(
      "{backspace}{backspace}{backspace}",
    );
    cy.wait(1100);
    testDecisionTableRow(0, [
      "1",
      "Inpatient",
      "Outpatient",
      "UST",
      ["899", "5", "18"],
      ["12/16/2024", "12/18/2024"],
      "12/15/2024 07:12",
      { type: "checkbox", isChecked: false },
    ]);
    testNumRowsInDecisionTable(8);
  });
});
