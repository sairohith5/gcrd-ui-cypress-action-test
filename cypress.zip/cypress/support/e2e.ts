// ***********************************************************
// This example support/e2e.ts is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************
// Import commands.js using ES2015 syntax:
// import "./commands";
// Alternatively you can use CommonJS syntax:
// require('./commands')
// the typescript way of doing it:
import "cypress-file-upload";
import "@cypress/skip-test";
import "cypress-mochawesome-reporter/register";
import "cypress-real-events";
import { registerCommands } from "./commands";

registerCommands();

before(() => {
  // verify app is in NEXT_PUBLIC_MOCK_SERVER mode (if not, no other tests will run)
  cy.visit("/");
  cy.getByTestId("mockServerBadge");

  Cypress.on("uncaught:exception", () => {
    // returning false here prevents Cypress from failing the tests when an uncaught exception occurs
    // (these are typically anomolies related to Cypress/mock server weirdness that we don't want to fail the tests for)
    return false;
  });
});

beforeEach(() => {
  cy.viewport(1920, 1080);
});
