/// <reference types="cypress" />
// ***********************************************
// This example commands.ts shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
//
// }
import "cypress-file-upload";

export function registerCommands() {
  Cypress.Commands.add("clickTabByIndex", (index, tabListTestId) => {
    const nthChild = index + 1; // nth-child is not zero-based, so add 1
    cy.get("div[data-testid='" + tabListTestId + "']")
      .find("button[role='tab']:nth-child(" + nthChild + ")")
      .click();
  });

  // @ts-ignore
  Cypress.Commands.add("getByTestId", (testId, ...args) => {
    return cy.get(`[data-testid=${testId}]`, ...args);
  });

  Cypress.Commands.add(
    "getGridCell",
    // @ts-ignore
    (rowIndex, columnIndex, tableTestId) => {
      tableTestId = tableTestId ? tableTestId : "dataTableContainer";

      const nthChildRow = rowIndex + 1; // nth-child is not zero-based, so add 1
      const nthChildCol = columnIndex + 1; // nth-child is not zero-based, so add 1

      return cy
        .getByTestId(tableTestId)
        .find(
          "tbody tr:nth-child(" +
            nthChildRow +
            ") th:nth-child(" +
            nthChildCol +
            "), tbody tr:nth-child(" +
            nthChildRow +
            ") td:nth-child(" +
            nthChildCol +
            ")",
        );
    },
  );

  Cypress.Commands.add(
    "getGridRowButtonOrLink",
    // @ts-ignore
    (rowIndex, columnIndex, elementIndex, tableTestId) => {
      // wait until the onclick events are attached to the grid buttons
      cy.wait(500);

      elementIndex = elementIndex ? elementIndex : 0;
      tableTestId = tableTestId ? tableTestId : "dataTableContainer";

      const nthChildRow = rowIndex + 1; // nth-child is not zero-based, so add 1
      const nthChildCol = columnIndex + 1; // nth-child is not zero-based, so add 1
      const nthChildElement = elementIndex + 1; // nth-child is not zero-based, so add 1

      if (elementIndex === null || elementIndex === undefined) {
        return cy
          .getByTestId(tableTestId)
          .find(
            "tbody tr:nth-child(" +
              nthChildRow +
              ") th:nth-child(" +
              nthChildCol +
              ") button, tbody tr:nth-child(" +
              nthChildRow +
              ") th:nth-child(" +
              nthChildCol +
              ") a, tbody tr:nth-child(" +
              nthChildRow +
              ") td:nth-child(" +
              nthChildCol +
              ") button, tbody tr:nth-child(" +
              nthChildRow +
              ") td:nth-child(" +
              nthChildCol +
              ") a",
          );
      } else {
        return cy
          .getByTestId(tableTestId)
          .find(
            "tbody tr:nth-child(" +
              nthChildRow +
              ") th:nth-child(" +
              nthChildCol +
              ") button:nth-child(" +
              nthChildElement +
              "), tbody tr:nth-child(" +
              nthChildRow +
              ") th:nth-child(" +
              nthChildCol +
              ") a:nth-child(" +
              nthChildElement +
              "), tbody tr:nth-child(" +
              nthChildRow +
              ") td:nth-child(" +
              nthChildCol +
              ") button:nth-child(" +
              nthChildElement +
              "), tbody tr:nth-child(" +
              nthChildRow +
              ") td:nth-child(" +
              nthChildCol +
              ") a:nth-child(" +
              nthChildElement +
              ")",
          );
      }
    },
  );

  Cypress.Commands.add("testBreadcrumbs", (breadcrumbs) => {
    cy.getByTestId("breadcrumbs")
      .find("ul li")
      .then((items) => {
        expect(items.length).to.equal(breadcrumbs.length);
        for (let x = 0; x < breadcrumbs.length; x++) {
          expect(items[x]).to.contain.text(breadcrumbs[x]);
        }
      });
  });

  Cypress.Commands.add("testBrowserTitle", (titlePrefix) => {
    cy.title().should("eq", titlePrefix + " - Rules Designer");
  });

  Cypress.Commands.add("testHeaderAndFooter", (pageHeader, tagline) => {
    cy.get("h1[data-testid='appHeader']").contains("Rules Designer");
    cy.get("footer[data-testid='footer-component']")
      .should("exist")
      .contains("HealthEdge Software, Inc.");
    // testing for the build timestamp element here, but not actually checking the timestamp value
    cy.get("footer [data-testid='footer-timestamp']")
      .should("exist")
      .contains("Release:");

    if (pageHeader) {
      cy.getByTestId("pageHeader").contains(pageHeader);
    }

    // test for the client name
    cy.getByTestId("footer-client")
      .should("exist")
      .contains("Profile: healthedge");

    if (tagline && tagline.length > 0) {
      cy.getByTestId("tagline").contains(tagline);
    } else {
      cy.getByTestId("tagline").should("not.exist");
    }
  });

  Cypress.Commands.add("testMaximizeToggleButton", () => {
    cy.getByTestId("maximizeToggleBtn").should("exist").as("maximizeToggleBtn");
    cy.getByTestId("fullscreenWrapper").should("exist");
    cy.get(".fullscreen").should("not.exist");

    cy.get("@maximizeToggleBtn").click();
    cy.get(".fullscreen").should("exist");

    cy.get("@maximizeToggleBtn").click();
    cy.get(".fullscreen").should("not.exist");
  });

  Cypress.Commands.add("testNavbar", (activeItem, shouldBeEmpty) => {
    cy.getByTestId("headerNavBar-component").should("exist");

    if (shouldBeEmpty) {
      // there should not be a list of items in the nav bar for the dashboard screen (i.e., no links)
      cy.getByTestId("headerNavBar-component")
        .find("ul li")
        .should("not.exist");
    } else {
      cy.getByTestId("headerNavBar-component")
        .find("ul li")
        .then((items) => {
          expect(items[0]).to.contain.text(""); // Home icon
          expect(items[1]).to.contain.text("Configuration");
          expect(items[2]).to.contain.text("Designer");
          expect(items[3]).to.contain.text("Testing");
        });

      // test for the correct active link
      cy.getByTestId("headerNavBar-component")
        .find("ul li button.active")
        .contains(activeItem);

      // test navbar links
      if (activeItem === "Configuration") {
        cy.getByTestId("nav-menu-configuration").click();
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/configuration/bot']")
          .contains("Business Object Model");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/configuration/custom-objects']")
          .contains("Custom Objects");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/configuration/global-variables']")
          .contains("Global Variables");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/configuration/rule-management']")
          .contains("Rule Management");
      } else if (activeItem === "Designer") {
        cy.getByTestId("nav-menu-designer").click();
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/designer/main-flow']")
          .contains("Main Flow");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/designer/functions']")
          .contains("Functions");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/designer/rule-sets']")
          .contains("Rule Sets");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/designer/decision-tables']")
          .contains("Decision Tables");
      } else if (activeItem === "Testing") {
        cy.getByTestId("nav-menu-testing").click();
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/rule-testing/data']")
          .contains("Data Testing");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/rule-testing/graph']")
          .contains("Graph Testing");
        cy.getByTestId("headerNavBar-component")
          .find("ul li a[href='/rule-designer/rule-testing/test-cases']")
          .contains("Test Cases");
      }
    }
  });

  Cypress.Commands.add("testSidebar", (sidebarCategory, activeItem) => {
    let sidebarItems: string[];
    switch (sidebarCategory) {
      case "Configuration":
        sidebarItems = [
          "Business Object Model",
          // "Data Mapping",
          "Custom Objects",
          "Global Variables",
          "Rule Management",
        ];
        break;
      case "Designer":
        sidebarItems = [
          "Main Flow",
          "Functions",
          "Rule Sets",
          "Decision Tables",
        ];
        break;
      case "Testing":
        sidebarItems = ["Data Testing", "Graph Testing", "Test Cases"];
        break;
    }

    cy.getByTestId("sidebar")
      .find("ul li")
      .then((items) => {
        expect(items.length).to.equal(sidebarItems.length);
        for (let x = 0; x < sidebarItems.length; x++) {
          expect(items[x]).to.contain.text(sidebarItems[x]);
        }
      });

    // test for the correct active link
    cy.getByTestId("sidebar")
      .find("ul li[class^='styles_isActive']") // look for class with "startsWith" because react is adding random suffix at end
      .should("have.text", activeItem);
  });

  Cypress.Commands.add("testPageNotFound", (invalidDestUrl) => {
    Cypress.on("uncaught:exception", () => {
      return false;
    });
    cy.visit(invalidDestUrl);
    cy.url().should("include", "page-not-found");
  });

  Cypress.Commands.add("shouldWrapText", { prevSubject: true }, (subject) => {
    cy.wrap(subject).then(($el) => {
      const element = $el[0];
      const isWrapping = element.scrollWidth === element.clientWidth;
      expect(isWrapping).to.be.true;
    });
  });

  Cypress.Commands.add(
    "shouldNotWrapText",
    { prevSubject: true },
    (subject) => {
      cy.wrap(subject).then(($el) => {
        const element = $el[0];

        console.log("scrollWidth:", element.scrollWidth);
        console.log("clientWidth:", element.clientWidth);

        const isWrapping = element.scrollWidth <= element.clientWidth;
        expect(isWrapping).to.be.false;
      });
    },
  );
}

declare global {
  namespace Cypress {
    interface Chainable {
      clickTabByIndex(index: number, tabListTestId: string): Chainable<Element>;
      getByTestId(testId: string, ...args): Chainable<Element>;
      getGridCell(
        rowIndex: number,
        columnIndex: number,
        tableTestId?: string,
      ): Chainable<Element>;
      getGridRowButtonOrLink(
        rowIndex: number,
        columnIndex: number,
        elementIndex?: number,
        tableTestId?: string,
      ): Chainable<Element>;
      shouldWrapText(): Chainable<Element>;
      shouldNotWrapText(): Chainable<Element>;
      testBreadcrumbs(breadcrumbs: string[]): Chainable<void>;
      testBrowserTitle(titlePrefix: string): Chainable<void>;
      testHeaderAndFooter(
        pageHeader?: string,
        tagline?: string,
      ): Chainable<void>;
      testMaximizeToggleButton(): Chainable<void>;
      testNavbar(
        activeItem?: "Configuration" | "Designer" | "Testing",
        shouldBeEmpty?: boolean,
      ): Chainable<void>;
      testSidebar(
        sidebarCategory: "Configuration" | "Designer" | "Testing",
        activeItem: string,
      ): Chainable<void>;
      testPageNotFound(invalidDestUrl: string);
    }
  }
}
