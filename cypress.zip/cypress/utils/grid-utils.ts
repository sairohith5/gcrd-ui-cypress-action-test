/**
 * Tests the table by verifying the existence of the table container,
 * checking the column headers, and testing the first row of data.
 *
 * @param columnHeaders - An array of strings representing the column headers.
 * @param firstRowData - An array of data representing the first row of the table. Usually this would be a string array, but it can also be an object array if the column contains buttons, in which case pass in something like {"aria-label": "test aria label"}
 * @param tableTestId - Optional. The test ID of the table container. Defaults to "dataTableContainer".
 */
export function testTable(
  columnHeaders: (
    | string
    | { type: "button" | "checkbox"; ariaLabel: string }
  )[],
  rowData: any[] | "No results.",
  tableTestId?: string,
  tableCaption?: string,
  rowIndexToTest: number = 0,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  cy.getByTestId(tableTestId).should("exist");
  testHeader(columnHeaders, tableTestId);

  if (rowData === "No results.") {
    cy.getByTestId(tableTestId).find("tbody tr td").contains("No results.");
  } else {
    testRow(rowIndexToTest, rowData, tableTestId);
  }

  if (tableCaption) {
    cy.getByTestId(tableTestId)
      .find("div[data-testid='dataTableCaption'")
      .contains(tableCaption);
  }
}

/**
 * Tests the header of a table by comparing the column headers with the expected values.
 * @param columnHeaders - An array of strings representing the expected column headers.
 * @param tableTestId - The test ID of the table element.
 */
export function testHeader(
  columnHeaders: (
    | string
    | { type: "button" | "checkbox"; ariaLabel: string }
  )[],
  tableTestId: string,
) {
  const tableHeaderId = tableTestId
    ? tableTestId.replace("Container", "") + "Header"
    : "dataTableHeader";
  cy.getByTestId(tableHeaderId).should("exist");
  cy.getByTestId(tableHeaderId)
    .find("th")
    .then((items) => {
      expect(items.length).to.equal(columnHeaders.length);
      for (let x = 0; x < columnHeaders.length; x++) {
        if (typeof columnHeaders[x] === "string") {
          expect(items[x]).to.contain.text(columnHeaders[x] as string);
        } else if (
          typeof columnHeaders[x] === "object" &&
          columnHeaders[x]["type"] === "button"
        ) {
          // expect(items[x]).to.contain.text((columnHeaders[x] as any).text);
          expect(items[x].getElementsByTagName("button").item(0)).to.have.attr(
            "aria-label",
            columnHeaders[x]["ariaLabel"],
          );
        }
      }
    });
}

export type TestRowData =
  | string
  | string[]
  | {
      type: "email" | "button" | "icon" | "tags" | "link" | "checkbox";
      value?: string;
      screenReaderText?: string;
      tags?: string[];
      isChecked?: boolean;
      isDisabled?: boolean;
      tooltip?: string;
    };
/**
 * Tests a row in a table.
 * @param rowNum - The row number to test.
 * @param rowData - An array of data representing a row of the table. Usually this would be a string array, but it can also be an object array if the column contains buttons, in which case pass in something like {"aria-label": "test aria label"}
 * @param tableTestId - The test ID of the table. Defaults to "dataTableContainer".
 * @param reportMissingAriaLabel - Whether to report (via log statement) a missing aria-label attribute for button columns. Defaults to true.
 */
export function testRow(
  rowNum: number,
  rowData: (TestRowData | TestRowData[])[],
  tableTestId?: string,
  reportMissingAriaLabel = true,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChild = rowNum + 1; // nth-child is not zero-based, so add 1

  // test for one and only one th element (for a11y, there must be one col designated as the row header)
  cy.getByTestId(tableTestId)
    .find("tbody tr:first-child th[scope='row']")
    .then((items) => {
      expect(items.length).to.equal(
        1,
        "For a11y, there must be one column designated as the row header <th scope='row'>",
      );
    });

  cy.getByTestId(tableTestId)
    .find(
      "tbody tr:nth-child(" +
        nthChild +
        ") th, tbody tr:nth-child(" +
        nthChild +
        ") td",
    )
    .then((items) => {
      expect(items.length).to.equal(rowData.length);
      for (let x = 0; x < rowData.length; x++) {
        if (typeof rowData[x] === "object") {
          if (rowData[x]["type"] === "tags") {
            // this is a tags column... test for correct tags
            for (let y = 0; y < rowData[x]["tags"].length; y++) {
              expect(
                items[x].getElementsByClassName("tag-badge").item(y),
              ).to.contain.text(rowData[x]["tags"][y]);
            }
          } else if (Array.isArray(rowData[x])) {
            // this is an array of objects... test each object (e.g., multiple buttons in a column)
            // @ts-ignore
            for (let y = 0; y < rowData[x].length; y++) {
              if (rowData[x][y]["type"] === "button") {
                // this is a button column... test for correct aria-label
                expect(
                  items[x].getElementsByTagName("button").item(y),
                ).to.have.attr("aria-label", rowData[x][y]["value"]);
              } else {
                expect(items[x]).to.contain.text(rowData[x][y]);
              }
            }
          } else if (rowData[x]["type"] === "button") {
            // this is a button column... test for correct aria-label
            expect(
              items[x].getElementsByTagName("button").item(0),
            ).to.have.attr("aria-label", rowData[x]["value"]);
            // test for disabled state
            if (rowData[x]["isDisabled"]) {
              expect(
                items[x].getElementsByTagName("button").item(0),
              ).to.have.attr("disabled");
            } else {
              expect(
                items[x].getElementsByTagName("button").item(0),
              ).not.to.have.attr("disabled");
            }
          } else if (rowData[x]["type"] === "email") {
            if (items[x].textContent.indexOf("@") > 0) {
              // this is an email column... test for mailto
              expect(items[x].getElementsByTagName("a").item(0)).to.have.attr(
                "href",
                "mailto:" + rowData[x]["value"],
              );
            } else {
              // this is an email type column, but the value is not an email address
              expect(items[x]).to.contain.text(rowData[x]["value"]);
            }
          } else if (rowData[x]["type"] === "icon") {
            // this is an icon column... test for correct icon
            expect(items[x].getElementsByTagName("svg").item(0)).to.have.attr(
              "data-icon",
              rowData[x]["value"],
            );
            expect(
              items[x].getElementsByClassName("sr-only").item(0),
              "Icon column must have a sr-only text element.",
            ).to.have.text(rowData[x]["screenReaderText"]);
          } else if (rowData[x]["type"] === "link") {
            // this is a link column... test for correct href
            expect(items[x].getElementsByTagName("a").item(0)).to.have.attr(
              "href",
              rowData[x]["value"],
            );
          } else if (rowData[x]["type"] === "checkbox") {
            // this is a checkbox column... test for correct checked state
            if (rowData[x]["isChecked"]) {
              expect(
                items[x].getElementsByTagName("button").item(0),
              ).to.have.attr("aria-checked", "true");
            } else {
              expect(
                items[x].getElementsByTagName("button").item(0),
              ).to.have.attr("aria-checked", "false");
            }

            if (rowData[x].hasOwnProperty("isDisabled")) {
              if (rowData[x]["isDisabled"]) {
                expect(
                  items[x].getElementsByTagName("button").item(0),
                ).to.have.attr("disabled");
              } else {
                expect(
                  items[x].getElementsByTagName("button").item(0),
                ).not.to.have.attr("disabled");
              }
            }
          } else {
            // this is an unknown type
            cy.log("Unknown type: " + rowData[x]["type"]);
          }
        } else {
          if (
            reportMissingAriaLabel &&
            rowData[x] === "" &&
            items[x].getElementsByTagName("button").length > 0
          ) {
            cy.log(
              "You have passed in an empty string to test a grid column value... are there button(s) in this column? If so, consider passing in an object to test for the correct aria-label (e.g., { 'aria-label': 'delete function entryPointFn' })",
            );
          }

          // @ts-ignore test for correct string
          expect(items[x]).to.contain.text(rowData[x]);
        }
      }
    });
}

/**
 * Applies a filter to a table and tests the filtered results.
 *
 * @param filterText - The text to filter the table by.
 * @param rowDataAfter - The expected row data after filtering.
 * @param tableTestId - (Optional) The test ID of the table container element.
 */
export function testFilter(
  filterText: string,
  rowDataAfter: any[],
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const tableFilterTestId = tableTestId
    ? tableTestId.replace("Container", "") + "FilterInput"
    : "dataTableFilterInput";
  const tableFilterResetBtnId = tableTestId
    ? tableTestId.replace("Container", "") + "FilterResetBtn"
    : "dataTableFilterResetBtn";

  // save row 0 before filtering...
  let rowDataBefore = getRowData(0, tableTestId);

  cy.getByTestId(tableFilterTestId).should("exist");
  cy.getByTestId(tableFilterResetBtnId).should("not.exist");
  cy.getByTestId(tableFilterTestId).type(filterText);
  cy.wait(510); // wait for 500ms debounce

  cy.getByTestId(tableFilterTestId).should("have.value", filterText);
  cy.getByTestId(tableFilterResetBtnId).should("exist").contains("Reset");

  // test row data after filter:
  testRow(0, rowDataAfter, tableTestId);

  // reset filter and then test against the saved rowDataBefore
  cy.getByTestId(tableFilterResetBtnId).click();
  testRow(0, rowDataBefore, tableTestId, false);
}

export function testFilterShouldNotExist(tableTestId?: string) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  cy.getByTestId(tableTestId)
    .find("[data-testid='dataTableFilter']")
    .should("not.exist");
}

/**
 * Performs a test for sorting a table column in both ascending and descending order.
 *
 * @param columnIndexToSort - The index of the column to sort.
 * @param rowDataDescending - The expected row data when sorted in descending order.
 * @param rowDataAscending - The expected row data when sorted in ascending order.
 * @param tableTestId - (Optional) The test ID of the table container element.
 */
export function testSort(
  columnIndexToSort: number,
  rowDataDescending: any[],
  rowDataAscending: any[],
  defaultSort: "ascending" | "descending" | "none" = "none",
  tableTestId?: string,
  rowDataBeforeSort?: any[],
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChildColumnIndex = columnIndexToSort + 1; // nth-child is not zero-based, so add 1
  let rowDataBefore = rowDataBeforeSort
    ? rowDataBeforeSort
    : getRowData(0, tableTestId);

  // first col header click will sort ascending, then descending, then off
  const tableHeaderId = tableTestId
    ? tableTestId.replace("Container", "") + "Header"
    : "dataTableHeader";

  // check for default sort
  cy.getByTestId(tableHeaderId)
    .find("th:nth-child(" + nthChildColumnIndex + ")")
    .as("columnHeader");

  cy.get("@columnHeader").invoke("attr", "aria-sort").should("eq", defaultSort);

  // click it once for ascending:
  cy.get("@columnHeader").find("button").click();
  testRow(0, rowDataAscending, tableTestId);

  // click it again for descending:
  cy.get("@columnHeader").find("button").click();
  testRow(0, rowDataDescending, tableTestId);

  // click it again for no sort:
  cy.get("@columnHeader").find("button").click();
  testRow(0, rowDataBefore, tableTestId, false);
}

export function testColumnNotSortable(
  columnIndex: number,
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChildColumnIndex = columnIndex + 1; // nth-child is not zero-based, so add 1
  const tableHeaderId = tableTestId
    ? tableTestId.replace("Container", "") + "Header"
    : "dataTableHeader";
  cy.getByTestId(tableHeaderId)
    .find("th:nth-child(" + nthChildColumnIndex + ")")
    .as("columnHeader");
  cy.get("@columnHeader").find("button").should("not.exist");
  cy.get("@columnHeader").invoke("attr", "aria-sort").should("eq", "none");
}

export function testColumnVisibility(
  configurableColumns: string[],
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const tableColumnsMenuBtnTestId = tableTestId
    ? tableTestId.replace("Container", "") + "ColumnsMenuBtn"
    : "dataTableColumnsMenuBtn";
  const tableColumnsMenuId = tableTestId
    ? tableTestId.replace("Container", "") + "ColumnsMenu"
    : "dataTableColumnsMenu";

  cy.getByTestId(tableColumnsMenuBtnTestId).should("exist").click();
  cy.getByTestId(tableColumnsMenuId).should("exist");

  cy.getByTestId(tableColumnsMenuId)
    .find("div[role='menuitemcheckbox']")
    .then((items) => {
      expect(items.length).to.equal(configurableColumns.length);
      for (let x = 0; x < configurableColumns.length; x++) {
        expect(items[x].innerText.toLowerCase()).to.contain(
          configurableColumns[x].toLowerCase(),
        );
      }
    });

  cy.getByTestId(tableColumnsMenuBtnTestId).click({ force: true });
  cy.getByTestId(tableColumnsMenuId).should("not.exist");
}

export function toggleColumnVisibility(
  columnNameToHide: string,
  columnHeadersRemaining: string[],
  firstRowData?: (TestRowData | TestRowData[])[],
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const tableColumnsMenuBtnTestId = tableTestId
    ? tableTestId.replace("Container", "") + "ColumnsMenuBtn"
    : "dataTableColumnsMenuBtn";
  const tableColumnsMenuId = tableTestId
    ? tableTestId.replace("Container", "") + "ColumnsMenu"
    : "dataTableColumnsMenu";

  // uncheck the column:
  cy.getByTestId(tableColumnsMenuBtnTestId).click();
  cy.getByTestId(tableColumnsMenuId)
    .find("div[role='menuitemcheckbox']")
    .contains(columnNameToHide, { matchCase: false })
    .click();

  // verify column headers after hiding column
  testHeader(columnHeadersRemaining, tableTestId);
  cy.wait(100);

  // verify row data after toggling column
  if (firstRowData) {
    testRow(0, firstRowData, tableTestId);
  }

  // check the column again (i.e., reset it)
  cy.getByTestId(tableColumnsMenuBtnTestId).click();
  cy.getByTestId(tableColumnsMenuId)
    .find("div[role='menuitemcheckbox']")
    .contains(columnNameToHide, { matchCase: false })
    .click();

  cy.wait(100);
}

export function testPagination(
  rowCount: number,
  rowsDisplayed?: number,
  secondPageFirstRowValues?: string[],
  tableTestId?: string,
  defaultPageSize?: number,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  defaultPageSize = defaultPageSize ? defaultPageSize : 100;
  const paginationTestId = tableTestId
    ? tableTestId.replace("Container", "") + "Pagination"
    : "dataTablePagination";

  cy.getByTestId(paginationTestId).should("exist");

  // test for the correct number of rows in the table
  cy.getByTestId(paginationTestId + "RowCount")
    .should("exist")
    .contains(rowCount + " row(s) found.");

  cy.getByTestId(tableTestId)
    .find("tbody tr")
    .then((items) => {
      expect(items.length).to.equal(rowsDisplayed ? rowsDisplayed : rowCount);
    });

  // test the rows per page dropdown
  cy.getByTestId(paginationTestId + "RowsPerPageBtn").should("exist");
  cy.getByTestId(paginationTestId + "RowsPerPageBtn")
    .invoke("text")
    .then((selectedValue) => {
      expect(selectedValue).to.eq(defaultPageSize.toString());
      let rowsPerPageSelection = parseInt(selectedValue);
      let totalPages = Math.ceil(rowCount / rowsPerPageSelection);

      if (rowsPerPageSelection < rowCount) {
        // the data is paginated, so do some pagination testing...
        cy.getByTestId(paginationTestId + "FirstPageBtn").should(
          "have.attr",
          "disabled",
        );
        cy.getByTestId(paginationTestId + "PreviousPageBtn").should(
          "have.attr",
          "disabled",
        );
        cy.getByTestId(paginationTestId + "LastPageBtn").should(
          "not.have.attr",
          "disabled",
        );
        cy.getByTestId(paginationTestId + "NextPageBtn").should(
          "not.have.attr",
          "disabled",
        );

        // test the pagination buttons
        // next page
        cy.getByTestId(paginationTestId + "NextPageBtn").click();
        cy.wait(500);
        cy.getByTestId(paginationTestId + "PageNumInput").should(
          "have.value",
          "2",
        );
        cy.getByTestId(paginationTestId + "FirstPageBtn").click();
        cy.wait(500);
        // last page
        cy.getByTestId(paginationTestId + "LastPageBtn").click();
        cy.wait(500);
        cy.getByTestId(paginationTestId + "PageNumInput").should(
          "have.value",
          totalPages.toString(),
        );
        // previous page
        cy.getByTestId(paginationTestId + "PreviousPageBtn").click();
        cy.wait(250);
        cy.getByTestId(paginationTestId + "PageNumInput").should(
          "have.value",
          (totalPages - 1).toString(),
        );

        // test the "Page x of x" component
        cy.getByTestId(paginationTestId + "PageNumInput")
          .invoke("val", "")
          .type("2");
        cy.wait(500);
        cy.getByTestId(paginationTestId + "FirstPageBtn").should(
          "not.have.attr",
          "disabled",
        );
        cy.getByTestId(paginationTestId + "PreviousPageBtn").should(
          "not.have.attr",
          "disabled",
        );
        if (secondPageFirstRowValues) {
          testRow(0, secondPageFirstRowValues, tableTestId);
        }

        // first page
        cy.getByTestId(paginationTestId + "FirstPageBtn").click();
        cy.wait(500);
        cy.getByTestId(paginationTestId + "PageNumInput").should(
          "have.value",
          "1",
        );

        // TODO: test rows per page dropdown
      }
    });
}

/**
 * Clicks on a grid row button or link based on the provided row and column indices.
 *
 * @param rowIndex - The index of the row in the grid.
 * @param columnIndex - The index of the column in the grid.
 * @param elementIndex - (Optional) The index of the element within the grid cell. Defaults to 0. Use this if there are multiple buttons/links in the cell.
 * @param tableTestId - (Optional) The test ID of the table containing the grid. Defaults to undefined.
 */
export function clickGridRow(
  rowIndex: number,
  columnIndex: number,
  elementIndex?: number,
  tableTestId?: string,
) {
  cy.getGridRowButtonOrLink(
    rowIndex,
    columnIndex,
    elementIndex,
    tableTestId,
  ).click();
}

export function clickTableHeaderButton(
  columnIndex: number,
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChildColumnIndex = columnIndex + 1; // nth-child is not zero-based, so add 1
  const tableHeaderId = tableTestId
    ? tableTestId.replace("Container", "") + "Header"
    : "dataTableHeader";

  cy.getByTestId(tableHeaderId)
    .find("th:nth-child(" + nthChildColumnIndex + ")")
    .as("columnHeader");

  cy.get("@columnHeader").find("button").click();
}

export function isColumnChecked(
  rowNum: number,
  columnIndex: number,
  checkedState: "checked" | "unchecked" | "indeterminate",
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChild = rowNum + 1; // nth-child is not zero-based, so add 1
  const nthChildColumnIndex = columnIndex + 1; // nth-child is not zero-based, so add 1

  cy.getByTestId(tableTestId)
    .find(
      "tbody tr:nth-child(" +
        nthChild +
        ") td:nth-child(" +
        nthChildColumnIndex +
        ")",
    )
    .then((items) => {
      expect(items[0].getElementsByTagName("button").item(0)).to.have.attr(
        "data-state",
        checkedState,
      );
    });
}

export function isColumnHeaderChecked(
  columnIndex: number,
  checkedState: "checked" | "unchecked" | "indeterminate",
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChildColumnIndex = columnIndex + 1; // nth-child is not zero-based, so add 1
  const tableHeaderId = tableTestId
    ? tableTestId.replace("Container", "") + "Header"
    : "dataTableHeader";

  cy.getByTestId(tableHeaderId)
    .find("th:nth-child(" + nthChildColumnIndex + ")")
    .as("columnHeader");

  cy.get("@columnHeader")
    .find("button")
    .then((items) => {
      expect(items[0]).to.have.attr("data-state", checkedState);
    });
}

export function testColumnIcon(
  columnIndex: number,
  rowIndex: number,
  iconName: string,
  screenReaderText: string,
  tableTestId?: string,
) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChild = rowIndex + 1; // nth-child is not zero-based, so add 1
  const nthChildColumnIndex = columnIndex + 1; // nth-child is not zero-based, so add 1

  cy.getByTestId(tableTestId)
    .find(
      "tbody tr:nth-child(" +
        nthChild +
        ") td:nth-child(" +
        nthChildColumnIndex +
        ")",
    )
    .then((items) => {
      if (iconName === "") {
        expect(items[0].getElementsByTagName("svg").item(0)).to.be.null;
        expect(items[0].getElementsByClassName("sr-only").item(0)).to.be.null;
        return;
      }
      expect(items[0].getElementsByTagName("svg").item(0)).to.have.attr(
        "data-icon",
        iconName,
      );
      expect(items[0].getElementsByClassName("sr-only").item(0)).to.have.text(
        screenReaderText,
      );
    });
}

function getRowData(rowIndex: number, tableTestId?: string) {
  tableTestId = tableTestId ? tableTestId : "dataTableContainer";
  const nthChild = rowIndex + 1; // nth-child is not zero-based, so add 1

  let rowData: string[] = [];

  cy.getByTestId(tableTestId)
    .find(
      "tbody tr:nth-child(" +
        nthChild +
        ") th, tbody tr:nth-child(" +
        nthChild +
        ") td",
    )
    .then((items) => {
      for (let x = 0; x < items.length; x++) {
        // @ts-ignore
        rowData.push(items[x].textContent);
      }
    });

  return rowData;
}
