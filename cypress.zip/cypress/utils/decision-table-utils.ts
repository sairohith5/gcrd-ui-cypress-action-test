import { TestRowData, testRow, testTable } from "./grid-utils";
import { clickAnywhere } from "./utils";

export const NULL_DISPLAY = "NULL";
export const EMPTY_STRING_DISPLAY = "";

/**
 * Tests a decision table by verifying the column headers and the data of the first row.
 * @param columnHeaders - An array of strings representing the column headers of the decision table.
 * @param firstRowData - An array of any type representing the data of the first row in the decision table.
 */
export function testDecisionTable(
  columnHeaders: string[],
  firstRowData: any[],
  allowsSorting?: boolean,
) {
  testTable(columnHeaders, firstRowData, "decisionTable");
  cy.getByTestId("decisionTableHeader")
    .find("th")
    .each((th, index) => {
      if (allowsSorting) {
        cy.wrap(th).find("[data-testid='sortColumnBtn']").should("exist");
      } else {
        cy.wrap(th).find("[data-testid='sortColumnBtn']").should("not.exist");
      }
    });
}

/**
 * Tests the decision table header by verifying if the column headers match the expected values.
 * @param columnHeaders - An array of strings representing the expected column headers.
 */
export function testDecisionTableHeader(columnHeaders: string[]) {
  const tableHeaderId = "decisionTableHeader";
  cy.getByTestId(tableHeaderId)
    .should("exist")
    .find("th")
    .then((items) => {
      expect(items.length).to.equal(columnHeaders.length);
      for (let x = 0; x < columnHeaders.length; x++) {
        expect(items[x]).to.contain.text(columnHeaders[x]);
      }
    });
}

export function getDecisionTableHeader(columnIndex: number) {
  const nthChild = columnIndex + 1;

  return cy
    .getByTestId("decisionTableHeader")
    .find(`th:nth-child(${nthChild})`);
}

/**
 * Tests a decision table row has the expected row values.
 *
 * @param rowNum - The zero-based row index of the decision table.
 * @param rowData - The data for the row, either as an array of `TestRowData` objects or a 2D array of `TestRowData` objects.
 */
export function testDecisionTableRow(
  rowNum: number,
  rowData: TestRowData[] | TestRowData[][],
  testId?: string,
) {
  testRow(rowNum, rowData, testId ? testId : "decisionTable");
}

/**
 * Verifies the items in the context menu for a specific column in a decision table.
 *
 * @param columnNum - The zero-based index of the column to test the context menu for.
 * @param contextMenuItems - An array of strings representing the expected context menu items.
 */
export function testColumnContextMenu(
  columnNum: number,
  contextMenuItems: string[],
) {
  cy.wait(500); // trying to combat the timing issue where the columnContextMenu is not always found
  toggleColumnContextMenu(columnNum);

  cy.getByTestId("columnContextMenu")
    .find("div[role='menuitem']")
    .then((items) => {
      expect(items.length).to.equal(contextMenuItems.length);
      for (let x = 0; x < contextMenuItems.length; x++) {
        expect(items[x].innerText).to.contain(contextMenuItems[x]);
      }
    });

  clickAnywhere();
  cy.wait(100); // give time for the context menu to close
}

/**
 * Opens or closes the context menu for a specific column in the decision table.
 * @param columnNum - The zero-based index of the column to toggle the context menu for.
 */
export function toggleColumnContextMenu(columnNum: number) {
  columnNum = columnNum === 0 ? 0 : columnNum + 1;
  cy.getByTestId(`columnHeader${columnNum}`, { timeout: 10000 }).as(
    "columnHeader",
  );
  cy.wait(500); // trying to combat the timing issue where the columnContextMenu is not always found
  cy.get("@columnHeader", { timeout: 10000 })
    .find("[data-testid='cell-menu']")
    .click();
  cy.getByTestId("columnContextMenu").should("exist").should("be.visible"); //copilot suggestion instead of cy.wait()
}

/**
 * Clicks on a specific option in the context menu of a column.
 *
 * @param columnNum - The zero-based index of the column.
 * @param menuIndex - The zero-based index of the option in the context menu.
 */
export function clickColumnContextMenuOption(
  columnNum: number,
  menuIndex: number,
) {
  toggleColumnContextMenu(columnNum);
  cy.getByTestId("columnContextMenu")
    .find("div[role='menuitem']")
    .eq(menuIndex)
    .click();
  cy.wait(100);
}

/**
 * Tests the context menu for a specific row in a decision table.
 *
 * @param rowNum - The zero-based row index of the decision table.
 * @param contextMenuItems - An array of strings representing the expected context menu items.
 */
export function testRowContextMenu(rowNum: number, contextMenuItems: string[]) {
  toggleRowContextMenu(rowNum);

  cy.getByTestId("rowContextMenu")
    .find("div[role='menuitem']")
    .then((items) => {
      expect(items.length).to.equal(contextMenuItems.length);
      for (let x = 0; x < contextMenuItems.length; x++) {
        expect(items[x].innerText).to.contain(contextMenuItems[x]);
      }
    });

  clickAnywhere();
  cy.wait(100); // give time for the context menu to close
}

/**
 * Opens or closes the context menu for a specific row in the decision table.
 * @param rowNum - The zero-based index of the row to toggle the context menu for.
 */
export function toggleRowContextMenu(rowNum: number) {
  cy.getByTestId(`rowHeader${rowNum}`).as("rowHeader");
  cy.get("@rowHeader").find("[data-testid='cell-menu']").click();
}

/**
 * Clicks on a specific option in the context menu of a row.
 *
 * @param rowNum - The zero-based index of the row.
 * @param menuIndex - The zero-based index of the option in the context menu.
 */
export function clickRowContextMenuOption(rowNum: number, menuIndex: number) {
  toggleRowContextMenu(rowNum);
  cy.wait(100);
  cy.getByTestId("rowContextMenu")
    .find("div[role='menuitem']")
    .eq(menuIndex)
    .click();
  cy.wait(500);
}

/**
 * Returns a specific button in a decision table cell.
 *
 * @param rowNum - The zero-based row index.
 * @param colNum - The zero-based column index.
 * @param button - The optional button label to click on in the cell.
 */
export function getTableCellButton(
  rowNum: number,
  colNum: number,
  button?: "Cancel" | "Edit" | "Delete" | "Apply",
) {
  colNum = colNum + 1; // needed to account for the hidden first column
  return button
    ? cy.get(
        `[data-testid='decisionTableCell-${rowNum}-${colNum}'] button[aria-label=${button}]`,
      )
    : cy.get(
        `[data-testid='decisionTableCell-${rowNum}-${colNum}'] button[type='button']`,
      );
}

/**
 * Clicks on a specific cell in the decision table.
 *
 * @param rowNum - The zero-based row index.
 * @param colNum - The zero-based column index.
 * @param button - The optional button label to click on in the cell.
 */
export function clickTableCellButton(
  rowNum: number,
  colNum: number,
  button?: "Cancel" | "Edit" | "Delete" | "Apply",
) {
  cy.wait(500);
  getTableCellButton(rowNum, colNum, button)
    .should("exist")
    .scrollIntoView()
    .click();
  cy.wait(500);
}

/**
 * Returns a specific cell in the decision table.
 *
 * @param rowIndex - The zero-based row index.
 * @param colIndex - The zero-based column index.
 */
export function getTableCell(rowIndex: number, colIndex: number) {
  colIndex = colIndex + 1; // needed to account for the hidden first column
  return cy.get(`[data-testid^='decisionTableCell-${rowIndex}-${colIndex}']`);
}

/**
 * Tests a decision table cell form field.
 * @param formFieldName - The name of the form field.
 * @param ariaLabel - The ARIA label of the form field.
 * @param options - Additional options for testing the form field.
 * @param options.isCheckbox - Specifies whether the form field is a checkbox.
 * @param options.expectedSelectOptions - An array of expected select options.
 * @param options.numSelectOptionsToTest - The number of select options to test.
 * @param options.defaultValue - The default value of the form field.
 */
export function testDecisionTableCellFormField(
  formFieldName: string,
  ariaLabel: string,
  options?: {
    isCheckbox?: boolean;
    expectedSelectOptions?: string[];
    numSelectOptionsToTest?: number;
    defaultValue?: string;
  },
) {
  cy.getByTestId(formFieldName).as("formField");
  cy.get("@formField")
    .should("exist")
    .should("have.attr", "aria-label", ariaLabel);

  // verify default value
  if (options?.defaultValue && !options?.expectedSelectOptions) {
    cy.getByTestId(formFieldName).should("have.value", options.defaultValue);
  }

  // test that the expected select options are present
  if (options?.expectedSelectOptions) {
    cy.getByTestId(formFieldName)
      .find("option")
      .then((actualOptions) => {
        const numToValidate = options.numSelectOptionsToTest
          ? options.numSelectOptionsToTest
          : actualOptions.length;
        for (let x = 0; x < numToValidate; x++) {
          expect(actualOptions[x]).to.contain.text(
            // @ts-ignore
            options.expectedSelectOptions[x],
          );

          if (options.defaultValue === options.expectedSelectOptions[x]) {
            cy.log("actualOptions[x]", actualOptions[x]);
            cy.wrap(actualOptions[x]).should("have.attr", "selected");
          }
        }
      });
  }
}

export function testArrayCellMenuOptions(
  rowNum: number,
  colNum: number,
  arrayCellIndex: number,
  options: string[],
) {
  clickArrayCellButton(rowNum, colNum, "Menu", arrayCellIndex);
  cy.getByTestId("arrayCellContextMenu")
    .find("div[role='menuitem']")
    .then((items) => {
      expect(items.length).to.equal(options.length);
      for (let x = 0; x < options.length; x++) {
        expect(items[x].innerText).to.contain(options[x]);
      }
    });
  clickAnywhere();
  cy.wait(100); // give time for the context menu to close
}

/**
 * Returns a specific array cell in the decision table.
 * @param rowNum - The zero-based row index.
 * @param colNum - The zero-based column index.
 * @param button - The optional button label to click on in the cell.
 * @param arrayCellIndex - The zero-based index of the array cell.
 * @returns - the button element
 */
export function clickArrayCellButton(
  rowNum: number,
  colNum: number,
  button?: "Cancel" | "Apply" | "Edit" | "Menu",
  arrayCellIndex?: number,
) {
  getTableCell(rowNum, colNum).as("tableCell");

  if (button === "Edit" || button === "Menu") {
    cy.get("@tableCell")
      .find("li")
      .eq(arrayCellIndex)
      .find("button")
      .as("arrayCellButton");
  } else {
    cy.get("@tableCell")
      .find("li")
      .eq(arrayCellIndex)
      .find(`button[aria-label='${button}']`)
      .as("arrayCellButton");
  }

  cy.get("@arrayCellButton").should("exist").scrollIntoView();
  cy.get("@arrayCellButton").click();
}

export function filterDecisionTable(filterText: string) {
  cy.getByTestId("decisionTableFilterInput").type(filterText);
  cy.wait(1500);
}

export function clearDecisionTableFilter() {
  cy.getByTestId("decisionTableFilterResetBtn").click();
  cy.wait(500);
}

export function insertRowBelow(rowIndex: number) {
  if (rowIndex === 0) {
    toggleColumnContextMenu(0);
    cy.getByTestId("columnContextMenu")
      .find("button[data-testid='add-row-menu-item']")
      .click();
  } else {
    toggleRowContextMenu(rowIndex - 1);
    cy.getByTestId("rowContextMenu")
      .find("button[data-testid='add-row-menu-item']")
      .click();
  }
}

export function deleteRow(rowIndex: number) {
  toggleRowContextMenu(rowIndex);
  cy.getByTestId("rowContextMenu")
    .find("button[data-testid='delete-row-menu-item']")
    .click();
}

export function insertColumnRight(colIndex: number, varName?: string) {
  varName = varName ? varName : "test_col";
  const displayName = varName ? varName : "test_display";

  toggleColumnContextMenu(colIndex);
  cy.getByTestId("columnContextMenu")
    .find("button[data-testid='add-column-menu-item']")
    .click();

  cy.wait(500);

  // just create a string column with default values
  cy.getByTestId("varNameInput").type(varName);
  cy.getByTestId("displayNameInput").type(displayName);
  cy.getByTestId("dialog-submit-button").should("exist").click();
  cy.wait(300);
}

export function deleteColumn(colIndex: number) {
  toggleColumnContextMenu(colIndex);
  cy.getByTestId("columnContextMenu")
    .find("button[data-testid='delete-column-menu-item']")
    .click();
  cy.wait(100);
}

export function testNumRowsInDecisionTable(numRows: number) {
  if (numRows === 0) {
    cy.getByTestId("decisionTable").find("tbody tr").should("have.length", 1);

    cy.getByTestId("decisionTable")
      .find("tbody tr")
      .should("contain.text", "No results.");
    return;
  }
  cy.getByTestId("decisionTable")
    .find("tbody tr")
    .should("have.length", numRows);
}

export function testCellConditionTooltip(
  row: number,
  col: number,
  displayName: string,
  expression: string,
) {
  cy.get(
    `[data-testid='decisionTableCell-${row}-${col}'] button[data-testid='cell-augmentation-trigger']`,
  ).as("cellConditionBtn");
  cy.get("@cellConditionBtn").focus();
  cy.getByTestId("cell-augmentation-tooltip").should("be.visible");
  cy.getByTestId("cell-augmentation-tooltip")
    .find("[data-testid='cell-augmentation-display-name']")
    .should("exist")
    .should("include.text", displayName);
  cy.getByTestId("cell-augmentation-tooltip")
    .find("[data-testid='cell-augmentation-expression']")
    .should("exist")
    .should("include.text", expression);
}

/**
 * Tests if all rows in a specific column have the default condition applied.
 * @param columnIndex - The column index to test (0-based)
 * @param expectedDefaultConditionText - The expected default condition display name
 * @param totalRows - Total number of rows to check (optional, defaults to checking all visible rows)
 */
export function testColumnHasDefaultConditions(
  columnIndex: number,
  expectedDefaultConditionText: string,
  totalRows?: number,
) {
  // If totalRows is not provided, get the count from the visible table rows
  if (!totalRows) {
    cy.get(
      '[data-testid^="decisionTableCell-"][data-testid$="-' +
        columnIndex +
        '"]',
    )
      .its("length")
      .then((rowCount) => {
        checkRowsForDefaultCondition(
          columnIndex,
          expectedDefaultConditionText,
          rowCount,
        );
      });
  } else {
    checkRowsForDefaultCondition(
      columnIndex,
      expectedDefaultConditionText,
      totalRows,
    );
  }
}

/**
 * Helper function to check each row for the default condition
 * @param columnIndex - The column index to test
 * @param expectedDefaultConditionText - The expected default condition display name
 * @param rowCount - Number of rows to check
 */
function checkRowsForDefaultCondition(
  columnIndex: number,
  expectedDefaultConditionText: string,
  rowCount: number,
) {
  for (let rowIndex = 0; rowIndex < rowCount; rowIndex++) {
    cy.get(`[data-testid='decisionTableCell-${rowIndex}-${columnIndex}']`)
      .should("exist")
      .within(() => {
        // Check if the cell has a cell augmentation button (indicates a condition is applied)
        cy.get('[data-testid="cell-augmentation-trigger"]')
          .should("exist")
          .focus();

        // Verify the tooltip shows the expected default condition
        cy.getByTestId("cell-augmentation-tooltip")
          .should("be.visible")
          .within(() => {
            cy.get('[data-testid="cell-augmentation-display-name"]')
              .should("exist")
              .should("include.text", expectedDefaultConditionText);
          });
      });
  }
}

/**
 * Tests if a specific cell has the default condition applied.
 * @param rowIndex - The row index (0-based)
 * @param columnIndex - The column index (0-based)
 * @param expectedDefaultConditionText - The expected default condition display name
 */
export function testCellHasDefaultCondition(
  rowIndex: number,
  columnIndex: number,
  expectedDefaultConditionText: string,
) {
  cy.get(`[data-testid='decisionTableCell-${rowIndex}-${columnIndex}']`)
    .should("exist")
    .within(() => {
      // Check if the cell has a cell augmentation button (indicates a condition is applied)
      cy.get('[data-testid="cell-augmentation-trigger"]')
        .should("exist")
        .focus();

      // Verify the tooltip shows the expected default condition
      cy.getByTestId("cell-augmentation-tooltip")
        .should("be.visible")
        .within(() => {
          cy.get('[data-testid="cell-augmentation-display-name"]')
            .should("exist")
            .should("include.text", expectedDefaultConditionText);
        });
    });
}

export function verifyDecisionTableIsReadonly(
  isRuleMgmtTable: boolean = false,
) {
  // verify save button is either disabled or not displayed
  cy.get("body").then(($body) => {
    const selector = "[data-testid='saveBtn']";
    const btn = $body.find(selector);
    if (btn.length) {
      cy.wrap(btn).should("be.disabled");
    } else {
      expect(btn.length).to.eq(0);
    }
  });

  cy.get("body").then(($body) => {
    const moreBtn = $body.find("[data-testid='nav-menu-more']");
    if (moreBtn.length) {
      cy.wrap(moreBtn).click();
    }
    // verify Delete button is not displayed
    cy.getByTestId("deleteArtifactBtn").should("not.exist");
    // verify Import button is not displayed
    cy.getByTestId("importFileBtn").should("not.exist");
  });

  //should not display the column context menu
  getDecisionTableHeader(1)
    .find("button[data-testid='cell-menu'][aria-label='cell options']")
    .should("exist")
    .should("not.be.visible");

  // should not display the row context menu
  if (!isRuleMgmtTable) {
    cy.getByTestId(`rowHeader${1}`).as("rowHeader");
    cy.getByTestId("row-context-menu").should("not.exist");
  }

  // should not allow editing of cells
  getTableCellButton(0, 0, "Edit").should("not.exist");
}
