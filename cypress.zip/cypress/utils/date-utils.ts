import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";

dayjs.extend(relativeTime);
dayjs.extend(utc);
dayjs.extend(timezone);

/**
 * Returns a relative date string (e.g. "2 years ago", "5 days ago", etc.) based on the given date.
 * @param date - The date to calculate the relative date from.
 * @returns A string representing the relative date.
 */
export function getRelativeDate(date: string): string {
  return date ? dayjs(date).fromNow() : "";
}

export function getRelativeDateFromEpoch(epoch: number): string {
  return epoch ? dayjs(epoch).fromNow() : "";
}

export function getLocalDateTime(
  date: string | number,
  format?: string,
): string {
  format = format || "MM/DD/YYYY HH:mm";
  return date ? dayjs(date).format(format) : "";
}

/**
 * Formats a given date for the browser's current timezone in the expected test format.
 * This utility helps avoid timezone-related test failures when running tests in different environments.
 *
 * @param year - The year
 * @param month - The month (1-12)
 * @param day - The day of the month
 * @param hour - The hour (0-23)
 * @param minute - The minute (0-59)
 * @returns A formatted date string like "Thursday, August 7th 2025, 3:26 pm"
 */
export function getTimezoneAwareDateTimeString(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
): string {
  // Get the browser's timezone
  const browserTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  // Create a date object and format it for the browser's timezone
  const date = dayjs()
    .year(year)
    .month(month - 1) // dayjs months are 0-indexed
    .date(day)
    .hour(hour)
    .minute(minute)
    .second(0)
    .millisecond(0);

  // Format the date to match the expected format in tests
  const dayName = date.format("dddd");
  const monthName = date.format("MMMM");
  const dayWithSuffix = getDayWithSuffix(day);
  const yearStr = date.format("YYYY");
  const timeStr = date.format("h:mm a");

  return `${dayName}, ${monthName} ${dayWithSuffix} ${yearStr}, ${timeStr}`;
}

/**
 * Helper function to get the day with proper suffix (1st, 2nd, 3rd, 4th, etc.)
 * @param day - The day of the month
 * @returns The day with appropriate suffix
 */
function getDayWithSuffix(day: number): string {
  if (day >= 11 && day <= 13) {
    return `${day}th`;
  }

  const lastDigit = day % 10;
  switch (lastDigit) {
    case 1:
      return `${day}st`;
    case 2:
      return `${day}nd`;
    case 3:
      return `${day}rd`;
    default:
      return `${day}th`;
  }
}

/**
 * Predefined timezone-aware date strings for common test dates.
 * These can be used in tests instead of hardcoded strings.
 */
export const TIMEZONE_AWARE_TEST_DATES = {
  AUGUST_17_2025_2_27_PM: getTimezoneAwareDateTimeString(2025, 8, 17, 14, 27),
  AUGUST_17_2025_3_27_PM: getTimezoneAwareDateTimeString(2025, 8, 17, 15, 27),
  AUGUST_7_2025_2_26_PM: getTimezoneAwareDateTimeString(2025, 8, 7, 14, 26),
  AUGUST_7_2025_3_26_PM: getTimezoneAwareDateTimeString(2025, 8, 7, 15, 26),
};
