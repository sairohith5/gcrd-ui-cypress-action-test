//Add these below constants to the node co-ordinates in mouse events calls to make sure the node can receive the mouse events
export const NODE_X = 120;
export const NODE_Y = 100;
