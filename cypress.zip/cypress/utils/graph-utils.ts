import "@4tw/cypress-drag-drop";
import { NODE_X, NODE_Y } from "./constants";
export enum nodes {
  Start = "START",
  If = "IF",
  For = "FOR",
  Action = "ACTION",
  Table = "DECISIONTABLE",
  Code = "CODE",
  Object = "OBJECT",
  Return = "RETURN",
  Invoke = "INVOKE",
  SwitchCase = "SWITCH_CASE",
}

const nodePaletteNodes = [
  { name: "IF" },
  { name: "FOR" },
  { name: "CODE" },
  { name: "ACT" },
  { name: "OBJ" },
  { name: "INVOKE" },
  { name: "DT" },
  { name: "SWC" },
  { name: "RET" },
];
/**
 * @param graphCanvasTestId - The test ID of the graph canvas element.
 */
export function testStartNode(graphCanvasTestId: string) {
  cy.wait(1000);
  cy.getByTestId(graphCanvasTestId).should("exist");
  testNodePalette();
  testGraphToolBar();

  testMaximizeMinimizeGraph();
}

/**
 * Tests the Node Palette of a graph by comparing the node names with the expected values.
 */
export function testNodePalette() {
  cy.getByTestId("nodePalette").should("exist");

  cy.getByTestId("nodePalette")
    .find("div span")
    .then((items) => {
      expect(items.length).to.equal(nodePaletteNodes.length);
      for (let x = 0; x < nodePaletteNodes.length; x++) {
        expect(items[x]).to.contain.text(nodePaletteNodes[x].name);
      }
    });
}

/**
 * Tests the Graph ToolBar Button exists or not .
 */
export function testGraphToolBar() {
  cy.getByTestId("nav-menu-more").should("exist");
  cy.getByTestId("graph-toolbar").should("exist");
  cy.getByTestId("saveGraphButton").should("exist");
  cy.getByTestId("undoButton").should("exist");
  cy.getByTestId("redoButton").should("exist");
  cy.getByTestId("arrangeButton").should("exist");
  // cy.getByTestId("modeChangeButton").should("exist");
}

/**
 * Tests the Graph ToolBar "Switch to light mode / dark mode" Button functionality.
 */
export function testModeSwitch() {
  cy.getByTestId("graphScreen").should("exist");
  cy.getByTestId("graphScreen").should("exist").and("have.class", "dark");
  cy.getByTestId("graphScreen").should("exist").and("not.have.class", "dark");
}

/**
 * Tests the Graph ToolBar "Maximize content" Button functionality.
 */
export function testMaximizeMinimizeGraph() {
  cy.getByTestId("graphScreen").should("exist");
  cy.getByTestId("maximizeToggleBtn").should("exist");
  cy.getByTestId("maximizeToggleBtn").click({ force: true });
  cy.get(".fullscreen").should("exist");
  cy.getByTestId("maximizeToggleBtn").click({ force: true });
  cy.get(".fullscreen").should("not.exist");
}
/**
 * Tests the Graph ToolBar "Switch to light mode / dark mode" Button functionality.
 */

/**
 * compares two canvases Image data.
 */
function compareCanvasImageData(data1, data2) {
  if (data1.length !== data2.length) return false;

  data1.forEach((element, index) => {
    if (element !== data2[index]) return false;
  });
  return true;
}

/**
 * custom function to check for Text in the canvas
 * check the passed node text exists in canvas or not.
 * check the node shape is drawn as expected
 */
export function checkForTextInCanvas(imageData, text, ctx) {
  //create offscreen canvas
  const offscreenCanvas = document.createElement("canvas");
  offscreenCanvas.width = imageData.width;
  offscreenCanvas.height = imageData.height;
  const offscreenCtx = offscreenCanvas.getContext("2d");

  //Draw a text on the off-screen canvas
  offscreenCtx.font = ctx.font;
  offscreenCtx.fillText(text, 10, 50);

  const offscreenImageData = offscreenCtx.getImageData(
    0,
    0,
    offscreenCanvas.width,
    offscreenCanvas.height,
  );
  return compareCanvasImageData(imageData.data, offscreenImageData.data);
}

/**
 * Tests the passed Node drag and drop from Node Palette in Graph .
 */
export function dragNodeFromPalette(node) {
  cy.getByTestId(`${node.toLowerCase()}-shape`).should("exist");
  cy.wait(1000);
  const draggable = `${node.toLowerCase()}-shape`;
  cy.getByTestId(draggable).trigger("mousedown", {
    which: 1,
    pageX: 100,
    pageY: 100,
  });

  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    const ctx = canvas.getContext("2d");
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const nodeExists = checkForTextInCanvas(imageData, node, ctx);

    cy.wrap(canvas).trigger("mousemove", {
      focus: true,
      x: 700,
      y: 200,
    });
    cy.wrap(canvas).trigger("mousedown", {
      focus: true,
      x: 700,
      y: 200,
    });

    expect(nodeExists).to.be.true;

    cy.wrap(canvas).trigger("mouseup", {
      focus: true,
      x: 700,
      y: 200,
    });
  });
}

/**
 * Tests the onclick of properties panel opend or not.
 */
export function openPropertiesPanel(nodeDetails) {
  cy.wait(1000);
  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    cy.wrap(canvas).trigger("mousemove", {
      x: nodeDetails.x,
      y: nodeDetails.y,
      force: true,
    });
    cy.wait(200);
    cy.wrap(canvas).trigger("mousemove", {
      x: nodeDetails.x,
      y: NODE_Y,
      force: true,
    });
    cy.wrap(canvas).trigger("mouseup", {
      x: nodeDetails.x,
      y: NODE_Y,
      force: true,
    });
    cy.wrap(canvas).dblclick(nodeDetails.x, nodeDetails.y);
    cy.wait(2000);
    cy.getByTestId("propertiesPanel").should("exist");
    cy.once("uncaught:exception", () => false);
  });
}

export function checkAllFieldsInPropertiesPanel(
  nodeDetails,
  expectReturnExpression = true,
) {
  cy.getByTestId("nodeTypeItem").should("exist");
  cy.getByTestId("nodeTypeInput").should("exist");
  cy.getByTestId("nodeTypeInput").should("exist").should("be.disabled");
  cy.getByTestId("nodeTypeInput").should("have.value", nodeDetails.type);

  cy.getByTestId("nodeNameInput").should("exist");
  cy.getByTestId("nodeNameInput").should("exist").should("not.be.disabled");
  cy.getByTestId("nodeNameInput").should("have.value", nodeDetails.name);

  cy.getByTestId("varDescriptionTextArea").should("exist");
  cy.getByTestId("varDescriptionTextArea")
    .should("exist")
    .should("not.be.disabled");
  cy.wait(2000);
  if (nodeDetails.type === nodes.If) {
    cy.getByTestId("ifConditionLabel").should("exist");
    cy.get(".monaco-editor").should("exist");
  }
  if (nodeDetails.type === nodes.Code) {
    cy.getByTestId("codeExpressionLabel").should("exist");
    cy.get(".monaco-editor").should("exist");
  }
  if (nodeDetails.type === nodes.Return) {
    cy.getByTestId("swcRetExpression").should(
      expectReturnExpression ? "exist" : "not.exist",
    );
    cy.get(".monaco-editor").should(
      expectReturnExpression ? "exist" : "not.exist",
    );
  }
  if (nodeDetails.type === nodes.Table) {
    cy.getByTestId("tableCondition").should("exist");
    cy.getByTestId("varNameLabel").should("exist");
    cy.get(".monaco-editor").should("exist");
  }
  if (nodeDetails.type === nodes.For) {
    cy.getByTestId("forSourceLabel").should("exist");
    cy.get('div[class^="monaco-editor"]').should("exist");

    cy.getByTestId("varTypeLabel").should("exist");
    cy.getByTestId("varTypeInput").should("exist").should("not.be.disabled");

    cy.getByTestId("varNameLabel").should("exist");
    cy.getByTestId("varNameInput").should("exist").should("not.be.disabled");

    cy.getByTestId("forConditionLabel").should("exist");
    cy.get('div[class^="monaco-editor"]').should("exist");
  }
  if (nodeDetails.type === nodes.Action || nodeDetails.type === nodes.Object) {
    cy.getByTestId("varTypeLabel").should("exist");
    cy.getByTestId("varTypeInput").should("exist").should("not.be.disabled");
    cy.getByTestId("varTypeInput").should("not.have.a.property", "RuleInfo");
    cy.getByTestId("varNameLabel").should("exist");
    cy.getByTestId("varNameInput").should("exist").should("not.be.disabled");

    cy.getByTestId("assignTargetLabel").should("exist");
    cy.get('div[class^="monaco-editor"]').should("exist");

    cy.getByTestId("actionFieldsAccordian").should("exist");
  }
  if (nodeDetails.type === nodes.Invoke) {
    cy.getByTestId("invokeTargetLabel").should("exist");
    cy.getByTestId("invokeTargetInput")
      .should("exist")
      .should("not.be.disabled");
  }
}

/**
 * delete the passed node fromgraph
 */
export function deleteNodeFromGraph(nodeDetails) {
  cy.wait(2000);
  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    const context = canvas.getContext("2d");
    const imageData = context.getImageData(
      nodeDetails.x,
      nodeDetails.y,
      1,
      1,
    ).data;
    expect(imageData[0]).to.equal(30);
    expect(imageData[1]).to.equal(113);
    expect(imageData[2]).to.equal(55);
    expect(imageData[3]).to.equal(255);
    cy.wrap(canvas).trigger("mousemove", {
      focus: true,
      x: nodeDetails.x,
      y: nodeDetails.y,
    });
    cy.wrap(canvas).rightclick(nodeDetails.x, nodeDetails.y);
    cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
    cy.getByTestId("deleteNode").click();
    expect(imageData[0]).to.equal(30);
    expect(imageData[1]).to.equal(113);
    expect(imageData[2]).to.equal(55);
    expect(imageData[3]).to.equal(255);
  });
}

/**
 * Tests the Properties Panel opening for passed node and check the correct values are selected or not.
 */
export function checkPropertiesPanelandNodeValues(
  node,
  expectReturnExpression = true,
) {
  cy.getByTestId(`${node.name.toLowerCase()}-shape`).should("exist");
  cy.wait(1000);
  const draggable = `${node.name.toLowerCase()}-shape`;
  cy.getByTestId(draggable).trigger("mousedown", {
    which: 1,
    pageX: 100,
    pageY: 100,
  });

  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];

    cy.wrap(canvas).trigger("mousemove", {
      x: 470 + NODE_X,
      y: 80 + NODE_Y,
      force: true,
    });
    cy.wait(200);
    cy.wrap(canvas).trigger("mousemove", {
      x: 570 + NODE_X,
      y: NODE_Y,
      force: true,
    });
    cy.wrap(canvas).trigger("mouseup", {
      x: 570 + NODE_X,
      y: NODE_Y,
      force: true,
    });
    cy.wrap(canvas).dblclick(570 + NODE_X, NODE_Y + 50);
    cy.wait(2000);
    cy.getByTestId("propertiesPanel").should("exist");
    cy.wait(3000);
    cy.once("uncaught:exception", () => false);
    checkAllFieldsInPropertiesPanel(node, expectReturnExpression);
  });
}

/**
 * Tests the Properties Panel Apply button functionality for passed node and check
 */
export function checkPropertiesPanelApplyButton(node) {
  cy.getByTestId(`${node.name.toLowerCase()}-shape`).should("exist");
  cy.wait(1000);
  const draggable = `${node.name.toLowerCase()}-shape`;
  cy.getByTestId(draggable).trigger("mousedown", {
    which: 1,
    pageX: 100,
    pageY: 100,
  });

  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    cy.wrap(canvas).trigger("mousemove", {
      x: 470 + NODE_X,
      y: 80 + NODE_Y,
      force: true,
    });
    cy.wait(200);
    cy.wrap(canvas).trigger("mousemove", {
      x: 570 + NODE_X,
      y: NODE_Y,
      force: true,
    });
    cy.wrap(canvas).trigger("mouseup", {
      x: 570 + NODE_X,
      y: NODE_Y,
      force: true,
    });
    cy.wrap(canvas).dblclick(570 + NODE_X, NODE_Y + 50);
    cy.wait(2000);
    cy.getByTestId("propertiesPanel").should("exist");
    cy.wait(3000);
    cy.once("uncaught:exception", () => false);
  });
}

export function verifyGraphContent(nodeDetails) {
  cy.wait(1000);
  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    const context = canvas.getContext("2d");
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;

    //verify text on canvas
    if (nodeDetails.name) {
      context.font = "bold 12px Arial";
      const actualTextWidth = context.measureText(nodeDetails.name).width;
      expect(actualTextWidth).to.be.greaterThan(0);
    }

    //verify shape on canvas
    if (nodeDetails.type) {
      const imageData = context.getImageData(
        nodeDetails.x,
        nodeDetails.y,
        canvasWidth,
        canvasHeight,
      );
      const isShapePresent = Array.from(imageData.data).some(
        (pixel) => pixel !== 0,
      );
      expect(isShapePresent).to.be.true;
    }
  });
}

export function deleteNodefromDesigner(
  posX: number,
  posY: number,
  isNodeAndSubTree?: boolean,
) {
  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    const startNodeX = posX + NODE_X;
    const startNodeY = posY + NODE_Y;
    cy.wrap(canvas).rightclick(startNodeX, startNodeY);
    cy.getByTestId("deleteNodeButton").should("exist").trigger("mouseover");
    isNodeAndSubTree
      ? cy.getByTestId("deleteNodeAndSubTree").should("exist").click()
      : cy.getByTestId("deleteNode").should("exist").click();
  });
}

export const getLatestNodesDataFromSessionStorage = (): any => {
  let nodesData = [];
  if (window) {
    nodesData = JSON.parse(window.sessionStorage.getItem("nodes"));
  }
  return nodesData;
};

export const getCopiedNodesFromLocalStorage = (): any => {
  let nodesData = [];
  if (window) {
    nodesData = JSON.parse(window.localStorage.getItem("copiedNode"));
  }
  return nodesData;
};

export const getParentNode = (currentNode, allNodes): any => {
  return allNodes?.find(
    (node) => node?.id === currentNode?.connections?.input?.connectedTo,
  );
};

export const getBranchOrder = (currentNode, parentNode): any => {
  return parentNode?.connections?.outputs?.find(
    (output) => output?.connectedTo === currentNode?.id,
  )?.order;
};

export function addCalculationVariable(isNew: boolean = true) {
  cy.getByTestId("calculationVariableAccordian").should("exist");
  cy.getByTestId("calculationVariableAccordian").scrollIntoView();
  if (isNew) {
    cy.getByTestId("calculationVariableAccordian").click();
  }
  cy.wait(500);
  cy.getByTestId("addGlobalVariableBtn").should("exist");
  cy.getByTestId("addGlobalVariableBtn").scrollIntoView();
  cy.getByTestId("addGlobalVariableBtn").click();
  cy.wait(1000);
  cy.getByTestId("dialog-cancel-button")
    .should("exist")
    .should("not.be.disabled");

  //Name
  cy.getByTestId("varNameLabel").should("contain.text", "Name");
  cy.getByTestId("varNameInput").should("exist");
  cy.getByTestId("varNameInput").type("testName");
  //Type
  cy.getByTestId("varTypeLabel").should("contain.text", "Type");
  cy.getByTestId("varTypeInput").should("exist");
  cy.getByTestId("varTypeInput").select("ActActivity");
  cy.getByTestId("arrayInput").should("exist");
  cy.getByTestId("arrayInput").click();
  cy.get("select").invoke("val");

  cy.getByTestId("initExprField").should("exist");
  cy.getByTestId("initExprField")
    .find(".monaco-scrollable-element")
    .find(".lines-content")
    .find(".view-line")
    .type("testValue");

  cy.getByTestId("dialog-submit-button")
    .should("exist")
    .should("not.be.disabled");
  cy.getByTestId("dialog-submit-button").click();
  cy.getByTestId("dialog-container").should("not.exist");

  if (!isNew) {
    cy.getByTestId("calculationVariableAccordian").click();
    cy.wait(500);
    cy.getByTestId("calculationVariableAccordian").click();
    cy.get("table tbody tr").eq(2).should("contain.text", "testName");
    cy.get("table tbody tr").eq(2).should("contain.text", "ActActivity");
    cy.get("table tbody tr").eq(2).should("contain.text", "testValue");
    cy.get("table tbody tr").eq(2).should("contain.text", "item is an array");
  } else {
    cy.get("table tbody tr").eq(0).should("contain.text", "testName");
    cy.get("table tbody tr").eq(0).should("contain.text", "ActActivity");
    cy.get("table tbody tr").eq(0).should("contain.text", "testValue");
    cy.get("table tbody tr").eq(0).should("contain.text", "item is an array");
  }
}

export function verifyGraphIsReadonly(
  graphType: "main" | "rule" | "function" | "ruleset" | "defaultRule",
  nodePosX?: number,
  nodePosY?: number,
) {
  // verify save button is either disabled or not displayed
  cy.get("body").then(($body) => {
    const selector = "[data-testid='saveGraphButton']";
    const btn = $body.find(selector);
    if (btn.length) {
      cy.wrap(btn).should("be.disabled");
    } else {
      expect(btn.length).to.eq(0);
    }
  });

  cy.get("body").then(($body) => {
    const moreBtn = $body.find("[data-testid='nav-menu-more']");
    if (moreBtn.length) {
      cy.wrap(moreBtn).click({ force: true });
    }

    // verify Delete button does not exist
    cy.getByTestId("deleteArtifactBtn").should("not.exist");
    // verify import button does not exist
    cy.getByTestId("importFileBtn").should("not.exist");
  });

  // verify arrange button is disabled
  cy.getByTestId("arrangeButton").should("be.disabled");
  // verify undo and redo buttons are disabled
  cy.getByTestId("undoButton").should("be.disabled");
  cy.getByTestId("redoButton").should("be.disabled");

  // verify node palette is readonly:
  cy.getByTestId("nodePalette")
    .find("div.shape")
    .each(($el) => {
      expect($el).to.have.class("read-only");
    });

  // verify user cannot edit graph description:
  cy.getByTestId("editDescriptionBtn").should("not.exist");

  // verify user cannot drag and drop nodes from palette
  cy.getByTestId("nodePalette")
    .find("div.shape")
    .each(($el) => {
      cy.wrap($el).trigger("dragstart");
      cy.getByTestId("graphContainer").trigger("drop");
      cy.getByTestId("graphContainer").trigger("dragend");
      cy.getByTestId("graphContainer").should("not.contain", $el);
    });

  // by default, just check the start node and assume the x/y coordinates are the same for all graphs
  rightClickNode(nodePosX ? nodePosX : 0, nodePosY ? nodePosY : 0);
  // verify editNode contains "View Node Properties"
  cy.getByTestId("editNode")
    .should("exist")
    .should("contain.text", "View Node Properties");

  // by default, just check the start node property panel is disabled (assuming x/y coordinates are the same for all graphs)
  doubleClickNode(nodePosX ? nodePosX : 0, nodePosY ? nodePosY : 0);
  cy.getByTestId("nodeNameInput").should("exist").and("be.disabled");
  cy.getByTestId("varDescriptionTextArea").should("exist").and("be.disabled");
  if (graphType === "function" || graphType === "defaultRule") {
    cy.getByTestId("returnTypeInput").should("exist").and("be.disabled");
    cy.getByTestId("arrayInput").should("exist").and("be.disabled");
  }
}

export function rightClickNode(posX, posY) {
  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    const startNodeX = posX + NODE_X;
    const startNodeY = posY + NODE_Y;
    cy.wrap(canvas).rightclick(startNodeX, startNodeY);
  });
}

export function doubleClickNode(posX, posY) {
  cy.getByTestId("mainGraphCanvas").then(($canvas) => {
    const canvas = $canvas[0];
    const startNodeX = posX + NODE_X;
    const startNodeY = posY + NODE_Y;
    cy.wrap(canvas).dblclick(startNodeX, startNodeY);
  });
}
