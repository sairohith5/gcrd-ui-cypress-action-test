export enum ToastTitle {
  SUCCESS = "Success!",
  ERROR = "Error!",
  INFO = "Note",
  WARNING = "Warning!",
  TEST_SUMMARY = "Test Summary",
}

export enum ToastMessage {
  SUCCESSFUL_SAVE = "Item saved.",
  SUCCESSFUL_DELETE = "Item deleted.",
  SUCCESSFUL_DELETE_VERSION = "Repository version deleted.",
  SUCCESSFUL_DELETE_VERSIONS = "Repository versions deleted.",
  SUCCESSFUL_COMMIT = "Item committed.",
  SUCCESSFUL_REVERT = "Checkout reverted.",
  SUCCESSFUL_SYNC = "Workspace synced from remote repository.",
  SUCCESSFUL_RESET = "Workspace reset.",
  SUCCESSFUL_ROLLBACK = "Item rolled back to selected revision.",
  SUCCESSFUL_DEPLOYMENT = "Deployment triggered successfully",
  SUCCESSFUL_CLONE = "Item cloned successfully.",
  ERROR_SAVE = "There was a problem saving the item.",
  ERROR_CHECK_UNIQUE_NAME = "There was a problem saving the item. Check to make sure the item name is unique.",
  ERROR_TARGET_ALREADY_EXISTS = "Unable to rename - the proposed name already exists.",
  ERROR_DELETE = "There was a problem while deleting the item.",
  ERROR_DELETE_REFERENCED = "Unable to delete - ",
  ERROR_RECORD_EXISTS = "There was a problem saving the item. Name is not unique",
  ERROR_DUPLICATE = "An item with this name already exists.",
  ERROR_CREATE_VERSION = "There was a problem creating the repository version.",
  SUCCESSFUL_EXPORT = "Export file downloaded successfully",
  ERROR_EXPORT_MISMATCH = "There was a problem exporting the table. Check to make sure the table column definitions match the data.",
  ERROR_EXPORT = "There was a problem exporting the table.",
  ERROR_DEPLOYMENT = "Error triggering deployment. Environment cannot be found",
  ERROR_DT_INPUT_ARGS = "At least one input argument must be configured.",
  IMPORT_FILE_SUCCESS = "File uploaded successfully.",
  ALL_RECORDS_UNLOCKED = "All items unlocked.",
  LOCK_RELEASED = "Lock released.",
  MAXIMUM_VALUE_EXCEEDED = "Maximum value exceeded. The value has been changed to the maximum numeric value permitted.",
  MINIMUM_VALUE_EXCEEDED = "Minimum value exceeded. The value has been changed to the minimum numeric value permitted.",
  ERROR_DT_COLUMNS_MISMATCH = "Decision table column definitions do not match the row data columns. Work with your administrator to correct the data.",
  ENTER_INPUT = "Enter an input",
  REORDER_VARIABLES = "Global variables reordered successfully.",
  ERROR_DT_COLUMN_NAME_EXISTS = "A column with this Column ID already exists in the decision table.",
  NODE_SUBTREE_COPIED = "Node + Subtree copied. Use right-click on any empty canvas to paste.",
  NODE_COPIED = "Node copied. Use right-click on any empty canvas to paste.",
  INVALID_COPIED_DATA = "Invalid copied data.",
  NODES_PASTED = "Node(s) pasted.",
  NO_NODES_TO_PASTE = "No nodes to paste.",
  APPLIED_DEFAULT_CELL_CONDITIONS = "Default cell conditions applied successfully.",
  NO_DEFAULT_CELL_CONDITIONS = "No missing cell conditions found to apply defaults.",
}

export function testToast(
  title: ToastTitle | string,
  message: ToastMessage | string,
  leaveOpen = false,
) {
  cy.get("ol[data-sonner-toaster]").should("exist").as("toast");
  cy.get("@toast").find("div[data-title]").contains(title);
  cy.get("@toast").find("div[data-description]").contains(message);
  if (!leaveOpen) {
    cy.get("@toast").find("button[data-close-button]").click();
    // this intermittently fails:
    // cy.get("@toast").should("not.exist");
  }
}

export function toastDismiss() {
  cy.get("ol[data-sonner-toaster]").should("exist").as("toast");
  cy.get("@toast").find("button[data-close-button]").click();
  cy.get("@toast").should("not.exist");
}

export function clickToastActionButton(buttonText?: string) {
  cy.get("ol[data-sonner-toaster]").should("exist").as("toast");
  if (buttonText) {
    cy.get("@toast").find("button[data-action]").contains(buttonText).click();
  } else {
    cy.get("@toast").find("button[data-action]").click();
  }
}
