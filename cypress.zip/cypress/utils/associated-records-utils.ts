import { clickGridRow, testRow, testTable } from "./grid-utils";

export function testAssociatedRecordsSheet(
  recordName: string,
  leaveSheetOpen = false,
  isTableRowFunction: boolean = false,
) {
  openSheet();
  cy.getByTestId("associated-records-sheet")
    .as("associatedRecordsSheet")
    .should("exist");
  cy.get("@associatedRecordsSheet").find("h2").contains("References");
  cy.get("@associatedRecordsSheet")
    .find("p[data-testid='associated-records-description']")
    .contains(!isTableRowFunction ? recordName : "defaultRule");

  if (!leaveSheetOpen) closeSheet();
}

export function testAssociatedRecordsGrid(
  firstRowData: any[] | "No results.",
  leaveSheetOpen = false,
) {
  openSheet();
  testTable(["Type", "Item"], firstRowData, "associatedRecordsTable");
  if (!leaveSheetOpen) closeSheet();
}

export function testAssociatedRecordsGridRow(
  rowIndex: number,
  rowData: any[],
  leaveSheetOpen = false,
) {
  openSheet();
  testRow(rowIndex, rowData, "associatedRecordsTable");
  if (!leaveSheetOpen) closeSheet();
}

export function testAssociatedRecordNavigation(
  rowIndex: number,
  recordType:
    | "Rule"
    | "Rule Set"
    | "Decision Table"
    | "Main Flow"
    | "Function"
    | "Table Function",
) {
  openSheet();
  cy.getByTestId("associated-records-sheet")
    .as("associatedRecordsSheet")
    .should("exist");

  clickGridRow(rowIndex, 1, 0, "associatedRecordsTable");

  cy.wait(500);
  cy.get("@associatedRecordsSheet").should("not.exist");
  switch (recordType) {
    case "Rule":
      cy.url()
        .should("contain", "/rule-designer/designer/rule-sets")
        .should("contain", "/rule/");
      break;
    case "Rule Set":
      cy.url().should("contain", "/rule-designer/designer/rule-sets");
      break;
    case "Decision Table":
      cy.url().should("contain", "/rule-designer/designer/decision-tables/");
      break;
    case "Main Flow":
      cy.url().should("contain", "/rule-designer/designer/main-flow");
      break;
    case "Function":
      cy.url().should("contain", "/rule-designer/designer/functions/");
      break;
    case "Table Function":
      cy.url()
        .should("contain", "/rule-designer/designer/decision-tables/")
        .should("contain", "/function/");
      break;
  }
}

export function openSheet() {
  cy.wait(1000);
  cy.get("body").then(($body) => {
    if ($body.find("div[data-testid='associated-records-sheet']").length > 0) {
      // it's already open... do nothing
      return;
    } else {
      cy.getByTestId("nav-menu-more").click({ force: true });
      cy.getByTestId("findReferencesBtn")
        .should("exist")
        .contains("Find References")
        .click({ force: true });
    }
  });
}

export function closeSheet() {
  cy.getByTestId("associated-records-sheet")
    .as("associatedRecordsSheet")
    .should("exist");
  cy.get("@associatedRecordsSheet")
    .find("button[data-testid='sheet-close-x-btn']")
    .should("exist")
    .click();
  cy.get("@associatedRecordsSheet").should("not.exist");
}
