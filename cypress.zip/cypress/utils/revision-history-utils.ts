import {
  cancelDialog,
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "./dialog-utils";
import { testTable } from "./grid-utils";
import { testToast, ToastMessage, ToastTitle } from "./toast-utils";

export function testRevisionHistoryDialog(
  dialogDescription: string,
  rowData: any[],
  hasCompareButton: boolean = true,
  rowToTest: number = 1,
) {
  testIsDialogDisplayed();
  cy.getByTestId("dialog-title").contains("Latest Revision History");
  cy.getByTestId("dialog-description").contains(dialogDescription);

  const headers = hasCompareButton
    ? [
        "Compare",
        "Revision ID",
        "Last Committed",
        "Committed By",
        "Message",
        "Actions",
      ]
    : ["Revision ID", "Last Committed", "Committed By", "Message", "Actions"];
  //test the table if the "Uncommitted version" row is present at the top always
  testTable(
    headers,
    hasCompareButton
      ? [
          { type: "checkbox", isChecked: false },
          "--",
          "--",
          "--",
          "Uncommitted version",
          "",
        ]
      : ["--", "--", "--", "Uncommitted version", ""],
    "revisionHistoryGrid",
    undefined,
    0,
  );
  testTable(headers, rowData, "revisionHistoryGrid", undefined, rowToTest);
  cy.getByTestId("dialog-submit-button").should("not.exist");
  cy.getByTestId("dialog-cancel-button").should("exist").contains("Close");

  if (hasCompareButton) {
    cy.getByTestId("compare-revisions-btn")
      .should("exist")
      .should("be.disabled");
    cy.getGridRowButtonOrLink(1, 0, 0, "revisionHistoryGrid").click();
    cy.getByTestId("compare-revisions-btn").should("be.disabled");
    cy.getGridRowButtonOrLink(2, 0, 0, "revisionHistoryGrid").click();
    cy.getByTestId("compare-revisions-btn").should("be.enabled");
  }
}

export function testRevisionHistoryDialogFromGrid(
  revisionHistoryBtnIndex: number,
  dialogDescription: string,
  firstRowData: any[],
  hasCompareButton: boolean = true,
) {
  cy.getByTestId(
    "grid-revision-history-button-" + revisionHistoryBtnIndex,
  ).click();
  testRevisionHistoryDialog(dialogDescription, firstRowData, hasCompareButton);
  cancelDialog();
  testDialogIsNotDisplayed();
}

export function testRevisionCompareDialog(
  revisionHistoryBtnIndex: number,
  version1BtnIndex: number,
  version2BtnIndex: number,
  dialogDescription: string,
  version1: string,
  version1Date: string,
  version2: string,
  version2Date: string,
  dataType?: "table" | "graph" | "globalVariables",
  customObjectFields?: {
    version1Fields: CustomObjectField[];
    version2Fields: CustomObjectField[];
  },
  globalVariableFields?: {
    version1Fields: GlobalVariableField[];
    version2Fields: GlobalVariableField[];
  },
  leaveOpen: boolean = false,
) {
  // first open the revision history dialog
  cy.getByTestId(
    "grid-revision-history-button-" + revisionHistoryBtnIndex,
  ).click();

  // now open the compare dialog by clicking two checkboxes and then the compare button
  cy.getGridRowButtonOrLink(
    version1BtnIndex,
    0,
    0,
    "revisionHistoryGrid",
  ).click();
  cy.getGridRowButtonOrLink(
    version2BtnIndex,
    0,
    0,
    "revisionHistoryGrid",
  ).click();

  cy.getByTestId("compare-revisions-btn").click();
  testIsDialogDisplayed("revision-compare-dialog-container");
  cy.getByTestId("revision-compare-dialog-title").contains("Compare Versions");
  cy.getByTestId("revision-compare-dialog-container")
    .find("[data-testid='dialog-description']")
    .contains(dialogDescription);

  cy.getByTestId("version-1-panel-title").contains("Version " + version1);
  cy.getByTestId("version-1-panel-title").contains("Committed " + version1Date);
  if (version2 != "") {
    cy.getByTestId("version-2-panel-title").contains("Version " + version2);
    cy.getByTestId("version-2-panel-title").contains(
      "Committed " + version2Date,
    );
  } else {
    cy.getByTestId("version-2-panel-title").contains("Uncommitted Version");
  }

  if (dataType === "table") {
    // test that a decision table is displayed on both sides
    cy.getByTestId("version-1-panel")
      .find(".decisionTableContainer")
      .should("exist");

    cy.getByTestId("version-2-panel")
      .find(".decisionTableContainer")
      .should("exist");
  }

  // Test custom object data tables if provided
  if (customObjectFields) {
    testCustomObjectDataTable(
      "version-1-panel",
      customObjectFields.version1Fields,
    );
    testCustomObjectDataTable(
      "version-2-panel",
      customObjectFields.version2Fields,
    );
  }

  // Test global variables data tables if provided
  if (globalVariableFields) {
    testGlobalVariablesDataTable(
      "version-1-panel",
      globalVariableFields.version1Fields,
    );
    testGlobalVariablesDataTable(
      "version-2-panel",
      globalVariableFields.version2Fields,
    );
  }

  if (!leaveOpen) {
    closeRevisionCompareDialog();
  }
}

export function closeRevisionCompareDialog() {
  // close the dialog
  cy.getByTestId("revision-compare-dialog-cancel-button")
    .should("exist")
    .click();
  testDialogIsNotDisplayed("revision-compare-dialog-container");

  cy.getByTestId("dialog-cancel-button").click();
  testDialogIsNotDisplayed();
}

export function testRollback(
  revisionHistoryBtnIndex: number,
  rollbackBtnRowIndex: number,
  canUserRollback: boolean = true,
  hasCompareButton: boolean = true,
) {
  const ACTION_BTN_COL_INDEX = hasCompareButton ? 5 : 4;
  // first open the revision history dialog
  cy.getByTestId(
    "grid-revision-history-button-" + revisionHistoryBtnIndex,
  ).click();

  if (canUserRollback) {
    // now click the rollback button
    cy.getGridRowButtonOrLink(
      rollbackBtnRowIndex,
      ACTION_BTN_COL_INDEX,
      0,
      "revisionHistoryGrid",
    ).click();

    // test the confirmation dialog
    testIsDialogDisplayed("rollback-confirmation-dialog-container");
    cy.getByTestId("rollback-confirmation-dialog-title").contains(
      "Rollback Confirmation",
    );
    cy.getByTestId("rollback-confirmation-dialog-content").contains(
      "Rolling back to a past revision will cause all unsaved and uncommitted changes to be lost. You will be able to discard the rollback before committing, but you will not be able to recover the changes you are about to lose.",
    );
    cy.getByTestId("rollback-confirmation-dialog-content").contains(
      "Are you sure you want to rollback to this revision?",
    );

    cy.getByTestId("rollback-confirmation-dialog-cancel-button")
      .should("exist")
      .click();

    testDialogIsNotDisplayed("rollback-confirmation-dialog-container");

    cy.getGridRowButtonOrLink(
      rollbackBtnRowIndex,
      ACTION_BTN_COL_INDEX,
      0,
      "revisionHistoryGrid",
    ).click();

    cy.getByTestId("rollback-confirmation-dialog-submit-button")
      .should("exist")
      .contains("Confirm")
      .click();

    testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_ROLLBACK);
    testDialogIsNotDisplayed("rollback-confirmation-dialog-container");
    testDialogIsNotDisplayed();
  } else {
    // test that the rollback button is disabled
    cy.getGridRowButtonOrLink(
      rollbackBtnRowIndex,
      5,
      0,
      "revisionHistoryGrid",
    ).should("be.disabled");

    cy.getByTestId("dialog-cancel-button").click();
    testDialogIsNotDisplayed();
  }
}

export interface CustomObjectField {
  name: string;
  type: string;
  isArray: boolean;
  required: boolean;
  nullable: boolean;
  auto: boolean;
}

/**
 * Test the custom object data table displayed in a revision compare panel
 * @param panelTestId - The test ID of the panel (version-1-panel or version-2-panel)
 * @param expectedFields - Array of expected fields to be displayed in the table
 */
export function testCustomObjectDataTable(
  panelTestId: string,
  expectedFields: CustomObjectField[],
) {
  cy.getByTestId(panelTestId)
    .find("[data-testid='scrollable-table']", { timeout: 1000 })
    .should("exist")
    .find("table")
    .should("exist");

  // Verify the table headers
  cy.getByTestId(panelTestId).find("thead th").should("have.length", 6);

  cy.getByTestId(panelTestId).find("thead th").eq(0).should("contain", "Name");
  cy.getByTestId(panelTestId).find("thead th").eq(1).should("contain", "Type");
  cy.getByTestId(panelTestId)
    .find("thead th")
    .eq(2)
    .should("contain", "Is Array?");
  cy.getByTestId(panelTestId)
    .find("thead th")
    .eq(3)
    .should("contain", "Is Required?");
  cy.getByTestId(panelTestId)
    .find("thead th")
    .eq(4)
    .should("contain", "Nullable?");
  cy.getByTestId(panelTestId)
    .find("thead th")
    .eq(5)
    .should("contain", "Auto Instantiate?");

  // Verify the number of data rows matches expected fields
  cy.getByTestId(panelTestId)
    .find("tbody tr")
    .should("have.length", expectedFields.length);

  // Verify each field row
  expectedFields.forEach((field, index) => {
    cy.getByTestId(panelTestId)
      .find("tbody tr")
      .eq(index)
      .find("td, th")
      .eq(0)
      .should("contain", field.name);

    cy.getByTestId(panelTestId)
      .find("tbody tr")
      .eq(index)
      .find("td, th")
      .eq(1)
      .should("contain", field.type);

    // Check for checkmark icon instead of "Yes" or "No" text
    if (field.isArray) {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(2)
        .find("svg[data-icon='check']")
        .should("exist")
        .should("have.class", "text-he-green-1");
    } else {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(2)
        .find("svg")
        .should("not.exist");
    }

    if (field.required) {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(3)
        .find("svg[data-icon='check']")
        .should("exist")
        .should("have.class", "text-he-green-1");
    } else {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(3)
        .find("svg")
        .should("not.exist");
    }

    if (field.nullable) {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(4)
        .find("svg[data-icon='check']")
        .should("exist")
        .should("have.class", "text-he-green-1");
    } else {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(4)
        .find("svg")
        .should("not.exist");
    }

    if (field.auto) {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(5)
        .find("svg[data-icon='check']")
        .should("exist")
        .should("have.class", "text-he-green-1");
    } else {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(5)
        .find("svg")
        .should("not.exist");
    }
  });
}

export function verifyTestCaseComparison(
  panel1: {
    removedCount?: number;
    removedText?: string;
    addedCount?: number;
    addedText?: string;
    modifiedCount?: number;
    modifiedText?: string;
  },
  panel2: {
    removedCount?: number;
    removedText?: string;
    addedCount?: number;
    addedText?: string;
    modifiedCount?: number;
    modifiedText?: string;
  },
) {
  cy.getByTestId("version-1-panel")
    .should("exist")
    .as("version1Panel")
    .within(() => {
      // check counts:
      if (panel1.removedCount) {
        cy.getByTestId("json-diff-viewer-removed-expected").should(
          "have.text",
          `-${panel1.removedCount}`,
        );
      } else {
        cy.getByTestId("json-diff-viewer-removed-expected").should("not.exist");
      }
      if (panel1.addedCount) {
        cy.getByTestId("json-diff-viewer-added-expected").should(
          "have.text",
          `+${panel1.addedCount}`,
        );
      } else {
        cy.getByTestId("json-diff-viewer-added-expected").should("not.exist");
      }
      if (panel1.modifiedCount) {
        cy.getByTestId("json-diff-viewer-modified-expected").should(
          "have.text",
          `~${panel1.modifiedCount}`,
        );
      } else {
        cy.getByTestId("json-diff-viewer-modified-expected").should(
          "not.exist",
        );
      }

      // check text:
      cy.getByTestId("json-diff-viewer-expected")
        .should("exist")
        .within(() => {
          if (panel1.modifiedText) {
            cy.get("span.modified")
              .should("exist")
              .then(($spans) => {
                const found = Array.from($spans).some(
                  (el) => el.textContent?.trim() === panel1.modifiedText,
                );
                expect(
                  found,
                  `Expected at least one span.modified with text "${panel1.modifiedText}"`,
                ).to.be.true;
              });
          }

          if (panel1.addedText) {
            cy.get("span.added")
              .should("exist")
              .then(($spans) => {
                const found = Array.from($spans).some(
                  (el) => el.textContent?.trim() === panel1.addedText,
                );
                expect(
                  found,
                  `Expected at least one span.added with text "${panel1.addedText}"`,
                ).to.be.true;
              });
          }

          if (panel1.removedText) {
            cy.get("span.removed")
              .should("exist")
              .then(($spans) => {
                const found = Array.from($spans).some(
                  (el) => el.textContent?.trim() === panel1.removedText,
                );
                expect(
                  found,
                  `Expected at least one span.removed with text "${panel1.removedText}"`,
                ).to.be.true;
              });
          }
        });
    });

  cy.getByTestId("version-2-panel")
    .should("exist")
    .as("version2Panel")
    .within(() => {
      // check counts:
      if (panel2.removedCount) {
        cy.getByTestId("json-diff-viewer-removed-actual").should(
          "have.text",
          `-${panel2.removedCount}`,
        );
      } else {
        cy.getByTestId("json-diff-viewer-removed-actual").should("not.exist");
      }
      if (panel2.addedCount) {
        cy.getByTestId("json-diff-viewer-added-actual").should(
          "have.text",
          `+${panel2.addedCount}`,
        );
      } else {
        cy.getByTestId("json-diff-viewer-added-actual").should("not.exist");
      }
      if (panel2.modifiedCount) {
        cy.getByTestId("json-diff-viewer-modified-actual").should(
          "have.text",
          `~${panel2.modifiedCount}`,
        );
      } else {
        cy.getByTestId("json-diff-viewer-modified-actual").should("not.exist");
      }

      // check text:
      cy.getByTestId("json-diff-viewer-actual")
        .should("exist")
        .within(() => {
          if (panel2.modifiedText) {
            cy.get("span.modified")
              .should("exist")
              .then(($spans) => {
                const found = Array.from($spans).some(
                  (el) => el.textContent?.trim() === panel2.modifiedText,
                );
                expect(
                  found,
                  `Expected at least one span.modified with text "${panel2.modifiedText}"`,
                ).to.be.true;
              });
          }

          if (panel2.addedText) {
            cy.get("span.added")
              .should("exist")
              .then(($spans) => {
                const found = Array.from($spans).some(
                  (el) => el.textContent?.trim() === panel2.addedText,
                );
                expect(
                  found,
                  `Expected at least one span.added with text "${panel2.addedText}"`,
                ).to.be.true;
              });
          }

          if (panel2.removedText) {
            cy.get("span.removed")
              .should("exist")
              .then(($spans) => {
                const found = Array.from($spans).some(
                  (el) => el.textContent?.trim() === panel2.removedText,
                );
                expect(
                  found,
                  `Expected at least one span.removed with text "${panel2.removedText}"`,
                ).to.be.true;
              });
          }
        });
    });
}

export interface GlobalVariableField {
  varName: string;
  varType: string;
  isArray: boolean;
  initExpr?: string;
}

/**
 * Test the global variables data table displayed in a revision compare panel
 * @param panelTestId - The test ID of the panel (version-1-panel or version-2-panel)
 * @param expectedVariables - Array of expected variables to be displayed in the table
 */
export function testGlobalVariablesDataTable(
  panelTestId: string,
  expectedVariables: GlobalVariableField[],
) {
  cy.getByTestId(panelTestId)
    .find("[data-testid='scrollable-table']", { timeout: 1000 })
    .should("exist")
    .find("table")
    .should("exist");

  // Verify the table headers
  cy.getByTestId(panelTestId).find("thead th").should("have.length", 4);

  cy.getByTestId(panelTestId).find("thead th").eq(0).should("contain", "Name");
  cy.getByTestId(panelTestId).find("thead th").eq(1).should("contain", "Type");
  cy.getByTestId(panelTestId)
    .find("thead th")
    .eq(2)
    .should("contain", "Is Array?");
  cy.getByTestId(panelTestId)
    .find("thead th")
    .eq(3)
    .should("contain", "Initial Expression");

  // Verify the number of data rows matches expected variables
  cy.getByTestId(panelTestId)
    .find("tbody tr")
    .should("have.length", expectedVariables.length);

  // Verify each variable row
  expectedVariables.forEach((variable, index) => {
    cy.getByTestId(panelTestId)
      .find("tbody tr")
      .eq(index)
      .find("td, th")
      .eq(0)
      .should("contain", variable.varName);

    cy.getByTestId(panelTestId)
      .find("tbody tr")
      .eq(index)
      .find("td, th")
      .eq(1)
      .should("contain", variable.varType);

    // Check for checkmark icon for isArray
    if (variable.isArray) {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(2)
        .find("svg[data-icon='check']")
        .should("exist")
        .should("have.class", "text-he-green-1");
    } else {
      cy.getByTestId(panelTestId)
        .find("tbody tr")
        .eq(index)
        .find("td, th")
        .eq(2)
        .find("svg")
        .should("not.exist");
    }

    // Check initExpr (Initial Expression)
    cy.getByTestId(panelTestId)
      .find("tbody tr")
      .eq(index)
      .find("td, th")
      .eq(3)
      .should("contain", variable.initExpr || "");
  });
}
