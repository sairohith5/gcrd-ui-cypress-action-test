/**
 * Tests the behavior of tabs in a UI component. This does NOT test the
 * content of the tab panels. Create separate tests to verify the content.
 *
 * @param tabListTestId - The test ID of the tab list element.
 * @param tabNames - An array of tab names.
 * @param initialActiveTab - The name of the initial active tab.
 * @param tabPanelTestIds - An array of test IDs for the tab panel elements.
 */
export function testTabs(
  tabListTestId: string,
  tabNames: string[],
  initialActiveTab: string,
  tabPanelTestIds: string[],
) {
  cy.getByTestId(tabListTestId)
    .find("button[role='tab']")
    .then((tabs) => {
      expect(tabs.length).to.equal(tabNames.length);
      for (let x = 0; x < tabNames.length; x++) {
        expect(tabs[x]).to.contain.text(tabNames[x]);
        if (initialActiveTab === tabNames[x]) {
          expect(tabs[x]).to.have.attr("data-state", "active");
        } else {
          expect(tabs[x]).to.have.attr("data-state", "inactive");
        }
      }
    });

  // click each tab to verify the expected tab panel appears
  tabNames.forEach((_tabName, index) => {
    // eslint-disable-next-line cypress/unsafe-to-chain-command
    cy.clickTabByIndex(index, tabListTestId).as("tabButton"); // @tabButton
    cy.get("@tabButton").should("have.attr", "data-state", "active");
    cy.get("@tabButton").should(
      "have.css",
      "text-decoration-line",
      "underline",
    );

    cy.getByTestId(tabPanelTestIds[index]).as("tabPanel"); // @tabPanel
    cy.get("@tabPanel").should("not.have.attr", "hidden");
    cy.get("@tabPanel")
      .should("have.attr", "data-state")
      .and("equal", "active");
  });
}
