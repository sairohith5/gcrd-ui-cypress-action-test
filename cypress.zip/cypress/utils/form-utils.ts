import { ToastMessage, ToastTitle, testToast } from "./toast-utils";

/**
 * Tests a form field in a Cypress test.
 *
 * @param formFieldName - The data-testid of the form field.
 * @param labelText - The expected label text of the form field.
 * @param isRequired - Indicates whether the form field is required.
 * @param options - Additional options for testing the form field.
 * @param options.isCheckbox - Indicates whether the form field is a checkbox.
 * @param options.expectedSelectOptions - An array of expected select options for the form field.
 * @param options.numSelectOptionsToTest - The number of select options to validate.
 * @param options.expectDisabled - Indicates whether the form field is expected to be disabled.
 * @param options.defaultValue - The default value of the form field.
 * @param options.isRadioButton - Indicates whether the form field is a radio button.
 * @param options.expectedRadioButtonOptions - An array of expected radio button options.
 * @param options.expectedRadioButtonSelected - The expected selected radio button.
 */
export function testFormField(
  formFieldName: string,
  labelText: string,
  isRequired: boolean,
  options?: {
    isCheckbox?: boolean;
    expectedSelectOptions?: string[];
    numSelectOptionsToTest?: number;
    expectDisabled?: boolean;
    defaultValue?: string;
    isRadioButton?: boolean;
    expectedRadioButtonOptions?: string[];
    expectedRadioButtonSelected?: string;
  },
) {
  // eslint-disable-next-line cypress/no-assigning-return-values
  const label = cy.getByTestId(formFieldName).find("label");
  // eslint-disable-next-line cypress/no-assigning-return-values
  const input = cy.getByTestId(formFieldName).find("input,select,textarea");

  label.contains(labelText);

  // test form field label is properly associated with its form field input
  cy.getByTestId(formFieldName)
    .find(
      "input, button[role='checkbox'], select, textarea, div[role='radiogroup']",
    )
    .invoke("attr", "id")
    .then((id) => {
      cy.getByTestId(formFieldName)
        .find("label")
        .should("have.attr", "for")
        .and("equal", id);
    });

  if (isRequired) {
    testRequired(label, input);
  } else if (!options?.isCheckbox && !options?.isRadioButton) {
    testNotRequired(label, input);
  }

  // test radio buttons
  if (options?.isRadioButton) {
    testNotRequired(label, input);

    // test that the expected radio button options are present
    if (options?.expectedRadioButtonOptions) {
      let x = 0;
      cy.getByTestId(formFieldName)
        .find("div[role='radiogroup'] label")
        .then((label) => {
          label.each((_, el) => {
            expect(el).to.contain.text(options.expectedRadioButtonOptions[x]);
            x++;
          });
        });
    }

    // test that the expected radio button is selected
    if (options?.expectedRadioButtonSelected) {
      cy.get(
        "[data-testid='" + formFieldName + "'] input[type='radio'][checked]",
      )
        .should("exist")
        .as("checkedRadio");
      cy.get("@checkedRadio")
        .invoke("attr", "value")
        .should("eq", options.expectedRadioButtonSelected.toLowerCase());
    }
  }

  // test that the expected select options are present
  if (options?.expectedSelectOptions) {
    cy.getByTestId(formFieldName)
      .find("select option")
      .then((actualOptions) => {
        const numToValidate = options.numSelectOptionsToTest
          ? options.numSelectOptionsToTest
          : actualOptions.length;
        for (let x = 0; x < numToValidate; x++) {
          expect(actualOptions[x]).to.contain.text(
            // @ts-ignore
            options.expectedSelectOptions[x],
          );
        }
      });
  }

  if (options?.expectDisabled) {
    cy.getByTestId(formFieldName)
      .find("input, select, textarea, button[role='checkbox']")
      .should("have.attr", "disabled");
  } else {
    cy.getByTestId(formFieldName)
      .find("input, select, textarea, button[role='checkbox']")
      .should("not.have.attr", "disabled");
  }

  if (options?.defaultValue) {
    testFormFieldValue(formFieldName, options.defaultValue);
  }
}

/**
 * Tests if a form field has the expected value.
 *
 * @param formFieldName - The test ID of the form field to check.
 * @param value - The expected value of the form field.
 */
export function testFormFieldValue(formFieldName: string, value: string) {
  cy.getByTestId(formFieldName)
    .find("input, select, textarea")
    .should("have.value", value);
}

/**
 * Tests the validation of a form field.
 *
 * @param formFieldName - The data-testid of the form field.
 * @param errorMessage - The expected error message.
 */
export function testFormFieldValidation(
  formFieldName: string,
  errorMessage: string,
  hasFormLabel: boolean = true,
) {
  if (hasFormLabel) {
    cy.getByTestId(formFieldName)
      .find("label")
      .should("have.class", "text-destructive");
  }

  cy.getByTestId(formFieldName)
    .find("p")
    .first()
    .contains(errorMessage)
    .should("have.class", "text-destructive");
  cy.getByTestId(formFieldName)
    .find("input,select,textarea")
    .should("have.attr", "aria-invalid")
    .and("equal", "true");

  cy.getByTestId(formFieldName)
    .find("p")
    .first()
    .invoke("attr", "id")
    .then((id) => {
      cy.getByTestId(formFieldName)
        .find("input,select,textarea")
        .should("have.attr", "aria-describedby")
        .and("contain", id);
    });
}

export function testFormFieldNoValidation(formFieldName: string) {
  cy.getByTestId(formFieldName)
    .find("label")
    .should("not.have.class", "text-destructive");
  cy.getByTestId(formFieldName).find("p.text-destructive").should("not.exist");
  cy.getByTestId(formFieldName)
    .find("input,select,textarea")
    .should("have.attr", "aria-invalid")
    .and("equal", "false");
}

/**
 * Makes a selection in a select dropdown.
 *
 * @param formInputName - The data-testid attribute value of the form field.
 * @param value - The value to be selected from the dropdown.
 */
export function selectFormField(formInputName: string, value: string) {
  cy.get('[data-testid="' + formInputName + '"]')
    .as("selectElement")
    .scrollIntoView();
  cy.get("@selectElement").select(value);
}

/**
 * Types a value into a form field identified by its data-testid attribute.
 *
 * @param formInputName - The data-testid attribute value of the form field.
 * @param value - The value to be typed into the form field.
 */
export function typeFormField(
  formInputName: string,
  value: string,
  delay = 10,
) {
  cy.get('[data-testid="' + formInputName + '"]').type(value, { delay });
}

export function pasteIntoFormField(formInputName: string, textToPaste: string) {
  cy.get('[data-testid="' + formInputName + '"]')
    .invoke("val", textToPaste)
    .trigger("input");
}

export function clearFormField(formInputName: string) {
  cy.get('[data-testid="' + formInputName + '"]').clear();
}

export function testNameFieldValidation(
  formFieldTestId = "fileFormNameField",
  formFieldInputTestId = "fileNameInput",
  submitBtnTestId = "btnFileFormSave",
  errorMessage = "Field can only contain alphanumeric characters and underscores, and cannot start with a numeric value.",
) {
  typeFormField(formFieldInputTestId, "1invalidname");
  cy.getByTestId(submitBtnTestId).click();
  testFormFieldValidation(formFieldTestId, errorMessage);
  clearFormField(formFieldInputTestId);
  typeFormField(formFieldInputTestId, "invalid name");
  testFormFieldValidation(formFieldTestId, errorMessage);
  clearFormField(formFieldInputTestId);
  typeFormField(formFieldInputTestId, "invalid-name!");
  testFormFieldValidation(formFieldTestId, errorMessage);
  clearFormField(formFieldInputTestId);
}

export function testNameFieldValidationWhenCloning() {
  testNameFieldValidation(
    "filenameField",
    "filenameInput",
    "dialog-submit-button",
  );
}

/**
 * Tests the description edit form. This is the form that appears on multiple pages where a description can be edited.
 */
export function testDescriptionEditForm() {
  cy.getByTestId("tagline")
    .invoke("text")
    .then((taglineText) => {
      cy.getByTestId("descriptionInput").should("not.exist");
      cy.getByTestId("editDescriptionBtn").should("exist").trigger("mouseover"); // button not visible until hovered
      cy.getByTestId("editDescriptionBtn").click();
      cy.getByTestId("descriptionInput").should("have.value", taglineText);

      // test validation
      pasteIntoFormField(
        "descriptionInput",
        "Curabitur eget ante ac dui convallis placerat. Phasellus ut magna eu lacus cursus tempor. Curabitur vel dictum diam, at imperdiet ex. Pellentesque justo lorem, sollicitudin vitae augue ut, iaculis scelerisque nisi. Integer bibendum leo elit, at rutrum neque bibendum et. Vivamus at volutpat diam, quis eleifend libero. Sed sed purus vel metus sollicitudin sodales. Nunc suscipit lacus id ex sagittis mattis sed venenatis felis. Quisque lacinia bibendum est ut pharetra. Nullam ut euismod arcu, ut ultrices mauris. Nullam maximus, nisi sed pretium ultrices, diam magna pharetra orci, sed lobortis dui nibh a nulla. Fusce posuere vestibulum volutpat. Nam ultrices id lectus vitae faucibus. Integer vel rutrum dui. Nulla volutpat nisi accumsan auctor volutpat. Duis arcu odio, mollis non vulputate eget, pretium eu dui. Donec leo enim, mollis sed vulputate id, facilisis vitae massa. Morbi et ipsum vulputate, iaculis mi eu, tempor ante. In quis purus id diam consequat tempus eget at nunc. In tortor non",
      );
      typeFormField("descriptionInput", "."); // trigger save button to become enabled (the above "paste" does not trigger it)
      cy.getByTestId("descriptionFormSaveBtn").click();
      testFormFieldValidation(
        "descriptionField",
        "Maximum length is 1000 characters",
        false,
      );
      cy.getByTestId("descriptionFormCancelBtn").click();

      // test save button
      cy.getByTestId("editDescriptionBtn").click();
      cy.getByTestId("descriptionFormSaveBtn").should("have.attr", "disabled");
      typeFormField("descriptionInput", "blah blah blah");
      cy.getByTestId("descriptionFormSaveBtn").should(
        "not.have.attr",
        "disabled",
      );
      cy.getByTestId("descriptionFormSaveBtn").click();
      testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
      cy.getByTestId("descriptionInput").should("not.exist");
      cy.getByTestId("editDescriptionBtn").should("exist");

      // test cancel button
      cy.getByTestId("editDescriptionBtn").should("exist").click();
      cy.getByTestId("descriptionFormCancelBtn").click();
      cy.getByTestId("descriptionInput").should("not.exist");
      cy.getByTestId("editDescriptionBtn").click();
    });
}

/**
 * Tests the behavior of the description add form.
 */
export function testDescriptionAddForm() {
  cy.getByTestId("tagline").should("not.exist");
  cy.getByTestId("addDescriptionBtn").should("exist").click();

  // test cancel button
  cy.getByTestId("descriptionFormCancelBtn").click();
  cy.getByTestId("descriptionInput").should("not.exist");

  // test save button
  cy.wait(500);
  cy.getByTestId("addDescriptionBtn").click();
  cy.getByTestId("descriptionFormSaveBtn").should("have.attr", "disabled");
  typeFormField("descriptionInput", "blah blah blah");
  cy.getByTestId("descriptionFormSaveBtn").should("not.have.attr", "disabled");
  cy.wait(500);
  cy.getByTestId("descriptionFormSaveBtn").click();
  testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_SAVE);
  cy.getByTestId("descriptionInput").should("not.exist");
}

/**
 * Checks if a label and input element are required.
 *
 * @param label - The label element to check.
 * @param input - The input element to check.
 */
function testRequired(
  label: Cypress.Chainable<JQuery<HTMLLabelElement>>,
  input: Cypress.Chainable<JQuery<HTMLElement>>,
) {
  label.then(($els) => {
    // get Window reference from element
    const win = $els[0].ownerDocument.defaultView;
    // use getComputedStyle to read the pseudo selector
    const before = win?.getComputedStyle($els[0], ":before");
    // read the value of the `content` CSS property
    const contentValue = before?.getPropertyValue("content");
    // the returned value will have double quotes around it, but this is correct
    expect(contentValue).to.eq('"*" / ""');
  });

  input.should("have.attr", "required");
  cy.get(".requiredNote, [class^='styles_requiredNote']").should("exist");
}

/**
 * Checks if a form field is not required.
 *
 * @param label - The label element associated with the form field.
 * @param input - The input element to be checked.
 */
function testNotRequired(
  label: Cypress.Chainable<JQuery<HTMLLabelElement>>,
  input: Cypress.Chainable<JQuery<HTMLElement>>,
) {
  label.then(($els) => {
    // get Window reference from element
    const win = $els[0].ownerDocument.defaultView;
    // use getComputedStyle to read the pseudo selector
    const before = win?.getComputedStyle($els[0], ":before");
    // read the value of the `content` CSS property
    const contentValue = before?.getPropertyValue("content");
    // the returned value will have double quotes around it, but this is correct
    expect(contentValue).to.not.eq('"*" / ""');
  });

  input.should("not.have.attr", "required");
}

/**
 * Tests a content-assisted form field by verifying its label text and required status.
 *
 * @param formFieldName - The test ID of the form field to select.
 * @param labelText - The expected text content of the field's label.
 * @param isRequired - Whether the field is required; checks for the "required" class accordingly.
 *
 * @example
 * testContentAssistedField('assignTarget', 'Assign Target', true);
 */
export function testContentAssistedField(
  formFieldName: string,
  labelText: string,
  isRequired: boolean,
) {
  // eslint-disable-next-line cypress/no-assigning-return-values
  const label = cy.getByTestId(formFieldName).find("label");
  label.contains(labelText);

  if (isRequired) {
    label.should("have.class", "required");
  } else {
    label.should("not.have.class", "required");
  }
}
