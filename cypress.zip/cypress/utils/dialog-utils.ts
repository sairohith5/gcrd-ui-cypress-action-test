import { testFormField, typeFormField } from "./form-utils";
import { ToastMessage, ToastTitle, testToast } from "./toast-utils";

export function testDialog(
  triggerBtn: Cypress.Chainable<Element>,
  title: string,
  submitBtnText?: string,
  cancelBtnText?: string,
) {
  // open the dialog
  openDialog(triggerBtn);
  testIsDialogDisplayed();
  cy.getByTestId("dialog-title").contains(title);
  if (submitBtnText) {
    cy.getByTestId("dialog-submit-button").contains(submitBtnText);
  }

  // test cancel button
  if (cancelBtnText) {
    cy.getByTestId("dialog-cancel-button")
      .contains(cancelBtnText)
      .click({ force: true });
  } else {
    cy.getByTestId("dialog-cancel-button").click({ force: true });
  }

  testDialogIsNotDisplayed();

  // we have removed the X button because using it to close dialog does not always allow dialog to be reopened, and we have the cancel button
  // open the dialog again
  // openDialog(triggerBtn);
  // test the close X button
  // cy.getByTestId("dialog-close-x-btn").click();
  // testDialogIsNotDisplayed();
}

export function cancelDialog() {
  cy.getByTestId("dialog-cancel-button").click();
  testDialogIsNotDisplayed();
}

export function submitDialog() {
  cy.getByTestId("dialog-submit-button").click();
}

export function openDialog(triggerBtn: Cypress.Chainable<Element>) {
  triggerBtn.click({ force: true });
  testIsDialogDisplayed();
}

export function testIsDialogDisplayed(testId?: string) {
  const dialogId = testId ? testId : "dialog-container";
  cy.getByTestId(dialogId).should("exist");
}

export function testDialogIsNotDisplayed(testId?: string) {
  const dialogId = testId ? testId : "dialog-container";
  cy.getByTestId(dialogId).should("not.exist");
}
export function confirmUnlock() {
  testIsDialogDisplayed();
  submitDialog();
}

export function testCommitDialog(title?: string) {
  cy.wait(1000);
  testDialog(
    cy.getByTestId("lock-button"),
    title ? title : "Commit/Revert Item",
  );

  openDialog(cy.getByTestId("lock-button"));
  cy.getByTestId("dialog-submit-button")
    .should("exist")
    .should("not.be.disabled")
    .contains("Commit Changes");

  cy.getByTestId("dialog-cancel-button")
    .should("exist")
    .should("not.be.disabled")
    .contains("Cancel");
  cy.getByTestId("dialog-destructive-button")
    .should("exist")
    .should("not.be.disabled")
    .contains("Revert Changes");

  // test form fields
  testFormField("gitMessageField", "Message", false, {
    defaultValue: "",
  });
  typeFormField("gitMessageField", "test commit message");

  cy.getByTestId("dialog-submit-button").click();
  testDialogIsNotDisplayed();

  testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_COMMIT);
}
