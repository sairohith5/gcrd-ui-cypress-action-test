import {
  testDialogIsNotDisplayed,
  testIsDialogDisplayed,
} from "./dialog-utils";
import { clearFormField } from "./form-utils";
import { testTable } from "./grid-utils";
import { testToast, ToastMessage, ToastTitle } from "./toast-utils";

export function clickAnywhere() {
  cy.get("body").click(0, 0, { force: true });
}

export function deleteArtifact(errorMessage: string | null = null) {
  cy.getByTestId("dialog-destructive-button")
    .should("exist")
    .should("be.disabled")
    .contains("Delete");
  cy.getByTestId("deleteConfirmationInput").type("DELETE");
  cy.getByTestId("dialog-destructive-button")
    .should("exist")
    .should("not.be.disabled")
    .contains("Delete");

  cy.getByTestId("deleteConfirmationInput").type("{backspace}");
  cy.getByTestId("dialog-destructive-button")
    .should("exist")
    .should("be.disabled");

  cy.getByTestId("deleteConfirmationInput").type("O");
  cy.getByTestId("dialog-destructive-button")
    .should("exist")
    .should("be.disabled");

  clearFormField("deleteConfirmationInput");
  cy.getByTestId("deleteConfirmationInput").type("DELETE");

  cy.getByTestId("dialog-destructive-button").click();

  if (!errorMessage) {
    testDialogIsNotDisplayed();
    // this does not work when deleting from an artifact page (because the toast disappears too quickly after navigating back to the list page)
    // testToast(ToastTitle.SUCCESS, ToastMessage.SUCCESSFUL_DELETE);
  } else {
    testIsDialogDisplayed();
    testToast(ToastTitle.ERROR, errorMessage);
  }
}

export function verifyTagsAreReadonly() {
  cy.getByTestId("tag-input").should("be.disabled");
}

export function verifyGlobalVarsAreReadonly() {
  cy.getByTestId("addGlobalVariableBtn").should("not.exist");
  cy.getByTestId("reorderGlobalVariablesBtn").should("not.exist");

  // the first column button should be disabled:
  cy.getByTestId("scrollable-table")
    .find("tbody tr")
    .first()
    .find("th")
    .first()
    .find("button")
    .should("exist")
    .and("be.disabled");

  // the Actions column is not displayed for readonly global vars
  testTable(
    ["Variable Name", "Type", "Is Array?", "Value"],
    ["isTrue", "boolean", "", "true"],
  );
}

export function verifyCustomObjectsAreReadonly() {
  cy.getByTestId("addCustomObjectPropBtn").should("not.exist");
  cy.get('[data-testid^="grid-delete-button"]').should("not.exist");
  cy.get('[data-testid^="grid-clone-button"]').should("not.exist");
}

export function verifyCustomObjectDetailIsReadonly() {
  cy.getByTestId("lock-button").should("not.exist");
  cy.getByTestId("addCustomObjectPropBtn").should("not.exist");
  cy.get('[data-testid^="editCustomObjectFieldBtn"]').should("not.exist");
  cy.get('[data-testid^="grid-delete-button"]').should("not.exist");
  cy.getByTestId("more-actions-btn").should("not.exist");
  cy.getByTestId("editDescriptionBtn").should("not.exist");
}

/**
 * Verifies that an info icon tooltip displays the expected text
 * @param expectedText - The text that should be visible in the tooltip
 * @param testId - Optional custom test ID for the info icon (defaults to "info-icon-tooltip-icon")
 */
export function verifyInfoTooltip(
  expectedText: string,
  testId: string = "info-icon-tooltip-icon",
) {
  cy.getByTestId(testId).should("exist").parents("button").first().focus();

  cy.getByTestId("tooltip-content")
    .should("be.visible")
    .invoke("prop", "innerText")
    .then((text) => {
      const strippedString = text.replace(/[\r\n]/g, " "); // Remove newlines
      expect(strippedString).to.include(expectedText);
    });
}

/**
 * Uses realHover to verify that a tooltip displays the expected text when hovering over a button.
 * @param expectedText
 * @param tooltipButtonTestId
 * @param tooltipContentTestId
 */
export function verifyHoverTooltip(
  expectedText: string,
  tooltipButtonTestId: string,
  tooltipContentTestId: string = "tooltip-content",
) {
  cy.get('[data-testid="' + tooltipButtonTestId + '"]').realHover();
  cy.get('[data-testid="' + tooltipContentTestId + '"]')
    .should("exist")
    .should("be.visible")
    .should("contain.text", expectedText);
}
