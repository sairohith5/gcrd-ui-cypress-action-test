function getEditorSelector(containerSelector?: string) {
  return containerSelector
    ? `${containerSelector} .monaco-editor`
    : ".monaco-editor";
}

/**
 * Clears all text from the Monaco editor identified by an optional container selector.
 *
 * @param containerSelector - Optional CSS selector scoping the Monaco editor container. If omitted,
 * the default context used by `getEditorSelector` is assumed.
 */
export function deleteAllText(containerSelector?: string) {
  const editorSelector = getEditorSelector(containerSelector);

  cy.get(editorSelector).should("exist").as("monacoEditor").click();
  cy.get("@monacoEditor").focused();
  const selectAllShortcut =
    Cypress.platform === "darwin" ? "{cmd}a" : "{ctrl}a";
  cy.get("@monacoEditor").type(`${selectAllShortcut}{del}`);
  cy.wait(500);
}

/**
 * Deletes all text and types replacement text into a Monaco editor. Note that this
 * uses parseSpecialCharSequences: false to ensure that special characters in the input
 * text (e.g. curly braces in JSON) are not interpreted as Cypress key commands.
 *
 * @param text The full text content to insert into the editor after clearing it.
 * @param containerSelector Optional CSS selector scoping which Monaco editor container
 *                          to target (useful when multiple editors are present). If omitted,
 *                          a default selector strategy inside `getEditorSelector` is used.
 */
export function replaceTextInEditor(text: string, containerSelector?: string) {
  deleteAllText(containerSelector);
  const editorSelector = getEditorSelector(containerSelector);

  cy.get(editorSelector).should("exist").as("monacoEditor").click();
  cy.get("@monacoEditor").focused();
  cy.get("@monacoEditor").type(text, {
    delay: 0,
    parseSpecialCharSequences: false,
  });
  cy.wait(500);
}

/**
 * Types the provided raw text into a Monaco editor instance within a Cypress test.
 * Note that this
 * uses parseSpecialCharSequences: false to ensure that special characters in the input
 * text (e.g. curly braces in JSON) are not interpreted as Cypress key commands.
 *
 * @param text The exact text to input into the Monaco editor.
 * @param containerSelector Optional CSS selector scoping where to locate the editor,
 *                          useful when multiple editor instances exist on the page.
 *
 */
export function typeTextInEditor(text: string, containerSelector?: string) {
  const editorSelector = getEditorSelector(containerSelector);

  cy.get(editorSelector).should("exist").as("monacoEditor").click();
  cy.get("@monacoEditor").focused();
  cy.get("@monacoEditor").type(text, {
    delay: 0,
    parseSpecialCharSequences: false,
  });
}

export function verifyEditorStyleIsReadWrite(containerSelector?: string) {
  const editorSelector = containerSelector
    ? `${containerSelector} .code-editor`
    : ".code-editor";
  cy.get(editorSelector).should("exist").should("have.class", "readwrite");
}

export function verifyEditorStyleIsReadOnly(containerSelector?: string) {
  const editorSelector = containerSelector
    ? `${containerSelector} .code-editor`
    : ".code-editor";
  cy.get(editorSelector).should("exist").should("have.class", "readonly");
}
